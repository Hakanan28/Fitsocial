import { Coin, NFT, Transaction } from '../types';

// Helper function to generate mock sparkline data
const generateSparkline = (startPrice: number, change: number): number[] => {
    const data: number[] = [];
    let price = startPrice * (1 - change / 100); // Start from yesterday's price
    for (let i = 0; i < 30; i++) {
        data.push(price);
        // More volatile, realistic movement
        price += (Math.random() - 0.48) * startPrice * 0.08; 
    }
    // Ensure the last point reflects the current price
    data[29] = startPrice;
    return data;
};

const generateTransactions = (balance: number, symbol: string): Transaction[] => {
    const transactions: Transaction[] = [];
    const txCount = Math.floor(Math.random() * 5) + 3; // 3 to 7 transactions

    for (let i = 0; i < txCount; i++) {
        const type = Math.random() > 0.5 ? 'sent' : 'received';
        // Transaction amount up to 20% of balance, with more variance
        const txAmount = (Math.random() * balance) / (5 + Math.random() * 5); 
        // Within last 30 days
        const date = new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; 
        const address = '0x' + [...Array(8)].map(() => Math.floor(Math.random() * 16).toString(16)).join('') + '...' + [...Array(6)].map(() => Math.floor(Math.random() * 16).toString(16)).join('');
        
        transactions.push({
            id: `${symbol}-${i}-${date}-${Math.random()}`,
            type,
            amount: txAmount,
            date,
            address
        });
    }
    // Sort transactions by date descending
    return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

let mockCoins: Coin[] = [
    {
        id: 'ethereum',
        name: 'Ethereum',
        symbol: 'ETH',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/eth.svg',
        balance: 2.5,
        price: 3450.12,
        priceChange24h: 2.5,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'solana',
        name: 'Solana',
        symbol: 'SOL',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/sol.svg',
        balance: 150.75,
        price: 135.80,
        priceChange24h: -1.2,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'binancecoin',
        name: 'Binance Coin',
        symbol: 'BNB',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/bnb.svg',
        balance: 10.2,
        price: 578.45,
        priceChange24h: 0.8,
        sparkline: [],
        transactions: [],
    },
     {
        id: 'matic-network',
        name: 'Polygon',
        symbol: 'MATIC',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/matic.svg',
        balance: 5200,
        price: 0.57,
        priceChange24h: 3.1,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'avalanche-2',
        name: 'Avalanche',
        symbol: 'AVAX',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/avax.svg',
        balance: 80,
        price: 25.50,
        priceChange24h: -2.5,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'sui',
        name: 'Sui',
        symbol: 'SUI',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/sui.svg',
        balance: 10000,
        price: 0.88,
        priceChange24h: 5.0,
        sparkline: [],
        transactions: [],
    },
     {
        id: 'aptos',
        name: 'Aptos',
        symbol: 'APT',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/apt.svg',
        balance: 1200,
        price: 6.90,
        priceChange24h: -0.5,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'optimism',
        name: 'Optimism',
        symbol: 'OP',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/op.svg',
        balance: 2500,
        price: 1.77,
        priceChange24h: 1.8,
        sparkline: [],
        transactions: [],
    },
     {
        id: 'arbitrum',
        name: 'Arbitrum',
        symbol: 'ARB',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/arb.svg',
        balance: 4000,
        price: 0.83,
        priceChange24h: 2.1,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'apecoin',
        name: 'ApeCoin',
        symbol: 'APE',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/ape.svg',
        balance: 850,
        price: 0.95,
        priceChange24h: -3.3,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'ripple',
        name: 'XRP',
        symbol: 'XRP',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/xrp.svg',
        balance: 2050,
        price: 0.47,
        priceChange24h: -0.8,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'stellar',
        name: 'Stellar',
        symbol: 'XLM',
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/xlm.svg',
        balance: 10000,
        price: 0.09,
        priceChange24h: 1.1,
        sparkline: [],
        transactions: [],
    },
    {
        id: 'base',
        name: 'Base',
        symbol: 'BASE',
        logoUrl: 'https://raw.githubusercontent.com/base-org/brand-kit/main/logo/symbol/Base_Symbol_Blue.svg',
        balance: 50.5,
        price: 22.45,
        priceChange24h: 4.5,
        sparkline: [],
        transactions: [],
    }
];

// Initialize sparklines and transactions for the first load
mockCoins.forEach(coin => {
    coin.sparkline = generateSparkline(coin.price, coin.priceChange24h);
    coin.transactions = generateTransactions(coin.balance, coin.symbol);
});

// FIX: Add missing properties to NFT objects to satisfy the NFT type.
const mockNfts: NFT[] = [
    {
        id: '1',
        name: 'FitSocial Genesis Runner',
        collection: 'FitSocial Originals',
        imageUrl: 'https://placehold.co/500x500/1E1E1E/A78BFA?text=NFT%20%231',
        owner: { username: 'FitSocial', avatar: 'https://placehold.co/100x100/10B981/FFFFFF?text=FS' },
        price: 1.5,
        currency: 'ETH',
        bestOffer: 1.2,
        description: 'A special NFT awarded to early adopters of the FitSocial platform.',
        bids: [],
        priceHistory: [],
    },
    {
        id: '2',
        name: 'Quantum Quads #345',
        collection: 'AI Body Art',
        imageUrl: 'https://placehold.co/500x500/111827/34D399?text=Q-Quads',
        owner: { username: 'Zeynep', avatar: 'https://placehold.co/100x100/E91E63/white?text=Z' },
        price: 2.1,
        currency: 'ETH',
        bestOffer: 1.9,
        description: 'A generative art piece based on the muscle data from your 100th workout.',
        bids: [],
        priceHistory: [],
    },
];

const validContracts: { [address: string]: Omit<Coin, 'balance' | 'sparkline' | 'transactions'> } = {
    "0x1f9840a85d5af5bf1d1762f925bdaddc4201f984": {
        id: 'uniswap',
        name: 'Uniswap',
        symbol: 'UNI',
        price: 9.50,
        priceChange24h: 1.5,
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/uni.svg'
    },
    "0x6b175474e89094c44da98b954eedeac495271d0f": {
        id: 'dai',
        name: 'Dai',
        symbol: 'DAI',
        price: 1.00,
        priceChange24h: 0.0,
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/dai.svg'
    },
    "0x514910771af9ca656af840dff83e8264ecf986ca": {
        id: 'chainlink',
        name: 'Chainlink',
        symbol: 'LINK',
        price: 14.25,
        priceChange24h: 4.2,
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/link.svg'
    },
    "0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce": {
        id: 'shiba-inu',
        name: 'Shiba Inu',
        symbol: 'SHIB',
        price: 0.0000175,
        priceChange24h: -1.8,
        logoUrl: 'https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@1a63530be6e374711a8554f31b17e4cb92c2566b/svg/color/shib.svg'
    }
};

export const getCoins = (): Coin[] => {
    // Simulate real-time data by applying fluctuations on each fetch
    return mockCoins.map(coin => {
        const priceFluctuation = (Math.random() - 0.5) * 0.05; // +/- 2.5% price fluctuation
        const balanceFluctuation = (Math.random()) * 0.0005; // small positive balance fluctuation (e.g. staking rewards)
        
        const newPrice = coin.price * (1 + priceFluctuation);
        const newBalance = coin.balance + (coin.balance * balanceFluctuation);
        const newChange = coin.priceChange24h + (priceFluctuation * 20); // Make change more reactive
        
        // Update the master list so changes persist between calls in the same session
        coin.price = newPrice;
        coin.balance = newBalance;
        coin.priceChange24h = newChange;
        
        return {
            ...coin,
            sparkline: generateSparkline(newPrice, newChange),
            transactions: generateTransactions(newBalance, coin.symbol),
        };
    });
};

export const getNFTs = (): NFT[] => {
    return mockNfts;
};

export const validateContract = (address: string): Omit<Coin, 'balance' | 'sparkline' | 'transactions'> | null => {
    return validContracts[address.toLowerCase()] || null;
};