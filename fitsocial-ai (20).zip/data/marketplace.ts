
import { GearItem } from '../types';
import { allUsers } from './users';

export const initialGearItems: GearItem[] = [
    {
        id: 'g1',
        title: 'Optimum Nutrition Gold Standard Whey',
        price: 29.99,
        currency: '$',
        image: 'https://images.unsplash.com/photo-1579722820308-d74e571900a9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        category: 'Supplement',
        condition: 'New',
        seller: allUsers[1], // Ahmet
        description: 'Brand new, sealed, 2.5lb Tub. Double Rich Chocolate flavor. Expiry 2025.',
        specs: [
            { id: 's1', key: 'Flavor', value: 'Double Rich Chocolate' },
            { id: 's2', key: 'Weight', value: '2.5 lbs' },
            { id: 's3', key: 'Servings', value: '29' }
        ],
        logistics: {
            weight: '1.2 kg',
            dimensions: '20x20x30 cm',
            carrier: 'Standard',
            deliveryTime: '3-5 Days'
        },
        reviews: [
            { id: 'r1', user: 'Elif', rating: 5, comment: 'Great price and fast shipping!', timestamp: Date.now() - 86400000 },
            { id: 'r2', user: 'Mehmet', rating: 4, comment: 'Good product, box was slightly dented though.', timestamp: Date.now() - 172800000 }
        ]
    },
    {
        id: 'g2',
        title: 'Adjustable Dumbbells (Pair)',
        price: 150.00,
        currency: '$',
        image: 'https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        category: 'Equipment',
        condition: 'Used',
        seller: allUsers[2], // Elif
        description: 'Slightly used adjustable dumbbells, 5kg to 25kg range. Perfect condition mechanically.',
        specs: [
            { id: 's1', key: 'Range', value: '5kg - 25kg' },
            { id: 's2', key: 'Material', value: 'Cast Iron' }
        ],
        logistics: {
            weight: '50 kg',
            dimensions: '40x40x20 cm',
            carrier: 'DHL Express',
            deliveryTime: '2 Days'
        },
        reviews: []
    },
    {
        id: 'g3',
        title: 'Nike Metcon 8 Training Shoes',
        price: 85.00,
        currency: '$',
        image: 'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        category: 'Clothing',
        condition: 'New',
        seller: allUsers[0], // Zeynep
        description: 'Size 42. Never worn. Box included. Great for CrossFit.',
        specs: [
            { id: 's1', key: 'Size', value: '42 EU' },
            { id: 's2', key: 'Color', value: 'Black/White' }
        ],
        logistics: {
            weight: '1 kg',
            dimensions: '30x20x12 cm',
            carrier: 'Standard',
            deliveryTime: '4 Days'
        },
        reviews: [
             { id: 'r3', user: 'Ahmet', rating: 5, comment: 'Perfect fit, thanks Zeynep!', timestamp: Date.now() - 40000000 }
        ]
    },
    {
        id: 'g4',
        title: 'Garmin Fenix 6 Pro',
        price: 300.00,
        currency: '$',
        image: 'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        category: 'Tech',
        condition: 'Used',
        seller: allUsers[3], // Mehmet
        description: 'Good condition. Comes with charger and extra band. Battery life still excellent.',
        reviews: []
    },
    {
        id: 'g5',
        title: 'Resistance Bands Set',
        price: 15.00,
        currency: '$',
        image: 'https://images.unsplash.com/photo-1598289431512-b97b0917affc?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        category: 'Equipment',
        condition: 'New',
        seller: allUsers[1],
        description: '5 bands with different resistance levels. Handles included.',
        reviews: []
    }
];
