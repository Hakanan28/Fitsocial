import { Reel } from '../types';

// Get timestamps for the last few days to simulate a realistic feed
const now = Date.now();
const oneHour = 60 * 60 * 1000;
const oneDay = 24 * oneHour;

export const initialReelData: Reel[] = [];
