import { Exercise } from '../types';

// Placeholder URLs for different muscle groups
const urls = {
    Legs: 'https://i.imgur.com/DR5gCJ6.gif', // Squat/Deadlift
    Chest: 'https://i.imgur.com/L621U1n.gif', // Bench Press
    Back: 'https://i.imgur.com/vH2s4Qk.gif', // Pull-up
    Shoulders: 'https://i.imgur.com/v1TfD1g.gif', // Overhead Press
    Arms: 'https://i.imgur.com/yk92a3F.gif', // Bicep Curl
    Core: 'https://i.imgur.com/JlvN72A.gif', // Generic core/full body placeholder
    Cardio: 'https://i.imgur.com/U50D32e.gif', // Jumping Jacks
};

export const exercises: Exercise[] = [
    // I. Bacaklar ve Kalça (Legs & Glutes)
    { id: 'legs_01', name: 'Barbell Squat (High Bar / Low Bar)', muscleGroup: 'Legs', equipment: 'Barbell, Squat Rack', location: 'gym', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Hamstrings', 'Core'] },
    { id: 'legs_02', name: 'Front Squat', muscleGroup: 'Legs', equipment: 'Barbell, Squat Rack', location: 'gym', thumbnailUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExMnU2N2N6d3B6b2ZpNnF2OGE5MnBkeGF2cWdudWczNXNnZ3o4M3YzaCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/Vbnmm424yB4k6G6j1B/giphy.gif', primaryMuscles: ['Quadriceps'], secondaryMuscles: ['Glutes', 'Core'] },
    { id: 'legs_03', name: 'Overhead Squat', muscleGroup: 'Legs', equipment: 'Barbell', location: 'gym', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps', 'Glutes', 'Shoulders'], secondaryMuscles: ['Core'] },
    { id: 'legs_04', name: 'Goblet Squat (Dumbbell/Kettlebell)', muscleGroup: 'Legs', equipment: 'Dumbbell or Kettlebell', location: 'both', thumbnailUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3VtbDR5eW11dzR1bnI4aWZ4ZzBnbnMyNTJtbHNoeGE3bjU1cWwzNyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3o6wNGRy0hNSeo2s5a/giphy.gif', primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Core'] },
    { id: 'legs_05', name: 'Zercher Squat', muscleGroup: 'Legs', equipment: 'Barbell', location: 'gym', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Core', 'Upper Back'] },
    { id: 'legs_06', name: 'Safety Bar Squat', muscleGroup: 'Legs', equipment: 'Safety Squat Bar', location: 'gym', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Upper Back'] },
    { id: 'legs_07', name: 'Box Squat', muscleGroup: 'Legs', equipment: 'Barbell, Box', location: 'gym', thumbnailUrl: urls.Legs, primaryMuscles: ['Glutes', 'Hamstrings'], secondaryMuscles: ['Quadriceps'] },
    { id: 'legs_08', name: 'Pistol Squat', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Core'] },
    { id: 'legs_09', name: 'Smith Machine Squat', muscleGroup: 'Legs', equipment: 'Smith Machine', location: 'gym', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps'], secondaryMuscles: ['Glutes'] },
    { id: 'legs_10', name: 'Hack Squat Machine', muscleGroup: 'Legs', equipment: 'Hack Squat Machine', location: 'gym', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps'], secondaryMuscles: ['Glutes'] },
    { id: 'legs_11', name: 'Conventional Deadlift', muscleGroup: 'Legs', equipment: 'Barbell', location: 'gym', thumbnailUrl: 'https://i.imgur.com/Y1b4Z4g.gif', primaryMuscles: ['Glutes', 'Hamstrings', 'Erector Spinae'], secondaryMuscles: ['Lats', 'Trapezius'] },
    { id: 'legs_12', name: 'Sumo Deadlift', muscleGroup: 'Legs', equipment: 'Barbell', location: 'gym', thumbnailUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExaHRiYmZ3dHRzNmVzbGRjaXdxZW1tY3VrcnhoMnI1eXF5MHFjNmQ5aiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/27HB5nWO03s2FlP0kC/giphy.gif', primaryMuscles: ['Glutes', 'Adductors', 'Hamstrings'], secondaryMuscles: ['Quadriceps'] },
    { id: 'legs_13', name: 'Romanian Deadlift (RDL)', muscleGroup: 'Legs', equipment: 'Barbell or Dumbbells', location: 'gym', thumbnailUrl: 'https://i.imgur.com/7s1HsoH.gif', primaryMuscles: ['Hamstrings', 'Glutes'], secondaryMuscles: ['Erector Spinae'] },
    { id: 'legs_14', name: 'Stiff-Legged Deadlift', muscleGroup: 'Legs', equipment: 'Barbell', location: 'gym', thumbnailUrl: 'https://i.imgur.com/7s1HsoH.gif', primaryMuscles: ['Hamstrings'], secondaryMuscles: ['Erector Spinae'] },
    { id: 'legs_15', name: 'Trap Bar Deadlift', muscleGroup: 'Legs', equipment: 'Trap Bar', location: 'gym', thumbnailUrl: 'https://i.imgur.com/Y1b4Z4g.gif', primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_16', name: 'Rack Pull', muscleGroup: 'Legs', equipment: 'Barbell, Squat Rack', location: 'gym', thumbnailUrl: 'https://i.imgur.com/Y1b4Z4g.gif', primaryMuscles: ['Erector Spinae', 'Trapezius'], secondaryMuscles: ['Glutes'] },
    { id: 'legs_17', name: 'Walking Lunge', muscleGroup: 'Legs', equipment: 'Bodyweight or Dumbbells', location: 'both', thumbnailUrl: 'https://i.imgur.com/793bu2v.gif', primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_18', name: 'Bulgarian Split Squat', muscleGroup: 'Legs', equipment: 'Bench, Dumbbells', location: 'both', thumbnailUrl: 'https://i.imgur.com/793bu2v.gif', primaryMuscles: ['Glutes', 'Quadriceps'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_19', name: 'Leg Press', muscleGroup: 'Legs', equipment: 'Leg Press Machine', location: 'gym', thumbnailUrl: 'https://i.imgur.com/dO2gE8x.gif', primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_20', name: 'Leg Extension', muscleGroup: 'Legs', equipment: 'Leg Extension Machine', location: 'gym', thumbnailUrl: 'https://i.imgur.com/dO2gE8x.gif', primaryMuscles: ['Quadriceps'], secondaryMuscles: [] },
    { id: 'legs_21', name: 'Lying Leg Curl', muscleGroup: 'Legs', equipment: 'Leg Curl Machine', location: 'gym', thumbnailUrl: 'https://i.imgur.com/qJ1jC8V.gif', primaryMuscles: ['Hamstrings'], secondaryMuscles: ['Calves'] },
    { id: 'legs_22', name: 'Hip Thrust', muscleGroup: 'Legs', equipment: 'Barbell, Bench', location: 'gym', thumbnailUrl: 'https://i.imgur.com/C72mGgF.gif', primaryMuscles: ['Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_23', name: 'Standing Calf Raise', muscleGroup: 'Legs', equipment: 'Machine or Dumbbells', location: 'gym', thumbnailUrl: 'https://i.imgur.com/1a7g6L7.gif', primaryMuscles: ['Gastrocnemius'], secondaryMuscles: ['Soleus'] },
    { id: 'legs_24', name: 'Seated Calf Raise', muscleGroup: 'Legs', equipment: 'Machine', location: 'gym', thumbnailUrl: 'https://i.imgur.com/1a7g6L7.gif', primaryMuscles: ['Soleus'], secondaryMuscles: [] },
    
    // II. Göğüs (Chest)
    { id: 'chest_01', name: 'Barbell Bench Press (Flat/Incline/Decline)', muscleGroup: 'Chest', equipment: 'Barbell, Bench', location: 'gym', thumbnailUrl: urls.Chest, primaryMuscles: ['Pectoralis Major'], secondaryMuscles: ['Triceps', 'Deltoids'] },
    { id: 'chest_02', name: 'Dumbbell Bench Press (Flat/Incline/Decline)', muscleGroup: 'Chest', equipment: 'Dumbbells, Bench', location: 'gym', thumbnailUrl: urls.Chest, primaryMuscles: ['Pectoralis Major'], secondaryMuscles: ['Triceps', 'Deltoids'] },
    { id: 'chest_03', name: 'Dumbbell Fly (Flat/Incline/Decline)', muscleGroup: 'Chest', equipment: 'Dumbbells, Bench', location: 'gym', thumbnailUrl: 'https://i.imgur.com/N52dJ4A.gif', primaryMuscles: ['Pectoralis Major'], secondaryMuscles: ['Deltoids'] },
    { id: 'chest_04', name: 'Cable Crossover (High-to-Low / Low-to-High)', muscleGroup: 'Chest', equipment: 'Cable Machine', location: 'gym', thumbnailUrl: 'https://i.imgur.com/zK3qS9x.gif', primaryMuscles: ['Pectoralis Major'], secondaryMuscles: [] },
    { id: 'chest_05', name: 'Pec Deck Fly Machine', muscleGroup: 'Chest', equipment: 'Pec Deck Machine', location: 'gym', thumbnailUrl: 'https://i.imgur.com/N52dJ4A.gif', primaryMuscles: ['Pectoralis Major'], secondaryMuscles: [] },
    { id: 'chest_06', name: 'Push-Up (Şınav)', muscleGroup: 'Chest', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/PAqYm3N.gif', primaryMuscles: ['Pectoralis Major'], secondaryMuscles: ['Triceps', 'Deltoids'] },
    { id: 'chest_07', name: 'Incline/Decline Push-Up', muscleGroup: 'Chest', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/sM2g3u1.gif', primaryMuscles: ['Pectoralis Major (Upper/Lower)'], secondaryMuscles: ['Triceps', 'Deltoids'] },
    
    // III. Sırt (Back)
    { id: 'back_01', name: 'Pull-Up', muscleGroup: 'Back', equipment: 'Pull-up Bar', location: 'both', thumbnailUrl: urls.Back, primaryMuscles: ['Latissimus Dorsi'], secondaryMuscles: ['Biceps', 'Rhomboids'] },
    { id: 'back_02', name: 'Chin-Up', muscleGroup: 'Back', equipment: 'Pull-up Bar', location: 'both', thumbnailUrl: urls.Back, primaryMuscles: ['Latissimus Dorsi', 'Biceps'], secondaryMuscles: ['Rhomboids'] },
    { id: 'back_03', name: 'Lat Pulldown', muscleGroup: 'Back', equipment: 'Cable Machine', location: 'gym', thumbnailUrl: urls.Back, primaryMuscles: ['Latissimus Dorsi'], secondaryMuscles: ['Biceps'] },
    { id: 'back_04', name: 'Barbell Bent-Over Row', muscleGroup: 'Back', equipment: 'Barbell', location: 'gym', thumbnailUrl: 'https://i.imgur.com/4z3a6A9.gif', primaryMuscles: ['Latissimus Dorsi', 'Rhomboids', 'Trapezius'], secondaryMuscles: ['Biceps', 'Erector Spinae'] },
    { id: 'back_05', name: 'Dumbbell Single-Arm Row', muscleGroup: 'Back', equipment: 'Dumbbell, Bench', location: 'gym', thumbnailUrl: 'https://i.imgur.com/4z3a6A9.gif', primaryMuscles: ['Latissimus Dorsi'], secondaryMuscles: ['Biceps', 'Rhomboids'] },
    { id: 'back_06', name: 'Seated Cable Row', muscleGroup: 'Back', equipment: 'Cable Machine', location: 'gym', thumbnailUrl: 'https://i.imgur.com/4z3a6A9.gif', primaryMuscles: ['Rhomboids', 'Trapezius'], secondaryMuscles: ['Lats', 'Biceps'] },
    { id: 'back_07', name: 'T-Bar Row', muscleGroup: 'Back', equipment: 'T-Bar Machine', location: 'gym', thumbnailUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExYXU2d3A2NHFqNWswbmU5dHF2bWhtNnE3aGhwczUzdTNtdHZudnJ1YSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/l3q2A1gU3I956A6m4/giphy.gif', primaryMuscles: ['Latissimus Dorsi', 'Rhomboids'], secondaryMuscles: ['Biceps'] },
    { id: 'back_08', name: 'Hyperextension', muscleGroup: 'Back', equipment: 'Hyperextension Bench', location: 'gym', thumbnailUrl: 'https://i.imgur.com/9a5cb8K.gif', primaryMuscles: ['Erector Spinae'], secondaryMuscles: ['Glutes', 'Hamstrings'] },
    
    // IV. Omuz (Shoulders)
    { id: 'shoulders_01', name: 'Barbell Overhead Press (Military Press)', muscleGroup: 'Shoulders', equipment: 'Barbell', location: 'gym', thumbnailUrl: urls.Shoulders, primaryMuscles: ['Deltoids'], secondaryMuscles: ['Triceps', 'Trapezius'] },
    { id: 'shoulders_02', name: 'Dumbbell Seated Shoulder Press', muscleGroup: 'Shoulders', equipment: 'Dumbbells, Bench', location: 'gym', thumbnailUrl: urls.Shoulders, primaryMuscles: ['Deltoids'], secondaryMuscles: ['Triceps'] },
    { id: 'shoulders_03', name: 'Arnold Press', muscleGroup: 'Shoulders', equipment: 'Dumbbells', location: 'gym', thumbnailUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbHBwbHBxajluY2Rvc2tldmV0M2o1bTExbmZ0eHR6dWswZXgzdGllNyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/l0MYD43C0IA7a0p2M/giphy.gif', primaryMuscles: ['Deltoids'], secondaryMuscles: ['Triceps'] },
    { id: 'shoulders_04', name: 'Dumbbell Lateral Raise', muscleGroup: 'Shoulders', equipment: 'Dumbbells', location: 'both', thumbnailUrl: 'https://i.imgur.com/I7eB5AF.gif', primaryMuscles: ['Deltoids (Medial)'], secondaryMuscles: [] },
    { id: 'shoulders_05', name: 'Dumbbell Front Raise', muscleGroup: 'Shoulders', equipment: 'Dumbbells', location: 'both', thumbnailUrl: 'https://i.imgur.com/I7eB5AF.gif', primaryMuscles: ['Deltoids (Anterior)'], secondaryMuscles: [] },
    { id: 'shoulders_06', name: 'Bent-Over Dumbbell Reverse Fly', muscleGroup: 'Shoulders', equipment: 'Dumbbells', location: 'both', thumbnailUrl: 'https://i.imgur.com/iL29iB5.gif', primaryMuscles: ['Deltoids (Posterior)'], secondaryMuscles: ['Rhomboids', 'Trapezius'] },
    { id: 'shoulders_07', name: 'Face Pull', muscleGroup: 'Shoulders', equipment: 'Cable Machine, Rope', location: 'gym', thumbnailUrl: 'https://i.imgur.com/iL29iB5.gif', primaryMuscles: ['Deltoids (Posterior)', 'Rotator Cuff'], secondaryMuscles: ['Trapezius'] },
    { id: 'shoulders_08', name: 'Upright Row', muscleGroup: 'Shoulders', equipment: 'Barbell or Dumbbells', location: 'gym', thumbnailUrl: 'https://i.imgur.com/I7eB5AF.gif', primaryMuscles: ['Deltoids (Medial)', 'Trapezius'], secondaryMuscles: ['Biceps'] },
    
    // V. Kollar (Arms)
    { id: 'arms_01', name: 'Barbell Curl', muscleGroup: 'Arms', equipment: 'Barbell or E-Z Bar', location: 'gym', thumbnailUrl: urls.Arms, primaryMuscles: ['Biceps'], secondaryMuscles: ['Forearms'] },
    { id: 'arms_02', name: 'Dumbbell Standing Curl', muscleGroup: 'Arms', equipment: 'Dumbbells', location: 'both', thumbnailUrl: urls.Arms, primaryMuscles: ['Biceps'], secondaryMuscles: ['Forearms'] },
    { id: 'arms_03', name: 'Hammer Curl', muscleGroup: 'Arms', equipment: 'Dumbbells', location: 'both', thumbnailUrl: urls.Arms, primaryMuscles: ['Biceps', 'Brachialis'], secondaryMuscles: ['Forearms'] },
    { id: 'arms_04', name: 'Preacher Curl', muscleGroup: 'Arms', equipment: 'Preacher Bench, Barbell/Dumbbell', location: 'gym', thumbnailUrl: urls.Arms, primaryMuscles: ['Biceps'], secondaryMuscles: [] },
    { id: 'arms_05', name: 'Triceps Pushdown', muscleGroup: 'Arms', equipment: 'Cable Machine', location: 'gym', thumbnailUrl: 'https://i.imgur.com/jG4pL9V.gif', primaryMuscles: ['Triceps'], secondaryMuscles: [] },
    { id: 'arms_06', name: 'Skullcrusher (Alın Bükme)', muscleGroup: 'Arms', equipment: 'Barbell/Dumbbells, Bench', location: 'gym', thumbnailUrl: 'https://i.imgur.com/jG4pL9V.gif', primaryMuscles: ['Triceps'], secondaryMuscles: [] },
    { id: 'arms_07', name: 'Overhead Extension', muscleGroup: 'Arms', equipment: 'Dumbbell or Cable', location: 'gym', thumbnailUrl: 'https://i.imgur.com/jG4pL9V.gif', primaryMuscles: ['Triceps'], secondaryMuscles: [] },
    { id: 'arms_08', name: 'Bench Dip', muscleGroup: 'Arms', equipment: 'Bench', location: 'both', thumbnailUrl: 'https://i.imgur.com/jG4pL9V.gif', primaryMuscles: ['Triceps'], secondaryMuscles: ['Chest', 'Deltoids'] },
    { id: 'arms_09', name: 'Close-Grip Bench Press', muscleGroup: 'Arms', equipment: 'Barbell, Bench', location: 'gym', thumbnailUrl: urls.Chest, primaryMuscles: ['Triceps'], secondaryMuscles: ['Pectoralis Major', 'Deltoids'] },
    
    // VI. Karın ve Çekirdek (Abs & Core)
    { id: 'core_01', name: 'Crunch', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis'], secondaryMuscles: [] },
    { id: 'core_02', name: 'Leg Raise (Hanging/Floor)', muscleGroup: 'Core', equipment: 'Pull-up Bar or Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/kSsoB5I.gif', primaryMuscles: ['Rectus Abdominis (Lower)'], secondaryMuscles: ['Hip Flexors'] },
    { id: 'core_03', name: 'Plank', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Core'], secondaryMuscles: [] },
    { id: 'core_04', name: 'Russian Twist', muscleGroup: 'Core', equipment: 'Bodyweight or Dumbbell', location: 'both', thumbnailUrl: 'https://i.imgur.com/rN41n9z.gif', primaryMuscles: ['Obliques'], secondaryMuscles: ['Rectus Abdominis'] },
    { id: 'core_05', name: 'Ab Rollout', muscleGroup: 'Core', equipment: 'Ab Wheel', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis', 'Core'], secondaryMuscles: ['Lats'] },
    { id: 'core_06', name: 'Cable Crunch', muscleGroup: 'Core', equipment: 'Cable Machine', location: 'gym', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis'], secondaryMuscles: [] },
    { id: 'core_07', name: 'Hanging Knee Raise', muscleGroup: 'Core', equipment: 'Pull-up Bar', location: 'gym', thumbnailUrl: 'https://i.imgur.com/kSsoB5I.gif', primaryMuscles: ['Rectus Abdominis (Lower)'], secondaryMuscles: ['Hip Flexors'] },
    { id: 'core_08', name: 'Mountain Climber', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Core', 'Full Body'], secondaryMuscles: [] },
    { id: 'core_09', name: 'Pallof Press', muscleGroup: 'Core', equipment: 'Cable Machine or Resistance Band', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Core', 'Obliques'], secondaryMuscles: [] },

    // AT-HOME EXERCISES
    { id: 'chest_home_02', name: 'Knee Push-Up', muscleGroup: 'Chest', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/PAqYm3N.gif', primaryMuscles: ['Pectoralis Major'], secondaryMuscles: ['Triceps', 'Deltoids'] },
    { id: 'chest_home_03', name: 'Wide Push-Up', muscleGroup: 'Chest', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/PAqYm3N.gif', primaryMuscles: ['Pectoralis Major'], secondaryMuscles: ['Deltoids'] },
    { id: 'arms_home_01', name: 'Close/Triceps Push-Up', muscleGroup: 'Arms', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/jG4pL9V.gif', primaryMuscles: ['Triceps'], secondaryMuscles: ['Pectoralis Major'] },
    { id: 'arms_home_02', name: 'Diamond Push-Up', muscleGroup: 'Arms', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/jG4pL9V.gif', primaryMuscles: ['Triceps'], secondaryMuscles: ['Pectoralis Major'] },
    { id: 'chest_home_04', name: 'One-Arm Push-Up', muscleGroup: 'Chest', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/PAqYm3N.gif', primaryMuscles: ['Pectoralis Major'], secondaryMuscles: ['Triceps', 'Core', 'Obliques'] },
    { id: 'arms_home_03', name: 'Fingertip Push-Up', muscleGroup: 'Chest', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/PAqYm3N.gif', primaryMuscles: ['Pectoralis Major'], secondaryMuscles: ['Forearms', 'Triceps'] },
    { id: 'chest_home_05', name: 'Plyometric Push-Up', muscleGroup: 'Chest', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/PAqYm3N.gif', primaryMuscles: ['Pectoralis Major'], secondaryMuscles: ['Triceps', 'Deltoids'] },
    { id: 'arms_home_04', name: 'Straight-Leg Bench Dip', muscleGroup: 'Arms', equipment: 'Bench or Chair', location: 'both', thumbnailUrl: 'https://i.imgur.com/jG4pL9V.gif', primaryMuscles: ['Triceps'], secondaryMuscles: ['Chest', 'Deltoids'] },
    { id: 'shoulders_home_01', name: 'Pike Push-Up', muscleGroup: 'Shoulders', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/v1TfD1g.gif', primaryMuscles: ['Deltoids'], secondaryMuscles: ['Triceps'] },
    { id: 'shoulders_home_02', name: 'Elevated Pike Push-Up', muscleGroup: 'Shoulders', equipment: 'Bodyweight, Bench/Chair', location: 'both', thumbnailUrl: 'https://i.imgur.com/v1TfD1g.gif', primaryMuscles: ['Deltoids'], secondaryMuscles: ['Triceps'] },
    { id: 'shoulders_home_03', name: 'Wall Press', muscleGroup: 'Shoulders', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/v1TfD1g.gif', primaryMuscles: ['Deltoids'], secondaryMuscles: ['Chest', 'Triceps'] },
    { id: 'back_home_01', name: 'Inverted Row', muscleGroup: 'Back', equipment: 'Table or Bar', location: 'home', thumbnailUrl: 'https://i.imgur.com/4z3a6A9.gif', primaryMuscles: ['Latissimus Dorsi', 'Rhomboids'], secondaryMuscles: ['Biceps'] },
    { id: 'back_home_02', name: 'Door Frame Pull-Up', muscleGroup: 'Back', equipment: 'Door Frame', location: 'home', thumbnailUrl: urls.Back, primaryMuscles: ['Latissimus Dorsi'], secondaryMuscles: ['Biceps'] },
    { id: 'back_home_03', name: 'Towel Row', muscleGroup: 'Back', equipment: 'Towel, Door', location: 'home', thumbnailUrl: 'https://i.imgur.com/4z3a6A9.gif', primaryMuscles: ['Latissimus Dorsi', 'Rhomboids'], secondaryMuscles: ['Biceps'] },
    { id: 'arms_home_05', name: 'Isometric Towel Biceps Curl', muscleGroup: 'Arms', equipment: 'Towel', location: 'home', thumbnailUrl: urls.Arms, primaryMuscles: ['Biceps'], secondaryMuscles: ['Forearms'] },
    { id: 'back_home_04', name: 'Archer Row', muscleGroup: 'Back', equipment: 'Bar', location: 'home', thumbnailUrl: urls.Back, primaryMuscles: ['Latissimus Dorsi'], secondaryMuscles: ['Biceps', 'Core'] },
    { id: 'legs_home_01', name: 'Bodyweight Squat', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_home_02', name: 'Tempo Squat', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_home_03', name: 'Jump Squat', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Calves'] },
    { id: 'legs_home_04', name: 'Split Squat', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/793bu2v.gif', primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_home_05', name: 'Shrimp Squat', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Core'] },
    { id: 'legs_home_06', name: 'Wall Sit', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Legs, primaryMuscles: ['Quadriceps'], secondaryMuscles: ['Glutes'] },
    { id: 'legs_home_07', name: 'Forward Lunge', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/793bu2v.gif', primaryMuscles: ['Quadriceps', 'Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_home_08', name: 'Reverse Lunge', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/793bu2v.gif', primaryMuscles: ['Glutes', 'Quadriceps'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_home_09', name: 'Lateral Lunge', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/793bu2v.gif', primaryMuscles: ['Adductors', 'Glutes'], secondaryMuscles: ['Quadriceps'] },
    { id: 'legs_home_10', name: 'Curtsy Lunge', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/793bu2v.gif', primaryMuscles: ['Glutes'], secondaryMuscles: ['Quadriceps'] },
    { id: 'legs_home_11', name: 'Glute Bridge', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/C72mGgF.gif', primaryMuscles: ['Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_home_12', name: 'Single-Leg Glute Bridge', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/C72mGgF.gif', primaryMuscles: ['Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_home_13', name: 'Hip Thrust (Bodyweight)', muscleGroup: 'Legs', equipment: 'Bodyweight, Bench/Chair', location: 'both', thumbnailUrl: 'https://i.imgur.com/C72mGgF.gif', primaryMuscles: ['Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_home_14', name: 'Donkey Kick', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/C72mGgF.gif', primaryMuscles: ['Glutes'], secondaryMuscles: ['Hamstrings'] },
    { id: 'legs_home_15', name: 'Fire Hydrant', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/C72mGgF.gif', primaryMuscles: ['Glutes'], secondaryMuscles: ['Abductors'] },
    { id: 'legs_home_16', name: 'Single-Leg RDL (Bodyweight)', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Legs, primaryMuscles: ['Hamstrings', 'Glutes'], secondaryMuscles: ['Core'] },
    { id: 'legs_home_17', name: 'Standing Calf Raise (Bodyweight)', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/1a7g6L7.gif', primaryMuscles: ['Gastrocnemius'], secondaryMuscles: ['Soleus'] },
    { id: 'legs_home_18', name: 'Elevated Calf Raise', muscleGroup: 'Legs', equipment: 'Bodyweight, Step', location: 'both', thumbnailUrl: 'https://i.imgur.com/1a7g6L7.gif', primaryMuscles: ['Gastrocnemius'], secondaryMuscles: ['Soleus'] },
    { id: 'legs_home_19', name: 'Single-Leg Calf Raise', muscleGroup: 'Legs', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/1a7g6L7.gif', primaryMuscles: ['Gastrocnemius'], secondaryMuscles: ['Soleus'] },
    { id: 'core_home_01', name: 'Reverse Crunch', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis (Lower)'], secondaryMuscles: [] },
    { id: 'core_home_02', name: 'Bicycle Crunch', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis', 'Obliques'], secondaryMuscles: [] },
    { id: 'core_home_03', name: 'Flutter Kicks', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis (Lower)'], secondaryMuscles: ['Hip Flexors'] },
    { id: 'core_home_04', name: 'Scissor Kicks', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis (Lower)'], secondaryMuscles: ['Hip Flexors'] },
    { id: 'core_home_05', name: 'V-Up', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis'], secondaryMuscles: ['Hip Flexors'] },
    { id: 'core_home_06', name: 'Ab Rollout (Towel/Alternative)', muscleGroup: 'Core', equipment: 'Towel', location: 'home', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis'], secondaryMuscles: ['Lats'] },
    { id: 'core_home_07', name: 'High Plank', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Core'], secondaryMuscles: ['Shoulders', 'Glutes'] },
    { id: 'core_home_08', name: 'Side Plank', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Obliques'], secondaryMuscles: ['Glutes'] },
    { id: 'core_home_09', name: 'Plank Hip Dip', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Obliques'], secondaryMuscles: ['Core'] },
    { id: 'core_home_10', name: 'Bird Dog', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Core'], secondaryMuscles: ['Glutes', 'Erector Spinae'] },
    { id: 'core_home_11', name: 'Superman', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/9a5cb8K.gif', primaryMuscles: ['Erector Spinae'], secondaryMuscles: ['Glutes'] },
    { id: 'core_home_12', name: 'Hollow Hold', muscleGroup: 'Core', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Core, primaryMuscles: ['Rectus Abdominis'], secondaryMuscles: ['Hip Flexors'] },

    // CARDIO
    { id: 'cardio_01', name: 'Jumping Jacks', muscleGroup: 'Cardio', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Cardio, primaryMuscles: ['Full Body'], secondaryMuscles: [] },
    { id: 'cardio_02', name: 'High Knees', muscleGroup: 'Cardio', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/OqD8nZ5.gif', primaryMuscles: ['Full Body'], secondaryMuscles: ['Core'] },
    { id: 'cardio_03', name: 'Burpees', muscleGroup: 'Cardio', equipment: 'Bodyweight', location: 'both', thumbnailUrl: 'https://i.imgur.com/zXg8tJk.gif', primaryMuscles: ['Full Body'], secondaryMuscles: [] },
    { id: 'cardio_04', name: 'Butt Kicks', muscleGroup: 'Cardio', equipment: 'Bodyweight', location: 'both', thumbnailUrl: urls.Cardio, primaryMuscles: ['Hamstrings'], secondaryMuscles: ['Full Body'] },
];