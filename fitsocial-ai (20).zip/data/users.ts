import { UserProfile, Story } from '../types';

// IMPORTANT: CVS Score is now a calculated metric. The static value here is only a fallback and will be overwritten.
// Setting all to 0.0 to represent a "clean slate" for the dynamic calculation.
export const allUsers: UserProfile[] = [
    {
        username: "Zeynep",
        name: "Zeynep",
        surname: "Yılmaz",
        email: "zeynep@fitsocial.app",
        phone: "+905551112233",
        password: "password123",
        avatarText: "Z",
        avatarColor: "#E91E63",
        avatarImage: "https://placehold.co/150x150/E91E63/white?text=Z",
        posts: [],
        followers: 2,
        following: ['Ahmet'],
        cvsScore: 0.0, 
        bio: "Fitness enthusiast & healthy recipe creator. Let's get stronger together! 💪",
        highlights: [],
        isVerified: false,
        somatotype: 'mesomorph',
        isOnline: true,
        lastSeen: Date.now(),
        presenceHidden: false,
        blockedUsers: [],
    },
    {
        username: "Ahmet",
        name: "Ahmet",
        surname: "Kaya",
        email: "ahmet@fitsocial.app",
        phone: "+905552223344",
        password: "password123",
        avatarText: "A",
        avatarColor: "#FBC02D",
        avatarImage: "https://placehold.co/100x100/FBC02D/white?text=A",
        posts: [],
        followers: 250,
        following: ['Elif', 'Mehmet'],
        cvsScore: 0.0,
        bio: "Just a guy trying to lift heavy things. Join me on my journey.",
        highlights: [],
        isVerified: false,
        somatotype: 'ectomorph',
        isOnline: true,
        lastSeen: Date.now(),
        presenceHidden: false,
        blockedUsers: [],
    },
    {
        username: "Elif",
        name: "Elif",
        surname: "Demir",
        email: "elif@fitsocial.app",
        phone: "+905553334455",
        password: "password123",
        avatarText: "E",
        avatarColor: "#E91E63",
        avatarImage: "https://placehold.co/100x100/E91E63/white?text=E",
        posts: [],
        followers: 1200,
        following: ['Zeynep'],
        cvsScore: 0.0,
        bio: "Healthy food lover.",
        highlights: [],
        isVerified: true, // Verified Coach
        somatotype: 'endomorph',
        isOnline: false,
        lastSeen: Date.now() - 3600000, // 1 hour ago
        presenceHidden: true,
        blockedUsers: [],
    },
    {
        username: "Mehmet",
        name: "Mehmet",
        surname: "Çelik",
        email: "mehmet@fitsocial.app",
        phone: "+905554445566",
        password: "password123",
        avatarText: "M",
        avatarColor: "#3F51B5",
        avatarImage: "https://placehold.co/100x100/3F51B5/white?text=M",
        posts: [],
        followers: 800,
        following: ['Zeynep', 'Ahmet'],
        cvsScore: 0.0,
        bio: "Gym is life.",
        highlights: [],
        isVerified: false,
        somatotype: 'mesomorph',
        isOnline: false,
        lastSeen: Date.now() - 86400000, // 1 day ago
        presenceHidden: false,
        blockedUsers: [],
    }
];

// Helper to find a user by username
export const findUser = (username: string, userList: UserProfile[]): UserProfile | undefined => {
    return userList.find(u => u.username === username);
};

// Helper to find a user by email
export const findUserByEmail = (email: string, userList: UserProfile[]): UserProfile | undefined => {
    return userList.find(u => u.email.toLowerCase() === email.toLowerCase());
};

// Helper to find a user by phone
export const findUserByPhone = (phone: string, userList: UserProfile[]): UserProfile | undefined => {
    return userList.find(u => u.phone === phone);
};


export const currentUserProfile = allUsers[0]; // Keep for components that haven't been fully migrated
export const otherUsers = allUsers.slice(1); // Keep for components that haven't been fully migrated