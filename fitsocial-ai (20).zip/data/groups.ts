
import { Group, GroupMessage, CallLog } from '../types';

export const initialGroupData: Group[] = [];

export const initialDmData: Record<string, GroupMessage[]> = {};

export const initialCallLogs: CallLog[] = [];
