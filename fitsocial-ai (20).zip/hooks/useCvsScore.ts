import { useMemo } from 'react';
import { UserProfile, Post, Reel, ProofOfWorkoutPost, WorkoutRoutine, ActivityRecord } from '../types';

// This new hook calculates a user's CVS score based on real data.
const oneDay = 24 * 60 * 60 * 1000;
const now = Date.now();

/**
 * Calculates a dynamic Community Validation Score (CVS) based on user activity and contributions.
 * The scoring is designed to reward consistent effort and quality content over superficial metrics.
 * A score of 10.0 is designed to be difficult, requiring ~1000 points.
 * A user creating 1 PoW per day (25 pts) + having some followers/likes would take roughly a month to get near the top.
 * @returns A calculated CVS score between 0.0 and 10.0.
 */
export const useCvsScore = (
    user: UserProfile | null,
    allPosts: Post[],
    allReels: Reel[],
    allPows: ProofOfWorkoutPost[],
    allRoutines: WorkoutRoutine[],
    activityHistory: ActivityRecord[]
): number => {
    return useMemo(() => {
        if (!user) return 0.0;

        let points = 0;
        const debugLog: string[] = [];

        // Filter content for the specific user
        const myPosts = allPosts.filter(p => p.author === user.username);
        const myReels = allReels.filter(r => r.user === user.username);
        const myPows = allPows.filter(p => p.user.username === user.username);
        const myRoutines = allRoutines.filter(r => r.user.username === user.username);

        // --- 1. ACCOUNT AGE & CONSISTENCY (Max ~150 points) ---
        // Simulating creation date. In a real app, this would be on the user object.
        const creationTimestamp = (user as any).creationTimestamp || (now - (3 * oneDay)); // Default to 3 days old for existing mock users
        const daysOld = (now - creationTimestamp) / oneDay;
        const ageBonus = Math.min(daysOld * 0.5, 50); // 0.5 points per day, capped at 50 points (approx 3 months)
        points += ageBonus;
        debugLog.push(`Age: +${ageBonus.toFixed(0)}`);

        // Activity Streak Bonus
        const streak = activityHistory.length; // Simplified for demo, assumes full history is a streak
        const streakBonus = Math.min(streak * 2, 100); // 2 points per day in streak, capped at 100
        points += streakBonus;
        debugLog.push(`Streak: +${streakBonus.toFixed(0)}`);

        // --- 2. SWEAT EQUITY (Proof of Workout is KING) (High Impact) ---
        const powBonus = myPows.length * 25; // 25 points per workout logged
        points += powBonus;
        if (powBonus > 0) debugLog.push(`PoW: +${powBonus.toFixed(0)}`);

        const verifiedPowBonus = myPows.filter(p => p.isVerified).length * 15; // Extra 15 points for verified data
        points += verifiedPowBonus;
        if (verifiedPowBonus > 0) debugLog.push(`VerifiedPoW: +${verifiedPowBonus.toFixed(0)}`);

        // --- 3. CONTENT CONTRIBUTION (Medium Impact) ---
        const postBonus = myPosts.length * 5;
        points += postBonus;
        if (postBonus > 0) debugLog.push(`Posts: +${postBonus.toFixed(0)}`);
        
        const reelBonus = myReels.length * 10; // Reels are higher effort
        points += reelBonus;
        if (reelBonus > 0) debugLog.push(`Reels: +${reelBonus.toFixed(0)}`);

        const routineBonus = myRoutines.length * 20; // Routines are very high value community content
        points += routineBonus;
        if (routineBonus > 0) debugLog.push(`Routines: +${routineBonus.toFixed(0)}`);
        
        // --- 4. SOCIAL CAPITAL (Low-Medium Impact) ---
        const followerBonus = Math.min(user.followers * 0.2, 150); // 0.2 points per follower, capped
        points += followerBonus;
        if (followerBonus > 0) debugLog.push(`Followers: +${followerBonus.toFixed(0)}`);

        const totalLikes = myPosts.reduce((s, p) => s + p.likes, 0) + myReels.reduce((s, r) => s + r.likes, 0) + myPows.reduce((s, p) => s + p.likes, 0);
        const likeBonus = Math.min(totalLikes * 0.1, 100); // Low value per like, capped
        points += likeBonus;
        if (likeBonus > 0) debugLog.push(`Likes: +${likeBonus.toFixed(0)}`);

        const totalSaves = myRoutines.reduce((s, r) => s + r.savesCount, 0);
        const saveBonus = Math.min(totalSaves * 2, 100); // Saves on routines are valuable
        points += saveBonus;
        if (saveBonus > 0) debugLog.push(`Saves: +${saveBonus.toFixed(0)}`);

        // --- 5. PENALTIES ---
        // Spam Filter
        const followRatio = user.followers / Math.max(1, user.following.length);
        if (followRatio < 0.1 && user.following.length > 500) {
            points -= 100;
            debugLog.push(`SpamPenalty: -100`);
        }

        // Inactivity Penalty (simulated based on latest content)
        const allContentTimestamps = [
            ...myPosts.map(p => (p as any).timestamp || 0),
            ...myReels.map(r => r.timestamp || 0),
            ...myPows.map(p => (p as any).timestamp || 0)
        ].filter(t => t > 0);

        const lastActivityTimestamp = allContentTimestamps.length > 0 ? Math.max(...allContentTimestamps) : creationTimestamp;
        
        if ((now - lastActivityTimestamp) > 7 * oneDay) {
            points *= 0.8; // 20% score decay if inactive for 7+ days
            debugLog.push(`Inactive: x0.8`);
        }

        // --- FINAL CALCULATION ---
        // Target: 1000 points = 10.0 CVS score. This makes it a journey.
        // A dedicated user logging a PoW daily (25 pts) would take ~40 days to reach max points from that alone.
        const cvs = (points / 1000) * 10.0;
        
        // Clamp the score between 0.0 and 10.0 and format to one decimal place.
        return parseFloat(Math.min(Math.max(0, cvs), 10.0).toFixed(1));

    }, [user, allPosts, allReels, allPows, allRoutines, activityHistory]);
};
