import { useState, useEffect, useCallback } from 'react';
import { ActivityRecord } from '../types';

const STORAGE_KEY = 'fitSocialActivityHistory';

// FIX: Helper function to get YYYY-MM-DD in local timezone
const getLocalDateString = (date: Date): string => {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
};

export const useActivityHistory = () => {
    const [activityHistory, setActivityHistory] = useState<ActivityRecord[]>([]);

    // Load from localStorage on initial render
    useEffect(() => {
        try {
            const storedHistory = localStorage.getItem(STORAGE_KEY);
            if (storedHistory) {
                setActivityHistory(JSON.parse(storedHistory));
            } else {
                // If no history, start with an empty array.
                setActivityHistory([]);
            }
        } catch (error) {
            console.error("Failed to load activity history from localStorage", error);
            setActivityHistory([]); // Fallback to empty on error
        }
    }, []);

    // Save to localStorage whenever history changes
    useEffect(() => {
        try {
            // Only save if there's actual data to prevent storing an empty array over real data from another tab.
            if(activityHistory.length > 0) {
                 localStorage.setItem(STORAGE_KEY, JSON.stringify(activityHistory));
            }
        } catch (error) {
            console.error("Failed to save activity history to localStorage", error);
        }
    }, [activityHistory]);

    const updateTodayRecord = useCallback((
        todayStats: Omit<ActivityRecord, 'date'>
    ) => {
        setActivityHistory(prevHistory => {
            // FIX: Use local date string instead of UTC from toISOString
            const todayStr = getLocalDateString(new Date());
            const todayIndex = prevHistory.findIndex(record => record.date === todayStr);

            let newHistory = [...prevHistory];

            if (todayIndex !== -1) {
                // Update today's existing record
                newHistory[todayIndex] = { ...newHistory[todayIndex], ...todayStats };
            } else {
                // Add a new record for today
                newHistory.unshift({ date: todayStr, ...todayStats });
            }
            return newHistory;
        });
    }, []);

    return { activityHistory, updateTodayRecord };
};