
import { useMemo } from 'react';
import { BadgeNFT, UserProfile, ActivityRecord, Post, Reel, ProofOfWorkoutPost, WorkoutRoutine } from '../types';
import { badgeData } from '../data/badges';

interface UserStats {
    // Milestones
    maxStepsInDay: number;
    totalSteps: number;
    maxDistanceInDay: number;
    totalDistance: number;
    powCount: number;
    verifiedPowCount: number;
    // Consistency
    activityStreak: number;
    maxWaterInDay: number;
    maxSleepInDay: number;
    totalMealLogs: number;
    mealLogStreak: number;
    // Social
    followerCount: number;
    followingCount: number;
    totalLikesReceived: number;
    totalCommentsMade: number;
    challengesCompleted: number;
    // Content
    postCount: number;
    reelCount: number;
    storyCount: number;
    routineCount: number;
    maxRoutineSaves: number;
    highlightCount: number;
    challengesCreated: number;
    // PRO
    usedAiCoach: number;
    aiImageGenerated: number;
    aiVideoGenerated: number;
    aiMealAnalyzed: number;
    aiPlanGenerated: number;
    usedFormAssistant: number;
    usedGhostRun: number;
    usedNeuralLink: number;
    usedQuantumHrv: number;
    joinedLiveClass: number;
    // Economy
    fitTokenBalance: number;
    nftSoldCount: number;
    stakedFit: number;
}

export const useAchievements = (
    profile: UserProfile | null,
    activityHistory: ActivityRecord[],
    posts: Post[],
    reels: Reel[],
    proofOfWorkouts: ProofOfWorkoutPost[],
    workoutRoutines: WorkoutRoutine[],
    fitTokenBalance: number,
    isProUser: boolean
) => {
    const userStats = useMemo((): UserStats => {
        if (!profile) {
            return {
                maxStepsInDay: 0,
                totalSteps: 0,
                maxDistanceInDay: 0,
                totalDistance: 0,
                powCount: 0,
                verifiedPowCount: 0,
                activityStreak: 0,
                maxWaterInDay: 0,
                maxSleepInDay: 0,
                totalMealLogs: 0,
                mealLogStreak: 0,
                followerCount: 0,
                followingCount: 0,
                totalLikesReceived: 0,
                totalCommentsMade: 0,
                challengesCompleted: 0,
                postCount: 0,
                reelCount: 0,
                storyCount: 0,
                routineCount: 0,
                maxRoutineSaves: 0,
                highlightCount: 0,
                challengesCreated: 0,
                usedAiCoach: 0,
                aiImageGenerated: 0,
                aiVideoGenerated: 0,
                aiMealAnalyzed: 0,
                aiPlanGenerated: 0,
                usedFormAssistant: 0,
                usedGhostRun: 0,
                usedNeuralLink: 0,
                usedQuantumHrv: 0,
                joinedLiveClass: 0,
                fitTokenBalance: 0,
                nftSoldCount: 0,
                stakedFit: 0,
            };
        }
        // --- Calculate Aggregate Stats ---
        const totalSteps = activityHistory.reduce((sum, record) => sum + record.steps, 0);
        const maxStepsInDay = Math.max(0, ...activityHistory.map(r => r.steps));
        const totalDistance = activityHistory.reduce((sum, record) => sum + record.distance, 0);
        const maxDistanceInDay = Math.max(0, ...activityHistory.map(r => r.distance));
        const maxWaterInDay = Math.max(0, ...activityHistory.map(r => r.water));
        const maxSleepInDay = Math.max(0, ...activityHistory.map(r => r.sleep));
        
        // Streak calculation
        let currentStreak = 0;
        if (activityHistory.length > 0) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            // Check if today's activity is logged
            const hasActivityToday = activityHistory.some(rec => new Date(rec.date).setHours(0,0,0,0) === today.getTime() && rec.steps > 0);
            if (hasActivityToday) {
                currentStreak = 1;
                for (let i = 0; i < activityHistory.length; i++) {
                    const recordDate = new Date(activityHistory[i].date);
                    const prevDate = new Date(today);
                    prevDate.setDate(today.getDate() - (i + 1));
                    recordDate.setHours(0,0,0,0);
                    prevDate.setHours(0,0,0,0);
                    
                    const correspondingRecord = activityHistory.find(r => new Date(r.date).setHours(0,0,0,0) === prevDate.getTime());

                    if (correspondingRecord && correspondingRecord.steps > 0) {
                        currentStreak++;
                    } else {
                        break; // Streak broken
                    }
                }
            }
        }


        const totalLikesReceived = 
            posts.reduce((sum, p) => sum + p.likes, 0) +
            reels.reduce((sum, r) => sum + r.likes, 0) +
            proofOfWorkouts.reduce((sum, p) => sum + p.likes, 0) +
            workoutRoutines.reduce((sum, r) => sum + r.likes, 0);

        const myRoutines = workoutRoutines.filter(r => r.user.username === profile.username);
        const maxRoutineSaves = Math.max(0, ...myRoutines.map(r => r.savesCount));

        return {
            maxStepsInDay,
            totalSteps,
            maxDistanceInDay,
            totalDistance,
            powCount: proofOfWorkouts.length,
            verifiedPowCount: proofOfWorkouts.filter(p => p.isVerified).length,
            activityStreak: currentStreak,
            maxWaterInDay,
            maxSleepInDay,
            // Resetting simulated values to 0 to ensure real user progression
            totalMealLogs: 0, 
            mealLogStreak: 0,
            followerCount: profile.followers,
            followingCount: profile.following.length,
            totalLikesReceived,
            totalCommentsMade: 0,
            challengesCompleted: 0,
            postCount: posts.filter(p => p.author === profile.username).length,
            reelCount: reels.filter(r => r.user === profile.username).length,
            storyCount: 0, 
            routineCount: myRoutines.length,
            maxRoutineSaves,
            highlightCount: profile.highlights?.length || 0,
            challengesCreated: 0,
            usedAiCoach: 0,
            aiImageGenerated: 0,
            aiVideoGenerated: 0,
            aiMealAnalyzed: 0,
            aiPlanGenerated: 0,
            usedFormAssistant: 0,
            usedGhostRun: 0,
            usedNeuralLink: 0,
            usedQuantumHrv: 0,
            joinedLiveClass: 0,
            fitTokenBalance, // Real balance from App state
            nftSoldCount: 0,
            stakedFit: 0,
        };
    }, [profile, activityHistory, posts, reels, proofOfWorkouts, workoutRoutines, fitTokenBalance, isProUser]);

    const earnedBadgeIds = useMemo(() => {
        const earnedIds = new Set<string>();

        badgeData.forEach(badge => {
            const { type, value } = badge.condition;
            let isEarned = false;

            switch (type) {
                case 'stepsInDay': isEarned = userStats.maxStepsInDay >= value; break;
                case 'totalSteps': isEarned = userStats.totalSteps >= value; break;
                case 'distanceInDay': isEarned = userStats.maxDistanceInDay >= value; break;
                case 'totalDistance': isEarned = userStats.totalDistance >= value; break;
                case 'powCount': isEarned = userStats.powCount >= value; break;
                case 'verifiedPowCount': isEarned = userStats.verifiedPowCount >= value; break;
                case 'activityStreak': isEarned = userStats.activityStreak >= value; break;
                case 'waterInDay': isEarned = userStats.maxWaterInDay >= value; break;
                case 'sleepInDay': isEarned = userStats.maxSleepInDay >= value; break;
                case 'mealLogs': isEarned = userStats.totalMealLogs >= value; break;
                case 'mealLogStreak': isEarned = userStats.mealLogStreak >= value; break;
                case 'followerCount': isEarned = userStats.followerCount >= value; break;
                case 'followingCount': isEarned = userStats.followingCount >= value; break;
                case 'totalLikesReceived': isEarned = userStats.totalLikesReceived >= value; break;
                case 'commentsMade': isEarned = userStats.totalCommentsMade >= value; break;
                case 'challengeCompleted': isEarned = userStats.challengesCompleted >= value; break;
                case 'postCount': isEarned = userStats.postCount >= value; break;
                case 'reelCount': isEarned = userStats.reelCount >= value; break;
                case 'storyCount': isEarned = userStats.storyCount >= value; break;
                case 'routineCount': isEarned = userStats.routineCount >= value; break;
                case 'routineSaves': isEarned = userStats.maxRoutineSaves >= value; break;
                case 'highlightCount': isEarned = userStats.highlightCount >= value; break;
                case 'challengeCreated': isEarned = userStats.challengesCreated >= value; break;
                case 'usedAiCoach': isEarned = userStats.usedAiCoach >= value; break;
                case 'aiImageGenerated': isEarned = userStats.aiImageGenerated >= value; break;
                case 'aiVideoGenerated': isEarned = userStats.aiVideoGenerated >= value; break;
                case 'aiMealAnalyzed': isEarned = userStats.aiMealAnalyzed >= value; break;
                case 'aiPlanGenerated': isEarned = userStats.aiPlanGenerated >= value; break;
                case 'usedFormAssistant': isEarned = userStats.usedFormAssistant >= value; break;
                case 'usedGhostRun': isEarned = userStats.usedGhostRun >= value; break;
                case 'usedNeuralLink': isEarned = userStats.usedNeuralLink >= value; break;
                case 'usedQuantumHrv': isEarned = userStats.usedQuantumHrv >= value; break;
                case 'joinedLiveClass': isEarned = userStats.joinedLiveClass >= value; break;
                case 'fitTokenEarned': isEarned = userStats.fitTokenBalance > 0 && userStats.fitTokenBalance >= value; break;
                case 'fitTokenBalance': isEarned = userStats.fitTokenBalance >= value; break;
                case 'stakedFit': isEarned = userStats.stakedFit >= value; break;
                // NFT count logic will be handled below
                case 'nftSoldCount': isEarned = userStats.nftSoldCount >= value; break;
                default: break;
            }

            if (isEarned) {
                earnedIds.add(badge.id);
            }
        });
        
        // Handle NFT-related badges separately
        const earnedBadgesSoFar = badgeData.filter(b => earnedIds.has(b.id));
        if (earnedBadgesSoFar.length >= 5) earnedIds.add('e005');
        if (earnedBadgesSoFar.some(b => b.rarity === 'Rare' || b.rarity === 'Epic' || b.rarity === 'Legendary')) earnedIds.add('e006');
        if (earnedBadgesSoFar.some(b => b.rarity === 'Epic' || b.rarity === 'Legendary')) earnedIds.add('e007');
        if (earnedBadgesSoFar.some(b => b.rarity === 'Legendary')) earnedIds.add('e008');


        return earnedIds;
    }, [userStats]);

    const getBadgeProgress = (badge: BadgeNFT): { current: number; goal: number } | null => {
        const { type, value } = badge.condition;
        const current = (userStats as any)[type];
        if (typeof current === 'number') {
            return { current, goal: value };
        }
        return null;
    };

    return { earnedBadgeIds, getBadgeProgress, userStats };
};
