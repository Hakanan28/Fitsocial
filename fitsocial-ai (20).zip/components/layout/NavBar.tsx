
import React from 'react';
import { ModalType, Page } from '../../types';
import { useTranslation } from '../../hooks/i18n';

interface NavBarProps {
    currentPage: Page;
    setCurrentPage: (page: Page) => void;
}

const NavButton: React.FC<{
    id: Page;
    label: string;
    icon: React.ReactNode;
    activeIcon: React.ReactNode;
    isActive: boolean;
    onClick: () => void;
}> = ({ id, label, icon, activeIcon, isActive, onClick }) => {
    return (
        <button
            id={`nav-${id}`}
            className={`group flex-1 flex flex-col items-center justify-center h-full relative cursor-pointer transition-all duration-200 active:scale-95`}
            onClick={onClick}
        >
            {/* Top Active Indicator Line */}
            {isActive && (
                <div className="absolute top-0 w-8 h-1 bg-emerald-500 rounded-b-full shadow-[0_0_10px_#10b981]"></div>
            )}

            {/* Icon */}
            <div className={`relative mb-1 transition-colors duration-300 ${isActive ? 'text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.4)]' : 'text-gray-500 group-hover:text-gray-300'}`}>
                {isActive ? activeIcon : icon}
            </div>

            {/* Label */}
            <span className={`text-[10px] font-semibold tracking-wide transition-colors duration-300 ${isActive ? 'text-white' : 'text-gray-600 group-hover:text-gray-400'}`}>
                {label}
            </span>
        </button>
    );
};

interface GroupNavProps {
    openModal: (modal: ModalType) => void;
    activeTab: 'chats' | 'calls' | 'discover' | 'profile';
    onTabChange: (tab: 'chats' | 'calls' | 'discover' | 'profile') => void;
}

export const GroupNav: React.FC<GroupNavProps> = ({ openModal, activeTab, onTabChange }) => {
    
    const NavItem: React.FC<{
        label: string;
        icon: React.ReactNode;
        isActive: boolean;
        onClick: () => void;
    }> = ({ label, icon, isActive, onClick }) => (
        <button onClick={onClick} className={`flex flex-col items-center justify-center gap-2 transition-colors ${isActive ? 'text-white' : 'text-slate-400 hover:text-slate-200'}`}>
            {isActive ? (
                <div className="bg-slate-700/80 p-3 rounded-2xl">{icon}</div>
            ) : (
                icon
            )}
            <span className={`text-sm font-semibold ${isActive ? 'font-bold' : ''}`}>{label}</span>
        </button>
    );
    
    return (
        <footer className="absolute bottom-0 left-0 right-0 z-50 p-4 pointer-events-auto">
            <div className="flex justify-around items-center h-24 bg-[#272a35] rounded-3xl shadow-lg border border-slate-700/50">
                <NavItem 
                    label="Chats" 
                    icon={<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="currentColor"><path d="M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18zM16 11H8V9h8v2zm-2-3H8V6h6v2z"/></svg>} 
                    isActive={activeTab === 'chats'} 
                    onClick={() => onTabChange('chats')} 
                />
                <NavItem 
                    label="Calls" 
                    icon={<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.02.74-.25 1.02l-2.2 2.2z"/></svg>}
                    isActive={activeTab === 'calls'} 
                    onClick={() => onTabChange('calls')} 
                />
                <NavItem 
                    label="Discover" 
                    icon={<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7.5L14.5 14.5L12 16.5L9.5 14.5L12 7.5Z" stroke="none" fill="currentColor"/></svg>}
                    isActive={activeTab === 'discover'} 
                    onClick={() => onTabChange('discover')} 
                />
                <NavItem 
                    label="Profile" 
                    icon={<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>}
                    isActive={activeTab === 'profile'} 
                    onClick={() => onTabChange('profile')} 
                />
            </div>
        </footer>
    );
};


const NavBar: React.FC<NavBarProps> = ({ currentPage, setCurrentPage }) => {
    const { t } = useTranslation();

    const navItems = [
        { 
            id: Page.Home, 
            label: t('nav.home') as string, 
            // Outline Icon
            icon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
            // Filled/Active Icon
            activeIcon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2L3 9v11a2 2 0 0 0 2 2h5v-7h4v7h5a2 2 0 0 0 2-2V9L12 2z"/></svg>
        },
        { 
            id: Page.Explore, 
            label: t('nav.explore') as string, 
            icon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>,
            activeIcon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
        },
        { 
            id: Page.Reels, 
            label: t('nav.reels') as string, 
            icon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M7 3v18"/><path d="M3 7.5h4"/><path d="M3 12h18"/><path d="M3 16.5h4"/><path d="M17 3v18"/><path d="M17 7.5h4"/><path d="M17 16.5h4"/></svg>,
            activeIcon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M18 3a5 5 0 0 0-5 5v8a5 5 0 0 0 10 0V8a5 5 0 0 0-5-5Z"/><path d="M6 3a5 5 0 0 0-5 5v8a5 5 0 0 0 10 0V8a5 5 0 0 0-5-5Z"/></svg> 
        },
        { 
            id: Page.Exercise, 
            label: t('nav.exercise') as string, 
            icon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6.5 6.5 11 11"/><path d="m21 21-1-1"/><path d="m3 3 1 1"/><path d="m18 22 4-4"/><path d="m6 2 4 4"/><path d="m3 10 7-7"/><path d="m14 21 7-7"/></svg>,
            activeIcon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12.4 2.7l.9 1.5L15 3l-.2 1.7 1.5.9-1.5.9.2 1.7-1.7-1.2-.9 1.5-.9-1.5-1.7 1.2.2-1.7-1.5-.9 1.5-.9-.2-1.7 1.7 1.2.9-1.5zM4 12a8 8 0 0 1 16 0v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-6z"/></svg> 
        },
        { 
            id: Page.Profile, 
            label: t('nav.profile') as string, 
            icon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/></svg>,
            activeIcon: <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M20 21a8 8 0 1 0-16 0"/><circle cx="12" cy="8" r="5"/></svg> 
        },
    ];

    return (
        <nav className="fixed bottom-0 left-0 z-[60] w-full safe-area-pb bg-[#0f1115]/95 backdrop-blur-xl border-t border-white/5 shadow-[0_-10px_30px_rgba(0,0,0,0.5)]">
            <div className="flex justify-around items-center w-full h-[70px] max-w-screen-lg mx-auto px-2">
                {navItems.map(item => (
                    <NavButton
                        key={item.id}
                        id={item.id}
                        label={item.label}
                        icon={item.icon}
                        activeIcon={item.activeIcon}
                        isActive={currentPage === item.id}
                        onClick={() => setCurrentPage(item.id)}
                    />
                ))}
            </div>
        </nav>
    );
};

export default NavBar;
