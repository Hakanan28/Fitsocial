
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';

interface NeuralLinkModalProps {
    closeModal: () => void;
}

const NeuralLinkModal: React.FC<NeuralLinkModalProps> = ({ closeModal }) => {
    const [focus, setFocus] = useState(0);
    const [recovery, setRecovery] = useState(0);
    
    useEffect(() => {
        // Animate the bars on mount
        setTimeout(() => setFocus(78), 100);
        setTimeout(() => setRecovery(92), 100);
    }, []);

    return (
        <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4 animate-fadeIn" onClick={closeModal}>
            <div className="bg-gradient-to-br from-[#1f2937] to-[#0f172a] border-2 border-green-500 w-full max-w-xs p-6 rounded-2xl shadow-2xl shadow-green-900/50 text-center animate-slideIn" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-extrabold text-green-400 mb-4" style={{textShadow: '0 0 8px #10B981'}}>🧠 Neural Link Analysis</h3>
                <p className="text-sm text-gray-300 mb-6">Real-time brainwave readings for today's session.</p>
                <div className="space-y-4">
                    <div className="bg-gray-900/50 p-4 rounded-xl border border-green-700/50">
                        <span className="text-xl font-semibold text-white">Lifting Focus</span>
                        <span className="text-5xl font-extrabold text-yellow-400 block my-2">{focus}%</span>
                        <div className="h-2 rounded-full bg-black/50 border border-green-700"><div className="bg-yellow-400 h-full rounded-full transition-all duration-1000 ease-out" style={{ width: `${focus}%` }}></div></div>
                    </div>
                     <div className="bg-gray-900/50 p-4 rounded-xl border border-green-700/50">
                        <span className="text-xl font-semibold text-white">Recovery Readiness</span>
                        <span className="text-5xl font-extrabold text-green-400 block my-2">{recovery}%</span>
                        <div className="h-2 rounded-full bg-black/50 border border-green-700"><div className="bg-green-500 h-full rounded-full transition-all duration-1000 ease-out" style={{ width: `${recovery}%` }}></div></div>
                    </div>
                </div>
                <button onClick={closeModal} className="w-full bg-green-500 text-black py-3 rounded-xl font-bold mt-6 hover:bg-green-400 transition-colors transform hover:scale-105">Close</button>
            </div>
        </div>
    );
};

export default NeuralLinkModal;