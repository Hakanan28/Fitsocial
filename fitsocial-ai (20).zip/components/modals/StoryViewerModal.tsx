
import React, { useState, useEffect, useRef } from 'react';
import { ModalType, Story, UserProfile } from '../../types';

interface StoryViewerModalProps {
    stories: Story[];
    closeModal: () => void;
    startIndex?: number;
    onClose?: (username: string) => void;
    openModal: (modal: ModalType, data?: any) => void;
    users: UserProfile[];
}

const StoryViewerModal: React.FC<StoryViewerModalProps> = ({ stories, closeModal, startIndex = 0, onClose, openModal, users }) => {
    const [currentIndex, setCurrentIndex] = useState(startIndex);
    const [progress, setProgress] = useState(0);
    const [isMuted, setIsMuted] = useState(true);
    const [showVolumeIcon, setShowVolumeIcon] = useState(false);
    
    const videoRef = useRef<HTMLVideoElement>(null);
    const audioRef = useRef<HTMLAudioElement>(null);
    const volumeIconTimer = useRef<number | null>(null);
    const progressTimerRef = useRef<number | null>(null);


    const handleClose = () => {
        if (onClose && stories.length > 0) {
            onClose(stories[0].user);
        }
        closeModal();
    };
    
    const currentStory = stories[currentIndex];

    const handleViewProfile = () => {
        if (!currentStory) return;
        const user = users.find(u => u.username === currentStory.user);
        if (user) {
            openModal(ModalType.Profile, user);
        }
    };

    useEffect(() => {
        if (!currentStory) return;
        
        const storyIsMuted = currentStory.mediaType === 'video' ? (currentStory.isMuted ?? false) : true;
        setIsMuted(storyIsMuted);

        setProgress(0);
        if (progressTimerRef.current) clearInterval(progressTimerRef.current);

        const duration = currentStory.mediaType === 'video' ? 15000 : 5000;
        const interval = duration / 100;
        
        progressTimerRef.current = window.setInterval(() => {
            setProgress(p => p + 1);
        }, interval);

        return () => {
            if (progressTimerRef.current) clearInterval(progressTimerRef.current);
        };
    }, [currentIndex, currentStory]);

    useEffect(() => {
        const audio = audioRef.current;
        const video = videoRef.current;
        if (currentStory.music && audio) {
            audio.src = currentStory.music.src;
            if (video) {
                audio.currentTime = video.currentTime;
            }
            audio.play().catch(e => console.error("Audio autoplay failed:", e));
        } else if (audio) {
            audio.pause();
            audio.src = '';
        }

        return () => { audio?.pause(); };
    }, [currentStory]);
    
    useEffect(() => {
        if(videoRef.current) {
            videoRef.current.muted = isMuted || !!currentStory.music;
        }
        if(audioRef.current) {
            audioRef.current.muted = isMuted;
        }
    }, [isMuted, currentStory.music]);


    useEffect(() => {
        if (progress >= 100) {
            if (currentIndex < stories.length - 1) {
                setCurrentIndex(i => i + 1);
            } else {
                handleClose();
            }
        }
    }, [progress, currentIndex, stories.length, handleClose]);

    const handleNext = (e?: React.MouseEvent) => {
        e?.stopPropagation();
         if (currentIndex < stories.length - 1) {
            setCurrentIndex(i => i + 1);
        } else {
            handleClose();
        }
    };

    const handlePrev = (e?: React.MouseEvent) => {
        e?.stopPropagation();
        if (currentIndex > 0) {
            setCurrentIndex(i => i - 1);
        }
    };

    const handleMediaClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (currentStory.mediaType === 'video' || currentStory.music) {
            setIsMuted(prev => !prev);
            setShowVolumeIcon(true);
            if (volumeIconTimer.current) clearTimeout(volumeIconTimer.current);
            volumeIconTimer.current = window.setTimeout(() => setShowVolumeIcon(false), 1000);
        }
    };
    
    if (!currentStory) return null;

    return (
        <div className="fixed inset-0 bg-black/90 z-[100] flex flex-col items-center justify-center p-0 animate-fadeIn" onClick={handleClose}>
            <audio ref={audioRef} loop />
            <div className="w-full h-full rounded-none md:rounded-2xl shadow-2xl flex flex-col relative overflow-hidden bg-black" onClick={e => e.stopPropagation()}>
                {/* Progress Bars */}
                <div className="absolute top-2 left-2 right-2 flex space-x-1 z-20">
                    {stories.map((_, index) => (
                        <div key={index} className="flex-1 h-1 bg-white/30 rounded-full">
                            <div className="h-1 bg-white rounded-full transition-all duration-100 ease-linear" style={{ width: `${index < currentIndex ? 100 : index === currentIndex ? progress : 0}%` }}></div>
                        </div>
                    ))}
                </div>
                
                {/* Header */}
                <div className="absolute top-5 left-4 z-20 flex items-center cursor-pointer" onClick={handleViewProfile}>
                    <img src={currentStory.avatarImage || `https://placehold.co/100x100/333/FFF?text=${currentStory.user.charAt(0)}`} alt={currentStory.user} className="w-8 h-8 rounded-full object-cover mr-2" />
                    <span className="text-white font-bold text-sm drop-shadow-lg">{currentStory.user}</span>
                </div>
                
                 {/* Close Button */}
                <button onClick={handleClose} className="absolute top-3 right-3 text-white text-3xl z-20 drop-shadow-lg">&times;</button>

                {/* Media Container */}
                <div className="w-full h-full flex items-center justify-center relative" onClick={handleMediaClick}>
                    {currentStory.mediaType === 'video' ? (
                        <video 
                            ref={videoRef}
                            key={currentStory.mediaUrl}
                            src={currentStory.mediaUrl}
                            className={`w-full h-full object-contain ${currentStory.filter || ''}`}
                            autoPlay
                            playsInline
                        />
                    ) : (
                        <img src={currentStory.mediaUrl} alt="Story content" className={`w-full h-full object-contain ${currentStory.filter || ''}`} />
                    )}
                     {currentStory.textOverlays?.map(overlay => (
                        <div
                            key={overlay.id}
                            className="absolute p-2 text-2xl font-bold drop-shadow-lg"
                            style={{
                                left: `${overlay.position.x}px`,
                                top: `${overlay.position.y}px`,
                                color: overlay.color,
                            }}
                        >
                            {overlay.text}
                        </div>
                    ))}
                </div>

                {showVolumeIcon && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/20 pointer-events-none animate-fadeIn">
                        <div className="bg-black/50 p-4 rounded-full">
                            {isMuted ? (
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" x2="17" y1="9" y2="15"/><line x1="17" x2="23" y1="9" y2="15"/></svg>
                            ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>
                            )}
                        </div>
                    </div>
                )}
                
                {/* Navigation */}
                <div className="absolute inset-0 flex justify-between z-10">
                    <div className="w-1/3 h-full" onClick={handlePrev}></div>
                    <div className="w-1/3 h-full"></div> {/* Center area doesn't navigate */}
                    <div className="w-1/3 h-full" onClick={handleNext}></div>
                </div>
            </div>
        </div>
    );
};

export default StoryViewerModal;
