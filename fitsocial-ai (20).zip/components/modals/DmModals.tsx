
import React, { useState } from 'react';
import { ModalType, DmMessage, UserProfile, ChallengeExercise } from '../../types';
import { translateText } from '../../services/geminiService';
import { useTranslation } from '../../hooks/i18n';

interface DmModalsProps {
    closeModal: () => void;
    openModal: (modal: ModalType, data?: any) => void;
    initialView: ModalType.DmList | ModalType.DmChat;
    language: string;
    users: UserProfile[];
    currentUser: UserProfile;
    messages: Record<string, DmMessage[]>;
    onSendMessage: (recipient: string, text: string) => void;
}

const ChatBubble: React.FC<{
    msg: DmMessage, 
    appLanguage: string, 
    onAcceptChallenge: (id: number) => void, 
    openModal: (modal: ModalType, data?: any) => void 
}> = ({ msg, appLanguage, onAcceptChallenge, openModal }) => {
    const { t } = useTranslation();
    const [showTranslation, setShowTranslation] = useState(true);
    const isUser = msg.sender === 'user';

    const renderSharedContent = (content: any, isNft: boolean) => {
        const author = isNft ? content.owner.username : content.author;
        const avatar = isNft ? content.owner.avatar : `https://placehold.co/50x50/333/FFF?text=${content.avatarText}`;
        const mediaUrl = isNft ? content.imageUrl : content.mediaUrl;
        const mediaType = isNft ? 'image' : content.mediaType;
        const modalType = isNft ? ModalType.ProductDetail : (content.type === 'reel' ? ModalType.ReelPlayer : ModalType.PostDetail);
        
        return (
             <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} w-full my-2`}>
                <div className={`max-w-[280px] w-full rounded-2xl overflow-hidden bg-[#2a2a2a] border ${isUser ? 'border-green-900' : 'border-gray-700'} shadow-lg`}>
                    <div className="flex items-center p-3 bg-black/20 gap-2">
                        <img src={avatar} alt={author} className="w-6 h-6 rounded-full border border-gray-600" />
                        <span className="text-xs font-bold text-white truncate">{author}</span>
                        <span className="text-[10px] text-gray-400 ml-auto">{isNft ? 'Shared NFT' : 'Shared Post'}</span>
                    </div>
                    
                    <div onClick={() => openModal(modalType, content)} className="relative aspect-square bg-black cursor-pointer group">
                        {mediaType === 'video' ? (
                            <video src={mediaUrl} className="w-full h-full object-cover" muted loop />
                        ) : (
                            <img src={mediaUrl} alt="Shared content" className="w-full h-full object-cover" />
                        )}
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                             <div className="bg-white/20 backdrop-blur-md p-3 rounded-full">
                                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                             </div>
                        </div>
                    </div>

                    <div className="p-3">
                        <p className="text-xs text-gray-300 line-clamp-2">
                            {isNft ? (
                                <>
                                    <span className="font-bold text-white block">{content.name}</span>
                                    <span className="text-[10px]">{content.collection}</span>
                                </>
                            ) : (
                                <><span className="font-bold text-white">{author}</span> {content.caption}</>
                            )}
                        </p>
                    </div>

                    <div className="p-3 pt-0">
                        <button 
                            onClick={() => openModal(modalType, content)}
                            className="w-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold py-2 rounded-lg transition-colors"
                        >
                            {isNft ? 'View NFT' : 'View Post'}
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    if (msg.type === 'post_share' && msg.sharedPost) {
        return renderSharedContent(msg.sharedPost, false);
    }
    
    if (msg.type === 'nft_share' && msg.sharedNft) {
        return renderSharedContent(msg.sharedNft, true);
    }

    if (msg.type === 'challenge' && msg.challengeDetails) {
        const { amount, duration, exercises, status } = msg.challengeDetails;
        
        return (
            <div className={`flex flex-col items-center w-full`}>
                <div className={`p-4 rounded-2xl w-full max-w-xs shadow-md bg-gray-800 border border-orange-500 my-2`}>
                    <h4 className="font-bold text-orange-400 text-center text-lg mb-2">🏆 Stake Challenge!</h4>
                    <div className="space-y-2 text-sm">
                        <div className="flex justify-between"><span className="text-gray-400">Amount:</span><span className="font-bold text-yellow-400">{amount} $FIT</span></div>
                        <div className="flex justify-between"><span className="text-gray-400">Duration:</span><span className="font-bold text-white">{duration} days</span></div>
                        <div className="border-t border-gray-700 pt-2 mt-2">
                             <p className="text-gray-400 font-semibold mb-1">Exercises:</p>
                             <ul className="space-y-1 text-xs list-disc list-inside">
                                {exercises.map((ex, index) => (
                                    <li key={index} className="text-white">
                                        {ex.exercise.name}: <span className="font-mono text-gray-300">{ex.sets}x{ex.reps}</span>
                                    </li>
                                ))}
                             </ul>
                        </div>
                    </div>
                    <div className="border-t border-gray-600 mt-3 pt-3 text-center">
                        {status === 'pending' && (
                            isUser ? (
                                <p className="text-sm font-semibold text-yellow-500 animate-pulse">Challenge Sent! Waiting...</p>
                            ) : (
                                <button
                                    onClick={() => onAcceptChallenge(msg.id)}
                                    className="w-full bg-green-600 text-white font-bold py-2 rounded-xl hover:bg-green-700 transition-all transform hover:scale-105"
                                >
                                    Accept Challenge
                                </button>
                            )
                        )}
                        {status === 'accepted' && (
                             <p className="text-sm font-bold text-green-400">🔥 Challenge Accepted! Let's go!</p>
                        )}
                         {status === 'declined' && (
                             <p className="text-sm font-semibold text-red-500">Challenge Declined.</p>
                        )}
                    </div>
                </div>
            </div>
        );
    }

    const languageFlags: { [key: string]: string } = { en: '🇺🇸', es: '🇪🇸', tr: '🇹🇷', de: '🇩🇪', fr: '🇫🇷', };
    const sourceLang = isUser ? languageFlags[appLanguage] || '🏳️' : languageFlags['en'];
    const targetLang = isUser ? languageFlags['en'] : (languageFlags[appLanguage] || '🏳️');
    const toggleTranslation = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (msg.translated && !msg.isTranslating) setShowTranslation(p => !p);
    };

    return (
        <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
            <div className={`p-3 rounded-2xl max-w-xs shadow-md ${isUser ? 'bg-green-600 text-white rounded-br-none' : 'bg-gray-700 text-white rounded-bl-none'}`}>
                <p className="text-white text-sm">{msg.text}</p>
                {showTranslation && (
                    <div className={`text-xs mt-1 border-t ${isUser ? 'border-green-800 text-green-200' : 'border-gray-600 text-gray-400'} pt-1`}>
                        {msg.isTranslating ? ( <span className="italic animate-pulse">{t('dms.translating') as string}</span> ) : msg.translated ? ( <p>{msg.translated}</p> ) : null}
                    </div>
                )}
            </div>
            {msg.translated && !msg.isTranslating && (
                 <button onClick={toggleTranslation} className="text-xs text-gray-500 hover:text-white mt-1 px-2 py-0.5 rounded-full bg-gray-800/80 transition-colors">
                    {showTranslation ? t('dms.hideTranslation') as string : t('dms.showTranslation', { sourceLang, targetLang }) as string}
                </button>
            )}
        </div>
    )
};

const DmModals: React.FC<DmModalsProps> = ({ closeModal, openModal, initialView, language, users, currentUser, messages, onSendMessage }) => {
    const { t } = useTranslation();
    const [view, setView] = useState<'list' | 'chat'>(initialView === ModalType.DmChat ? 'chat' : 'list');
    
    // Initialize with the first person the user is following, or null
    const firstFollowing = users.find(u => currentUser.following.includes(u.username));
    const [chatUser, setChatUser] = useState<UserProfile | null>(firstFollowing || null);
    
    // Local mock messages + Global messages merge
    const [localMessages, setLocalMessages] = useState<DmMessage[]>([
        { id: 1, sender: 'other', type: 'text', text: "Hi! I finally managed to lift 100kg!", translated: "Merhaba! Nihayet 100kg kaldırmayı başardım!" },
        { id: 2, sender: 'user', type: 'text', text: "Tebrikler, harika iş! 🔥", translated: "Congratulations, great job! 🔥" },
    ]);
    const [input, setInput] = useState('');

    const currentChatMessages = chatUser ? [...localMessages, ...(messages[chatUser.username] || [])].sort((a, b) => a.id - b.id) : [];


    const supportedLanguages: { [key: string]: string } = {
        en: 'English',
        es: 'Spanish',
        tr: 'Turkish',
        de: 'German',
        fr: 'French',
    };

    const handleSend = async () => {
        if (!input.trim() || !chatUser) return;
        
        // Send to parent App state
        onSendMessage(chatUser.username, input);
    
        const newMessageId = Date.now();
        
        // For local optimistic UI update (optional if parent updates fast enough, but good for translation demo)
        const userMessage: DmMessage = {
            id: newMessageId,
            sender: 'user',
            type: 'text',
            text: input,
            isTranslating: true,
        };
        
        // We push to local state just for the translation demo effect, in a real app we'd wait for the backend
        setLocalMessages(prev => [...prev, userMessage]);
        setInput('');
    
        try {
            const translation = await translateText(input, 'English');
             setLocalMessages(prev => prev.map(msg => msg.id === newMessageId ? { ...msg, translated: translation, isTranslating: false } : msg));
        } catch (e) {
            console.error(e);
             setLocalMessages(prev => prev.map(msg => msg.id === newMessageId ? { ...msg, translated: 'Translation failed', isTranslating: false } : msg));
        }
    };

    const handleSelectChat = (user: UserProfile) => {
        setChatUser(user);
        // Clear local demo messages when switching chats in a real app, but keeping for demo
        setView('chat');
    };
    
    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) {
            closeModal();
        }
    };
    
    const handleSendChallenge = (details: { amount: number; duration: number; exercises: ChallengeExercise[]; }) => {
         // In a real app, this would go through onSendMessage with a special type
         // For this demo, we'll just push to local
        const newChallengeMessage: DmMessage = {
            id: Date.now(),
            sender: 'user',
            type: 'challenge',
            challengeDetails: {
                ...details,
                status: 'pending'
            },
        };
        setLocalMessages(prev => [...prev, newChallengeMessage]);
    };

    const handleAcceptChallenge = (messageId: number) => {
        setLocalMessages(prevMessages =>
            prevMessages.map(msg =>
                msg.id === messageId && msg.challengeDetails
                    ? {
                        ...msg,
                        challengeDetails: { ...msg.challengeDetails, status: 'accepted' },
                      }
                    : msg
            )
        );
        const acceptanceMessage: DmMessage = {
            id: Date.now(),
            sender: 'user',
            type: 'text',
            text: `I've accepted the challenge! Let the games begin.`
        };
         setLocalMessages(prev => [...prev, acceptanceMessage]);
    };

    const chatContacts = users.filter(u => currentUser.following.includes(u.username) || u.following.includes(currentUser.username));

    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-0" onClick={handleOverlayClick}>
            <div className="bg-[#1E1E1E] w-full max-w-md h-full md:h-[80vh] md:max-h-[700px] rounded-none md:rounded-2xl shadow-2xl flex flex-col animate-slideIn">
                {view === 'list' && (
                    <>
                        <header className="flex justify-between items-center p-4 border-b border-gray-700"><h3 className="text-xl font-bold text-white">{t('dms.messages') as string}</h3><button onClick={closeModal} className="text-gray-400 hover:text-white text-2xl">&times;</button></header>
                        <div className="flex-1 p-2 space-y-2 overflow-y-auto">
                           {chatContacts.map(contact => (
                                <div key={contact.username} className="flex items-center p-3 hover:bg-gray-700 rounded-xl cursor-pointer transition-colors" onClick={() => handleSelectChat(contact)}>
                                    <img className="w-12 h-12 rounded-full object-cover" src={contact.avatarImage} alt={contact.username}/>
                                    <div className="ml-3 flex-1">
                                        <div className="flex justify-between">
                                            <h4 className="font-bold text-white text-lg">{contact.username}</h4>
                                            {messages[contact.username] && messages[contact.username].length > 0 && <span className="text-xs text-green-400 font-bold">New</span>}
                                        </div>
                                        <p className="text-sm text-gray-400 truncate">{messages[contact.username]?.slice(-1)[0]?.text || "Click to chat"}</p>
                                    </div>
                                </div>
                            ))}
                             {chatContacts.length === 0 && (
                                <p className="text-center text-gray-500 pt-10">{t('dms.noConversations') as string}</p>
                            )}
                        </div>
                    </>
                )}
                {view === 'chat' && chatUser && (
                    <>
                         <header className="flex justify-between items-center p-4 border-b border-gray-700">
                            <button onClick={() => setView('list')} className="text-green-400 text-md font-semibold hover:text-green-300 transition-all">{t('common.back') as string}</button>
                             <div className="text-center">
                                <h3 className="text-xl font-bold text-white">{chatUser.username}</h3>
                             </div>
                             <div className="w-10"></div>
                        </header>
                        <div className="flex-1 p-4 flex flex-col space-y-3 overflow-y-auto">
                           {currentChatMessages.map((msg) => <ChatBubble key={msg.id} msg={msg} appLanguage={language} onAcceptChallenge={handleAcceptChallenge} openModal={openModal} />)}
                        </div>
                        <footer className="p-4 border-t border-gray-700 flex space-x-2">
                            <button onClick={() => openModal(ModalType.StakeChallenge, { onStake: handleSendChallenge })} className="bg-orange-500 text-white px-3 py-1.5 rounded-xl font-bold shadow-md hover:bg-orange-600 transition-colors transform hover:scale-105 text-sm flex-shrink-0">{t('dms.stake') as string}</button>
                            <input value={input} onChange={e => setInput(e.target.value)} onKeyPress={e => e.key === 'Enter' && handleSend()} type="text" className="flex-1 p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:ring-2 focus:ring-green-500/50 focus:border-green-500 transition-all" placeholder={t('dms.placeholder') as string}/>
                            <button onClick={handleSend} className="bg-green-500 text-white px-4 rounded-xl font-bold shadow-md">{t('dms.send') as string}</button>
                        </footer>
                    </>
                )}
            </div>
        </div>
    );
};

export default DmModals;
