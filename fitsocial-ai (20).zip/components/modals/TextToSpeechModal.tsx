import React, { useState, useRef, useEffect } from 'react';
import Modal from '../ui/Modal';
import { generateSpeech, analyzeContent } from '../../services/geminiService';
import { decode, decodeAudioData, pcmToWavBlob } from '../../utils/audioUtils';

interface TextToSpeechModalProps {
    closeModal: () => void;
}

const voices = [
    // Female
    { name: 'Kore', gender: 'female', description: 'Clear, standard' },
    { name: 'Zephyr', gender: 'female', description: 'Calm, soothing' },
    { name: 'Aoede', gender: 'female', description: 'Warm, friendly' },
    { name: 'Autonoe', gender: 'female', description: 'Bright, upbeat' },
    { name: 'Leda', gender: 'female', description: 'Gentle, soft' },
    { name: 'Erinome', gender: 'female', description: 'Grounded, natural' },
    { name: 'Callirrhoe', gender: 'female', description: 'Melodic, pleasant' },
    { name: 'Despina', gender: 'female', description: 'Crisp, articulate' },
    { name: 'Laomedeia', gender: 'female', description: 'Elegant, poised' },
    { name: 'Pulcherrima', gender: 'female', description: 'Rich, smooth' },
    { name: 'Sadachbia', gender: 'female', description: 'Energetic, youthful' },
    { name: 'Schedar', gender: 'female', description: 'Mature, authoritative' },
    { name: 'Sulafat', gender: 'female', description: 'Expressive, narrative' },
    { name: 'Umbriel', gender: 'female', description: 'Mysterious, deep' },
    { name: 'Vindemiatrix', gender: 'female', description: 'Formal, precise' },
    // Male
    { name: 'Puck', gender: 'male', description: 'Deep, resonant' },
    { name: 'Charon', gender: 'male', description: 'Authoritative, mature' },
    { name: 'Fenrir', gender: 'male', description: 'Energetic, youthful' },
    { name: 'Orus', gender: 'male', description: 'Crisp, professional' },
    { name: 'Alnilam', gender: 'male', description: 'Storyteller, engaging' },
    { name: 'Gacrux', gender: 'male', description: 'Formal, articulate' },
    { name: 'Iapetus', gender: 'male', description: 'Steady, reassuring' },
    { name: 'Achernar', gender: 'male', description: 'Clear, bright' },
    { name: 'Achird', gender: 'male', description: 'Warm, friendly' },
    { name: 'Algenib', gender: 'male', description: 'Strong, confident' },
    { name: 'Algieba', gender: 'male', description: 'Smooth, narrative' },
    { name: 'Enceladus', gender: 'male', description: 'Calm, measured' },
    { name: 'Zubenelgenubi', gender: 'male', description: 'Unique, deep' },
    { name: 'Rasalgethi', gender: 'male', description: 'Gravelly, wise' },
    { name: 'Sadaltager', gender: 'male', description: 'Standard, neutral' },
];

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = error => reject(error);
    });
};


const TextToSpeechModal: React.FC<TextToSpeechModalProps> = ({ closeModal }) => {
    const [text, setText] = useState('Hello! This is a demonstration of Gemini\'s text-to-speech capabilities. You can also upload an image to have the AI read the text from it.');
    const [isLoading, setIsLoading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [activeTab, setActiveTab] = useState<'pre-built' | 'clone'>('pre-built');
    const [genderFilter, setGenderFilter] = useState<'all' | 'male' | 'female'>('all');
    const [selectedVoice, setSelectedVoice] = useState(voices[0].name);
    
    // Image State
    const [imageFiles, setImageFiles] = useState<File[]>([]);
    const [imagePreviews, setImagePreviews] = useState<string[]>([]);
    
    // Audio Player State
    const [audioData, setAudioData] = useState<{ buffer: AudioBuffer; rawPcm: Uint8Array } | null>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);

    const audioContextRef = useRef<AudioContext | null>(null);
    const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
    const progressAnimationRef = useRef<number | null>(null);
    const playbackStartTimeRef = useRef(0);
    const playbackPausedTimeRef = useRef(0);

    const handleGenerate = async () => {
        if (!text.trim() && imageFiles.length === 0) return;

        setIsLoading(true);
        setError(null);
        setAudioData(null);
        setIsPlaying(false);

        try {
            let combinedText = text.trim();

            if (imageFiles.length > 0) {
                setLoadingMessage('Extracting text from images...');
                const extractedTexts = await Promise.all(
                    imageFiles.map(async (file) => {
                        const base64Data = await fileToBase64(file);
                        return await analyzeContent("Extract all text from this image. Return only the text.", base64Data, file.type);
                    })
                );
                const imageText = extractedTexts.filter(Boolean).join('\n\n');
                if (imageText) {
                    combinedText = combinedText ? `${imageText}\n\n---\n\n${combinedText}` : imageText;
                    setText(combinedText);
                }
            }

            if (!combinedText) {
                throw new Error("No text found in images or text box.");
            }

            setLoadingMessage('Generating audio...');
            const base64Audio = await generateSpeech(combinedText, selectedVoice);
            if (base64Audio) {
                const rawPcm = decode(base64Audio);
                if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
                }
                const ctx = audioContextRef.current;
                const audioBuffer = await decodeAudioData(rawPcm, ctx, 24000, 1);
                setAudioData({ buffer: audioBuffer, rawPcm });
                // Automatically play after generation
                playAudio(audioBuffer);
            } else {
                throw new Error("API did not return audio data.");
            }
        } catch (err) {
            console.error("TTS Error:", err);
            setError("Failed to generate speech. The selected voice may not support the language or content.");
        } finally {
            setIsLoading(false);
            setLoadingMessage('');
        }
    };

    const playAudio = (buffer: AudioBuffer, offset: number = 0) => {
        if (sourceNodeRef.current) {
            sourceNodeRef.current.stop();
        }
        if (!audioContextRef.current) return;

        const ctx = audioContextRef.current;
        const source = ctx.createBufferSource();
        sourceNodeRef.current = source;
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start(0, offset);
        
        playbackStartTimeRef.current = ctx.currentTime - offset;
        setIsPlaying(true);

        source.onended = () => {
            if (sourceNodeRef.current === source) {
                setIsPlaying(false);
                cancelAnimationFrame(progressAnimationRef.current!);
                // If it ended naturally, reset progress
                if (ctx.currentTime - playbackStartTimeRef.current >= buffer.duration - 0.1) {
                    setProgress(0);
                    playbackPausedTimeRef.current = 0;
                }
            }
        };
        
        const updateProgress = () => {
            if (ctx.state === 'running' && sourceNodeRef.current) {
                const elapsedTime = ctx.currentTime - playbackStartTimeRef.current;
                setProgress((elapsedTime / buffer.duration) * 100);
                progressAnimationRef.current = requestAnimationFrame(updateProgress);
            }
        };
        updateProgress();
    };

    const pauseAudio = () => {
        if (sourceNodeRef.current && audioContextRef.current) {
            playbackPausedTimeRef.current = audioContextRef.current.currentTime - playbackStartTimeRef.current;
            sourceNodeRef.current.stop();
            sourceNodeRef.current = null;
            setIsPlaying(false);
            if(progressAnimationRef.current) cancelAnimationFrame(progressAnimationRef.current);
        }
    };

    const handlePlayPause = () => {
        if (isPlaying) {
            pauseAudio();
        } else if (audioData) {
            playAudio(audioData.buffer, playbackPausedTimeRef.current);
        }
    };

    const handleScrubberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!audioData) return;
        const newProgress = parseFloat(e.target.value);
        setProgress(newProgress);
        
        const newTime = (newProgress / 100) * audioData.buffer.duration;
        playbackPausedTimeRef.current = newTime;
        if (isPlaying) {
            playAudio(audioData.buffer, newTime);
        }
    };

    const handleDownload = () => {
        if (!audioData) return;
        const blob = pcmToWavBlob(audioData.rawPcm, 24000, 1);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'fitsocial-ai-speech.wav';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleImageFiles = (files: FileList | null) => {
        if (!files) return;
        const newFiles = Array.from(files);
        setImageFiles(prev => [...prev, ...newFiles]);
        const newPreviews = newFiles.map(file => URL.createObjectURL(file));
        setImagePreviews(prev => [...prev, ...newPreviews]);
    };

    const removeImage = (index: number) => {
        setImageFiles(prev => prev.filter((_, i) => i !== index));
        setImagePreviews(prev => {
            URL.revokeObjectURL(prev[index]);
            return prev.filter((_, i) => i !== index);
        });
    };

    useEffect(() => {
        return () => {
            imagePreviews.forEach(url => URL.revokeObjectURL(url));
            if (progressAnimationRef.current) cancelAnimationFrame(progressAnimationRef.current);
        };
    }, [imagePreviews]);

    const filteredVoices = voices.filter(v => genderFilter === 'all' || v.gender === genderFilter);

    return (
        <Modal title="🗣️ AI Text & Image to Speech" closeModal={closeModal} show={true}>
            <div className="space-y-4 max-h-[75vh] flex flex-col">
                <div className="flex-shrink-0">
                    <div className="flex bg-gray-900 p-1 rounded-lg border border-gray-700">
                        <button onClick={() => setGenderFilter('all')} className={`flex-1 py-1 text-xs rounded ${genderFilter === 'all' ? 'bg-gray-700' : 'hover:bg-gray-800'}`}>All</button>
                        <button onClick={() => setGenderFilter('male')} className={`flex-1 py-1 text-xs rounded ${genderFilter === 'male' ? 'bg-gray-700' : 'hover:bg-gray-800'}`}>Male</button>
                        <button onClick={() => setGenderFilter('female')} className={`flex-1 py-1 text-xs rounded ${genderFilter === 'female' ? 'bg-gray-700' : 'hover:bg-gray-800'}`}>Female</button>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-3 max-h-32 overflow-y-auto pr-2">
                        {filteredVoices.map(voice => (
                            <button key={voice.name} onClick={() => setSelectedVoice(voice.name)} className={`p-2 rounded-xl border-2 text-left transition-all ${selectedVoice === voice.name ? 'border-sky-500 bg-sky-900/50' : 'border-gray-700 bg-gray-800 hover:border-gray-600'}`}>
                                <p className="font-bold text-xs text-white">{voice.name}</p>
                                <p className="text-[10px] text-gray-400">{voice.description}</p>
                            </button>
                        ))}
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto pr-1 space-y-4">
                    <div>
                        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-2">Read Text from Images (Optional)</label>
                        <div className="flex flex-wrap gap-2">
                            {imagePreviews.map((preview, index) => (
                                <div key={index} className="relative w-16 h-16 rounded-md overflow-hidden">
                                    <img src={preview} className="w-full h-full object-cover" />
                                    <button onClick={() => removeImage(index)} className="absolute top-0 right-0 bg-black/50 text-white rounded-full p-0.5 m-0.5">&times;</button>
                                </div>
                            ))}
                            <label className="w-16 h-16 rounded-md border-2 border-dashed border-gray-600 flex items-center justify-center cursor-pointer hover:border-sky-500">
                                <span className="text-2xl text-gray-500">+</span>
                                <input type="file" multiple accept="image/*" onChange={(e) => handleImageFiles(e.target.files)} className="hidden" />
                            </label>
                        </div>
                    </div>
                    
                    <textarea
                        value={text}
                        onChange={(e) => setText(e.target.value)}
                        placeholder="Or type text here to generate audio..."
                        rows={4}
                        className="w-full p-3 bg-gray-900 text-white rounded-xl border border-gray-700 focus:border-sky-500 transition-colors"
                        disabled={isLoading}
                    />
                </div>

                <div className="flex-shrink-0 space-y-3 pt-2 border-t border-gray-800">
                    {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                    
                    {audioData && !isLoading && (
                        <div className="bg-gray-900/50 p-3 rounded-xl border border-gray-700 space-y-3 animate-fadeIn">
                            <div className="flex items-center gap-3">
                                <button onClick={handlePlayPause} className="bg-sky-500 text-white rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                                    {isPlaying ? <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg> : <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>}
                                </button>
                                <input
                                    type="range"
                                    min="0"
                                    max="100"
                                    value={progress}
                                    onChange={handleScrubberChange}
                                    className="w-full h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-sky-400"
                                />
                                <button onClick={handleDownload} className="text-gray-400 hover:text-white" title="Download WAV">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                                </button>
                            </div>
                        </div>
                    )}

                    <button
                        onClick={handleGenerate}
                        disabled={isLoading}
                        className="w-full py-3 bg-sky-600 text-white font-bold rounded-xl hover:bg-sky-500 transition-colors disabled:bg-gray-500 flex items-center justify-center gap-2"
                    >
                        {isLoading ? (
                            <>
                                <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                                <span>{loadingMessage || 'Generating...'}</span>
                            </>
                        ) : (
                            <span>Generate & Play</span>
                        )}
                    </button>
                </div>
            </div>
        </Modal>
    );
};

export default TextToSpeechModal;
