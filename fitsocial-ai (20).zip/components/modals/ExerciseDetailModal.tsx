import React, { useState } from 'react';
import { Exercise } from '../../types';
import { useTranslation } from '../../hooks/i18n';

// --- React Component ---
const ExerciseDetailModal: React.FC<{ closeModal: () => void; modalData: Exercise; }> = ({ closeModal, modalData }) => {
    // --- State and Hooks ---
    const { t } = useTranslation();
    const [sets, setSets] = useState(3);
    const [reps, setReps] = useState(10);
    
    // --- Data and Translation ---
    const { name, primaryMuscles, secondaryMuscles } = modalData;

    return (
        <div className="fixed inset-0 bg-black z-[150] flex flex-col animate-fadeIn">
            {/* Header */}
            <header className="flex-shrink-0 flex items-center p-4 border-b border-gray-700 bg-[#121212]">
                <h2 className="text-xl font-bold text-white text-center flex-1">{name}</h2>
                <button onClick={closeModal} className="text-gray-400 text-2xl">×</button>
            </header>

            {/* Content */}
            <main className="flex-1 bg-gray-900 overflow-y-auto p-4">
                <div className="animate-fadeIn space-y-6">
                    <section>
                        <h3 className="text-lg font-bold text-green-400 mb-2">Çalışan Kaslar</h3>
                        <div className="text-sm">
                            <p><strong className="text-gray-200">Birincil:</strong> <span className="text-gray-300">{primaryMuscles.join(', ')}</span></p>
                            <p><strong className="text-gray-200">İkincil:</strong> <span className="text-gray-300">{secondaryMuscles.join(', ')}</span></p>
                        </div>
                    </section>
                    <section className="bg-gray-800 p-4 rounded-xl">
                        <h3 className="text-lg font-bold text-green-400 mb-3 text-center">Antrenman Kurulumu</h3>
                        <div className="flex justify-around items-center">
                            <div className="text-center">
                                <label className="text-sm text-gray-400">Set</label>
                                <div className="flex items-center gap-4 mt-1">
                                    <button onClick={() => setSets(s => Math.max(1, s - 1))} className="w-8 h-8 rounded-full bg-gray-700 text-white font-bold">-</button>
                                    <span className="text-2xl font-bold text-white w-8 text-center">{sets}</span>
                                    <button onClick={() => setSets(s => s + 1)} className="w-8 h-8 rounded-full bg-gray-700 text-white font-bold">+</button>
                                </div>
                            </div>
                             <div className="text-center">
                                <label className="text-sm text-gray-400">Tekrar</label>
                                <div className="flex items-center gap-4 mt-1">
                                    <button onClick={() => setReps(r => Math.max(1, r - 1))} className="w-8 h-8 rounded-full bg-gray-700 text-white font-bold">-</button>
                                    <span className="text-2xl font-bold text-white w-8 text-center">{reps}</span>
                                    <button onClick={() => setReps(r => r + 1)} className="w-8 h-8 rounded-full bg-gray-700 text-white font-bold">+</button>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </main>
        </div>
    );
};

export default ExerciseDetailModal;