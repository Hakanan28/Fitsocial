import React, { useState, useRef, useEffect } from 'react';
import { ModalType, Reel } from '../../types';
import { FILTERS } from '../../utils/filters'; // Re-using filters from story editor

interface ReelEditorModalProps {
    closeModal: () => void;
    openModal: (modal: ModalType, data?: any) => void;
    handleCreateReel: (reelData: Omit<Reel, 'id' | 'user' | 'likes' | 'comments' | 'isLiked'>) => void;
    modalData?: { mediaFile?: File };
}

type EditorTool = 'düzenle' | 'klipler' | 'ses' | 'metin' | 'çıkartmalar' | 'altyazılar' | 'seslendirme' | 'filtreler';

// --- Sub-Components for Tools ---

const FilterStrip: React.FC<{ videoPreview: string | null, onSelect: (filter: string) => void }> = ({ videoPreview, onSelect }) => (
    <div className="flex overflow-x-auto gap-3 px-4 h-28 items-center">
        {FILTERS.map(f => (
            // FIX: Use `f.name` as key since `f.id` does not exist on the filter object.
            <button key={f.name} onClick={() => onSelect(f.filter)} className="flex flex-col items-center gap-2 flex-shrink-0">
                <div className={`w-16 h-16 rounded-lg overflow-hidden border-2 border-transparent hover:border-green-500`}>
                    {videoPreview && <video src={videoPreview} style={{ filter: f.filter }} className="w-full h-full object-cover" muted />}
                </div>
                <span className="text-xs font-semibold text-gray-300">{f.name}</span>
            </button>
        ))}
    </div>
);

// --- Main Component ---

const ReelEditorModal: React.FC<ReelEditorModalProps> = ({ closeModal, openModal, handleCreateReel, modalData }) => {
    const [videoFile] = useState<File | null>(modalData?.mediaFile || null);
    const [videoPreview] = useState<string | null>(videoFile ? URL.createObjectURL(videoFile) : null);
    
    // Playback State
    const [isPlaying, setIsPlaying] = useState(true);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    
    const videoRef = useRef<HTMLVideoElement>(null);
    const timelineRef = useRef<HTMLDivElement>(null);

    // Editor State
    const [activeTool, setActiveTool] = useState<EditorTool | null>(null);
    const [selectedFilter, setSelectedFilter] = useState('none');
    
    // Final Details State
    const [caption, setCaption] = useState('');

    useEffect(() => {
        const video = videoRef.current;
        if (!video) return;

        const handleTimeUpdate = () => setCurrentTime(video.currentTime);
        const handleLoadedMetadata = () => setDuration(video.duration);

        video.addEventListener('timeupdate', handleTimeUpdate);
        video.addEventListener('loadedmetadata', handleLoadedMetadata);

        return () => {
            video.removeEventListener('timeupdate', handleTimeUpdate);
            video.removeEventListener('loadedmetadata', handleLoadedMetadata);
        };
    }, []);

    const togglePlay = () => {
        if (videoRef.current) {
            if (videoRef.current.paused) videoRef.current.play();
            else videoRef.current.pause();
            setIsPlaying(!videoRef.current.paused);
        }
    };
    
    const handleToolSelect = (tool: EditorTool) => {
        setActiveTool(current => current === tool ? null : tool);
    };

    const formatTime = (seconds: number) => {
        const floor = Math.floor(seconds);
        const min = Math.floor(floor / 60);
        const sec = floor % 60;
        return `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
    };
    
    const handleSubmit = () => {
        if (!videoPreview) return;
        // Simplified submission for UI demo
        handleCreateReel({
            caption: "My Edited Reel",
            subtitle: "Original Audio",
            videoSrc: videoPreview,
            videoType: videoFile?.type || 'video/mp4',
            savesCount: 0,
            shareCount: 0,
            watchTimePercentage: 0,
            timestamp: Date.now(),
            category: 'General',
            allowDownload: true,
        });
        closeModal();
    };

    const tools: { id: EditorTool, icon: React.ReactNode, label: string }[] = [
        { id: 'düzenle', icon: <svg width="24" height="24" viewBox="0 0 24 24"><path d="M6 22l-4-4 13-13 4 4-13 13zM22 6l-4-4-2.5 2.5 4 4L22 6z" fill="currentColor"/></svg>, label: 'Düzenle' },
        { id: 'klipler', icon: <svg width="24" height="24" viewBox="0 0 24 24"><path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="currentColor"/></svg>, label: 'Klipler ekle' },
        { id: 'ses', icon: <svg width="24" height="24" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" fill="currentColor"/></svg>, label: 'Ses' },
        { id: 'metin', icon: <svg width="24" height="24" viewBox="0 0 24 24"><path d="M2.5 4v3h5v12h3V7h5V4h-13zm19 5h-9v3h3v7h3v-7h3V9z" fill="currentColor"/></svg>, label: 'Metin' },
        { id: 'çıkartmalar', icon: <svg width="24" height="24" viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z" fill="currentColor"/></svg>, label: 'Çıkartmalar' },
        { id: 'altyazılar', icon: <svg width="24" height="24" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2zm0 4v2h4V8H4zm6 0v2h4V8h-4zm6 0v2h4V8h-4zM4 12v2h4v-2H4zm6 0v2h4v-2h-4zm6 0v2h4v-2h-4z" fill="currentColor"/></svg>, label: 'Altyazılar' },
        { id: 'seslendirme', icon: <svg width="24" height="24" viewBox="0 0 24 24"><path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z" fill="currentColor"/></svg>, label: 'Seslendirme' },
        { id: 'filtreler', icon: <svg width="24" height="24" viewBox="0 0 24 24"><path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-2c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8-8 3.582 8 8 8zm-4-8a4 4 0 108 0 4 4 0 10-8 0z" fill="currentColor"/></svg>, label: 'Filtreler' },
    ];

    return (
        <div className="fixed inset-0 z-[200] bg-[#111] flex flex-col font-sans">
            {/* Top Bar: Preview and Export */}
            <header className="flex-shrink-0 flex justify-between items-center p-3 border-b border-white/10">
                <button onClick={closeModal} className="p-2 text-white/70 hover:text-white transition-colors">
                    <svg width="24" height="24" viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" fill="currentColor"/></svg>
                </button>
                <div className="text-sm font-bold text-white">Video Düzenleyici</div>
                <button onClick={handleSubmit} className="bg-blue-600 text-white font-bold py-2 px-5 rounded-lg hover:bg-blue-500 transition-colors shadow-md">
                    Dışa Aktar
                </button>
            </header>
            
            {/* Main Content Area */}
            <div className="flex-1 flex flex-col overflow-hidden">
                {/* Video Preview */}
                <div className="flex-1 relative flex items-center justify-center bg-black min-h-[200px]">
                    {videoPreview && <video ref={videoRef} src={videoPreview} style={{ filter: selectedFilter }} className="max-w-full max-h-full" loop muted={false} />}
                    <div className="absolute bottom-2 left-2 right-2 flex items-center justify-center gap-4">
                        <button className="p-2 bg-black/50 rounded-full text-white"><svg width="20" height="20" viewBox="0 0 24 24"><path d="M10.53 5.47a.75.75 0 010 1.06L6.81 10.25H19a.75.75 0 010 1.5H6.81l3.72 3.72a.75.75 0 11-1.06 1.06l-5-5a.75.75 0 010-1.06l5-5a.75.75 0 011.06 0z" fill="currentColor"/></svg></button>
                        <button onClick={togglePlay} className="p-3 bg-black/50 rounded-full text-white">
                            {isPlaying ? <svg width="24" height="24" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" fill="currentColor"/></svg> : <svg width="24" height="24" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>}
                        </button>
                        <button className="p-2 bg-black/50 rounded-full text-white"><svg width="20" height="20" viewBox="0 0 24 24"><path d="M13.47 5.47a.75.75 0 011.06 0l5 5a.75.75 0 010 1.06l-5 5a.75.75 0 11-1.06-1.06L17.19 11.75H5a.75.75 0 010-1.5h12.19l-3.72-3.72a.75.75 0 010-1.06z" fill="currentColor"/></svg></button>
                    </div>
                </div>

                {/* Timeline and Controls */}
                <div className="bg-[#1a1a1a] flex-shrink-0 p-3 space-y-3 border-t border-white/10">
                    <div className="text-center text-xs font-mono text-white/50">{formatTime(currentTime)} / {formatTime(duration)}</div>
                    
                    <div ref={timelineRef} className="h-28 bg-black/30 rounded-lg p-2 space-y-1 relative overflow-hidden">
                        {/* Playhead */}
                        <div className="absolute top-0 bottom-0 w-1 bg-white z-10" style={{ left: `calc(${(currentTime / duration) * 100}% - 2px)` }}></div>
                        
                        {/* Video Track */}
                        <div className="h-12 bg-gray-700 rounded flex items-center px-2 text-[10px] text-gray-400">VIDEO</div>
                        {/* Audio Track */}
                        <div className="h-6 bg-gray-800 rounded flex items-center px-2 text-[10px] text-gray-500">SES</div>
                        {/* Text Track */}
                        <div className="h-6 bg-gray-800 rounded flex items-center px-2 text-[10px] text-gray-500">METİN</div>
                    </div>
                </div>
            </div>

            {/* Bottom Toolbar */}
            <div className="flex-shrink-0 bg-[#0A0A0A] border-t border-white/10 relative">
                {/* Secondary Tool Panel */}
                {activeTool && (
                    <div className="absolute bottom-full w-full h-32 bg-[#1C1C1C] border-t border-white/10 animate-slideInUp">
                        {activeTool === 'filtreler' && <FilterStrip videoPreview={videoPreview} onSelect={(filter) => setSelectedFilter(filter)} />}
                        {activeTool !== 'filtreler' && <div className="p-4 text-center text-sm text-gray-400">`{activeTool}` aracı için arayüz burada görünecek.</div>}
                    </div>
                )}
                
                {/* Main Tool Scroll View */}
                <div className="flex overflow-x-auto h-24 no-scrollbar">
                    {tools.map(tool => (
                        <button 
                            key={tool.id} 
                            onClick={() => handleToolSelect(tool.id)}
                            className={`flex flex-col items-center justify-center flex-shrink-0 w-24 gap-1 transition-colors ${activeTool === tool.id ? 'bg-white/10 text-white' : 'text-white/50 hover:bg-white/5'}`}
                        >
                            <div className="text-2xl">{tool.icon}</div>
                            <span className="text-xs">{tool.label}</span>
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ReelEditorModal;
