
import React, { useState } from 'react';
import Modal from '../ui/Modal';
import { DetailedUserProfileData, UserSport } from '../../types';
import { useTranslation } from '../../hooks/i18n';

interface DataEntryModalProps {
    closeModal: () => void;
    currentData: DetailedUserProfileData;
    onSave: (newData: DetailedUserProfileData) => void;
}

const SPORTS_LIST = [
    "Archery", "Badminton", "Baseball", "Basketball", "Boxing", "BJJ", "Calisthenics", 
    "Climbing", "Cricket", "CrossFit", "Cycling", "Dance", "Fencing", "Figure Skating", 
    "Fitness/Gym", "Football", "Golf", "Gymnastics", "Hiking", "Horse Riding", "Ice Hockey", 
    "Judo", "Karate", "Kickboxing", "MMA", "Muay Thai", "Pilates", "Powerlifting", "Rowing", 
    "Rugby", "Running", "Skateboarding", "Skiing", "Snowboarding", "Squash", "Surfing", 
    "Swimming", "Table Tennis", "Taekwondo", "Tennis", "Volleyball", "Wrestling", "Yoga"
];

const DataEntryModal: React.FC<DataEntryModalProps> = ({ closeModal, currentData, onSave }) => {
    const { t } = useTranslation();
    const [data, setData] = useState(currentData);
    const [selectedSport, setSelectedSport] = useState('');
    const [selectedIntensity, setSelectedIntensity] = useState<'Low' | 'Moderate' | 'High'>('Moderate');
    // Split duration state
    const [inputHours, setInputHours] = useState<number>(0);
    const [inputMinutes, setInputMinutes] = useState<number>(0);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { id, value } = e.target;
        // Determine if value should be number or string based on current type
        const parsedValue = (['height', 'weight', 'targetWeight', 'age', 'activity'].includes(id)) 
            ? parseFloat(value) || 0 
            : value;
            
        setData(prev => ({ ...prev, [id]: parsedValue }));
    };

    const handleAddSport = () => {
        const totalHoursPerWeek = inputHours + (inputMinutes / 60);

        if (selectedSport && totalHoursPerWeek > 0) {
            const newSport: UserSport = {
                id: Date.now().toString(),
                name: selectedSport,
                hoursPerWeek: parseFloat(totalHoursPerWeek.toFixed(2)),
                intensity: selectedIntensity
            };
            setData(prev => ({
                ...prev,
                activeSports: [...(prev.activeSports || []), newSport]
            }));
            setSelectedSport('');
            setInputHours(0);
            setInputMinutes(0);
            setSelectedIntensity('Moderate');
        }
    };

    const handleRemoveSport = (id: string) => {
        setData(prev => ({
            ...prev,
            activeSports: (prev.activeSports || []).filter(s => s.id !== id)
        }));
    };

    const handleSave = () => {
        onSave(data);
        closeModal();
    };

    // Helper component for input fields to reduce repetition
    const InputField = ({ id, label, type = "text", value }: { id: string, label: string, type?: string, value: any }) => (
        <div>
            <label htmlFor={id} className="text-xs font-bold text-gray-400 block mb-1.5 uppercase tracking-wide">{label}</label>
            <input 
                type={type} 
                id={id} 
                value={value} 
                onChange={handleChange} 
                className="w-full p-3 bg-gray-900/50 text-white rounded-xl border border-gray-700 focus:border-green-500 focus:ring-2 focus:ring-green-500/20 transition-all shadow-inner"
            />
        </div>
    );

    return (
        <Modal title="Update My Data" closeModal={closeModal} show={true}>
            <div className="space-y-6">
                
                {/* Section 1: Goal (Hero) */}
                <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-4 rounded-2xl border border-green-500/30 shadow-lg">
                    <label htmlFor="fitnessGoal" className="text-xs font-extrabold text-green-400 block mb-2 uppercase tracking-widest flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                        {t('profile.goals.title') as string}
                    </label>
                    <select id="fitnessGoal" value={data.fitnessGoal || 'maintenance'} onChange={handleChange} className="w-full p-3 bg-black/40 text-white rounded-xl border border-green-500/50 focus:border-green-400 focus:ring-0 transition-all font-bold text-lg cursor-pointer appearance-none hover:bg-black/60">
                        <option value="weight_loss">📉 {t('profile.goals.weight_loss') as string}</option>
                        <option value="muscle_gain">💪 {t('profile.goals.muscle_gain') as string}</option>
                        <option value="athletic">⚡ {t('profile.goals.athletic') as string}</option>
                        <option value="maintenance">🧘 {t('profile.goals.maintenance') as string}</option>
                    </select>
                </div>

                {/* Section 2: Physical Stats */}
                <div>
                    <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2 border-b border-gray-800 pb-2">
                        <span>📏</span> Physical Stats
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                        <InputField id="height" label="Height (cm)" type="number" value={data.height} />
                        <InputField id="weight" label="Current Weight (kg)" type="number" value={data.weight} />
                        <InputField id="targetWeight" label="Target Weight (kg)" type="number" value={data.targetWeight} />
                        <InputField id="age" label="Age" type="number" value={data.age} />
                    </div>
                </div>

                {/* Section 3: Sports & Activities (New Feature) */}
                <div className="bg-gray-800/30 p-4 rounded-xl border border-gray-700">
                    <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2 border-b border-gray-800 pb-2">
                        <span>🏅</span> Weekly Sports Activity
                    </h4>
                    
                    {/* List of Added Sports */}
                    {(data.activeSports && data.activeSports.length > 0) && (
                        <div className="flex flex-wrap gap-2 mb-4">
                            {data.activeSports.map(sport => (
                                <div key={sport.id} className="bg-green-900/30 text-green-300 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 border border-green-500/30">
                                    <div className="flex flex-col">
                                        <span>{sport.name}</span>
                                        <span className="text-[9px] text-green-200/70 font-normal">{sport.intensity} • {sport.hoursPerWeek.toFixed(1)}h/week</span>
                                    </div>
                                    <button onClick={() => handleRemoveSport(sport.id)} className="text-red-400 hover:text-red-300 font-bold text-lg leading-none ml-1">&times;</button>
                                </div>
                            ))}
                        </div>
                    )}

                    {/* Add Sport Form */}
                    <div className="flex flex-col gap-3">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Add Activity</label>
                        <select 
                            value={selectedSport} 
                            onChange={(e) => setSelectedSport(e.target.value)} 
                            className="w-full p-3 bg-gray-900 text-white rounded-lg text-sm border border-gray-600 focus:border-green-500"
                        >
                            <option value="">{t('profile.sports.selectSport') as string}</option>
                            {SPORTS_LIST.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                        
                        <div className="flex gap-2">
                             {/* Intensity Selector */}
                             <div className="w-1/3">
                                <label className="text-[10px] text-gray-400 font-bold mb-1 block text-center">INTENSITY</label>
                                <select 
                                    value={selectedIntensity} 
                                    onChange={(e) => setSelectedIntensity(e.target.value as any)} 
                                    className="w-full p-2.5 bg-gray-900 text-white rounded-lg text-xs border border-gray-600 focus:border-green-500 text-center"
                                >
                                    <option value="Low">Low</option>
                                    <option value="Moderate">Moderate</option>
                                    <option value="High">High</option>
                                </select>
                            </div>

                            <div className="flex-1">
                                <label className="text-[10px] text-gray-400 font-bold mb-1 block text-center">HOURS</label>
                                <div className="relative">
                                    <input 
                                        type="number" 
                                        min="0"
                                        value={inputHours} 
                                        onChange={(e) => setInputHours(Math.max(0, parseInt(e.target.value) || 0))} 
                                        className="w-full p-2.5 bg-gray-900 text-white rounded-lg text-sm border border-gray-600 text-center font-mono focus:border-green-500 focus:ring-1 focus:ring-green-500"
                                        placeholder="0"
                                    />
                                </div>
                            </div>
                            <div className="flex-1">
                                <label className="text-[10px] text-gray-400 font-bold mb-1 block text-center">MINS</label>
                                <div className="relative">
                                    <input 
                                        type="number"
                                        min="0" 
                                        max="59"
                                        value={inputMinutes} 
                                        onChange={(e) => setInputMinutes(Math.max(0, parseInt(e.target.value) || 0))} 
                                        className="w-full p-2.5 bg-gray-900 text-white rounded-lg text-sm border border-gray-600 text-center font-mono focus:border-green-500 focus:ring-1 focus:ring-green-500"
                                        placeholder="0"
                                    />
                                </div>
                            </div>
                        </div>
                        
                        <button onClick={handleAddSport} className="w-full bg-green-600 text-white px-4 py-2.5 rounded-lg font-bold text-xs hover:bg-green-500 shadow-md mt-1">
                            {t('profile.sports.add') as string} Activity
                        </button>
                        <p className="text-[10px] text-gray-500 text-right italic">* Total time per week</p>
                    </div>

                    {/* Specific Gym Routine Input (if Gym is selected) */}
                    {data.activeSports?.some(s => s.name === 'Fitness/Gym' || s.name === 'CrossFit' || s.name === 'Powerlifting') && (
                        <div className="mt-3">
                            <label htmlFor="gymExercises" className="text-xs font-bold text-blue-400 block mb-1.5 uppercase tracking-wide">
                                {t('profile.sports.gymDetails') as string}
                            </label>
                            <textarea 
                                id="gymExercises" 
                                value={data.gymExercises || ''} 
                                onChange={handleChange} 
                                placeholder="e.g., Squat (5x5), Bench Press, Deadlift, Lat Pulldown..." 
                                className="w-full p-3 bg-gray-900/50 text-white rounded-xl border border-blue-500/30 focus:border-blue-500 transition-all text-xs h-20 resize-none"
                            />
                        </div>
                    )}
                </div>

                {/* Section 4: Personal Details */}
                <div>
                    <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2 border-b border-gray-800 pb-2">
                        <span>👤</span> Personal Details
                    </h4>
                    <div className="grid grid-cols-1 gap-4">
                        <InputField id="dob" label="Date of Birth" type="date" value={data.dob || '1995-01-01'} />
                        <div>
                            <label htmlFor="gender" className="text-xs font-bold text-gray-400 block mb-1.5 uppercase tracking-wide">Gender</label>
                            <div className="flex p-1 bg-gray-900 rounded-xl">
                                {['male', 'female'].map(g => (
                                    <button 
                                        key={g}
                                        onClick={() => setData(prev => ({ ...prev, gender: g as any }))}
                                        className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${data.gender === g ? 'bg-gray-700 text-white shadow' : 'text-gray-500 hover:text-gray-300'}`}
                                    >
                                        {g.charAt(0).toUpperCase() + g.slice(1)}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Section 5: Lifestyle & Body Type */}
                <div>
                    <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2 border-b border-gray-800 pb-2">
                        <span>🧬</span> Lifestyle & Body Type
                    </h4>
                    
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="activity" className="text-xs font-bold text-gray-400 block mb-1.5 uppercase tracking-wide">Activity Level (Job/School)</label>
                            <select id="activity" value={data.activity} onChange={handleChange} className="w-full p-3 bg-gray-900/50 text-white rounded-xl border border-gray-700 focus:border-blue-500 transition-all text-sm">
                                <option value="1.2">Sedentary (Office job, mostly sitting)</option>
                                <option value="1.375">Lightly Active (Standing sometimes)</option>
                                <option value="1.55">Moderately Active (Active job)</option>
                                <option value="1.725">Very Active (Construction, physical labor)</option>
                                <option value="1.9">Extra Active (Athlete level daily)</option>
                            </select>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="somatotype" className="text-xs font-bold text-gray-400 block mb-1.5 uppercase tracking-wide">Body Type</label>
                                <select id="somatotype" value={data.somatotype || 'mesomorph'} onChange={handleChange} className="w-full p-3 bg-gray-900/50 text-white rounded-xl border border-gray-700 focus:border-blue-500 transition-all text-sm">
                                    <option value="ectomorph">Ectomorph</option>
                                    <option value="mesomorph">Mesomorph</option>
                                    <option value="endomorph">Endomorph</option>
                                </select>
                            </div>
                            <div>
                                <label htmlFor="fatDistribution" className="text-xs font-bold text-gray-400 block mb-1.5 uppercase tracking-wide">Fat Storage</label>
                                <select id="fatDistribution" value={data.fatDistribution || 'apple'} onChange={handleChange} className="w-full p-3 bg-gray-900/50 text-white rounded-xl border border-gray-700 focus:border-blue-500 transition-all text-sm">
                                    <option value="apple">Apple (Belly)</option>
                                    <option value="pear">Pear (Hips)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <button onClick={handleSave} className="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-green-500 transition-colors transform hover:scale-[1.02] active:scale-95">
                    Update Profile
                </button>
            </div>
        </Modal>
    );
};

export default DataEntryModal;