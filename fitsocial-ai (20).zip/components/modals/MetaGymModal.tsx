import React, { useState } from 'react';
import { UserProfile } from '../../types';

interface MetaGymModalProps {
    closeModal: () => void;
    users: UserProfile[];
    currentUser: UserProfile;
}

const MetaGymModal: React.FC<MetaGymModalProps> = ({ closeModal, users, currentUser }) => {
    const [chatMessages, setChatMessages] = useState([
        { user: 'Ahmet', text: 'Great session!' },
        { user: 'Elif', text: 'Feeling the burn 🔥' },
    ]);
    const [input, setInput] = useState('');
    const instructor = users.find(u => u.username === 'Elif')!;
    const participants = users.filter(u => ['Ahmet', 'Mehmet'].includes(u.username));

    const handleSendChat = () => {
        if(input.trim()) {
            setChatMessages(prev => [...prev, { user: currentUser.username, text: input }]);
            setInput('');
        }
    }

    return (
        <div className="fixed inset-0 bg-[#0A0A0A] z-[150] flex flex-col animate-fadeIn">
            <header className="flex justify-between items-center p-4 border-b border-indigo-700 bg-[#0A0A0A] shadow-lg shadow-indigo-900/50">
                <h2 className="text-xl font-bold text-indigo-400" style={{textShadow: '0 0 5px #4F46E5'}}>🧘‍♀️ Meta-Gym: Live Yoga Flow</h2>
                <button onClick={closeModal} className="text-red-500 font-bold hover:text-red-400 transition-colors">Exit Class</button>
            </header>
            <div className="flex-1 flex flex-col lg:flex-row p-2 gap-2 overflow-hidden">

                {/* Main Video Panel */}
                <div className="flex-1 flex flex-col items-center justify-center bg-gray-900 rounded-lg relative overflow-hidden">
                     <video 
                        src='https://firebasestorage.googleapis.com/v0/b/genai-downloads.appspot.com/o/developer-documentation%2Fvideos%2Fsigned-urls%2Fyoga.mp4?alt=media&token=f0146e4b-2d2c-4a37-9e4a-50b579f18731' 
                        autoPlay loop muted playsInline 
                        className="absolute inset-0 w-full h-full object-cover" 
                     />
                     <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                     <div className="absolute top-3 left-3 bg-red-600/80 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-2 animate-pulse">
                        <span className="w-2 h-2 bg-white rounded-full"></span>LIVE
                     </div>
                     <div className="absolute bottom-3 left-3 flex items-center gap-2">
                        <img src={instructor.avatarImage} alt={instructor.username} className="w-10 h-10 rounded-full border-2 border-indigo-400" />
                        <div>
                            <p className="font-bold text-white text-sm drop-shadow-lg">{instructor.username}</p>
                            <p className="text-xs text-gray-300 drop-shadow-lg">Instructor</p>
                        </div>
                     </div>
                </div>

                {/* Side Panel (Participants & Chat) */}
                <div className="w-full lg:w-80 bg-[#1E1E1E] rounded-lg flex flex-col p-3 gap-3 overflow-hidden">
                    {/* Participants */}
                    <div>
                        <h3 className="text-sm font-bold text-gray-400 uppercase mb-2">Participants ({participants.length + 1})</h3>
                        <div className="flex gap-3 overflow-x-auto pb-2">
                             {/* Your Avatar */}
                             <div className="text-center flex-shrink-0">
                                <img src={currentUser.avatarImage} alt="You" className="w-14 h-14 rounded-full border-2 border-green-500" />
                                <p className="text-xs font-semibold text-green-400 mt-1">You</p>
                             </div>
                            {participants.map(p => (
                                <div key={p.username} className="text-center flex-shrink-0">
                                    <img src={p.avatarImage} alt={p.username} className="w-14 h-14 rounded-full border-2 border-gray-600" />
                                    <p className="text-xs font-semibold text-gray-300 mt-1">{p.username}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Chat */}
                    <div className="flex-1 flex flex-col bg-gray-900/50 rounded-lg overflow-hidden">
                        <div className="flex-1 p-2 space-y-2 overflow-y-auto">
                            {chatMessages.map((msg, i) => (
                                <div key={i} className="text-xs">
                                    <span className="font-bold text-indigo-300 mr-1.5">{msg.user}:</span>
                                    <span className="text-gray-200">{msg.text}</span>
                                </div>
                            ))}
                        </div>
                        <div className="p-2 border-t border-gray-700">
                             <input 
                                value={input}
                                onChange={e => setInput(e.target.value)}
                                onKeyPress={e => e.key === 'Enter' && handleSendChat()}
                                placeholder="Send a message..."
                                className="w-full bg-gray-700 text-white text-xs rounded-full px-3 py-2 border border-transparent focus:outline-none focus:ring-1 focus:ring-indigo-500"
                            />
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default MetaGymModal;