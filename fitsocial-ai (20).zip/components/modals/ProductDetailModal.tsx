import React, { useEffect, useRef, useState } from 'react';
import { GearItem, NFT, ModalType } from '../../types';
import { initialNftData } from '../../data/nfts'; // For "New Arrivals"
import { allUsers } from '../../data/users'; // For "Top Creators"
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

interface ProductDetailModalProps {
    closeModal: () => void;
    item: GearItem | NFT;
    openModal: (modal: ModalType, data?: any) => void;
    isPreview?: boolean;
    customDesign?: { background?: string; themeColor?: string; fontStyle?: string } | null;
    customLayout?: any;
}

const CountdownTimer = () => {
    const calculateTimeLeft = () => {
        // Set a fixed future date for a consistent countdown
        const difference = +new Date("2025-10-26T23:59:59") - +new Date();
        let timeLeft: { [key: string]: number } = {};

        if (difference > 0) {
            timeLeft = {
                hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                minutes: Math.floor((difference / 1000 / 60) % 60),
                seconds: Math.floor((difference / 1000) % 60)
            };
        }
        return timeLeft;
    };

    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

    useEffect(() => {
        const timer = setTimeout(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);
        return () => clearTimeout(timer);
    });

    return (
        <span className="text-2xl font-black text-white tracking-wider">
            {String(timeLeft.hours).padStart(2, '0')}:
            {String(timeLeft.minutes).padStart(2, '0')}:
            {String(timeLeft.seconds).padStart(2, '0')}
        </span>
    );
}

const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ closeModal, item, openModal, isPreview = false }) => {
    if (!item) {
        return (
            <div className="fixed inset-0 bg-black/80 z-[300] flex items-center justify-center p-4">
                <div className="bg-red-900/50 border border-red-500 p-6 rounded-lg text-center">
                    <h2 className="text-white text-xl font-bold">Render Error</h2>
                    <p className="text-red-300 mt-2 text-sm">Product data is missing. Cannot display details.</p>
                    <button onClick={closeModal} className="mt-4 bg-red-500 text-white px-4 py-2 rounded">Close</button>
                </div>
            </div>
        );
    }

    const isGear = 'category' in item && item.category !== undefined;

    if (isGear) {
        return (
            <div className="fixed inset-0 bg-black z-[300] flex items-center justify-center p-4">
                <div className="bg-gray-800 p-6 rounded-lg text-center">
                    <h2 className="text-white text-xl">Gear Detail View</h2>
                    <p className="text-gray-400 mt-2">This design is specific to NFTs. A custom view for Gear is pending.</p>
                    <button onClick={closeModal} className="mt-4 bg-red-500 text-white px-4 py-2 rounded">Close</button>
                </div>
            </div>
        );
    }
    
    const nftItem = item as NFT;
    const chartRef = useRef<HTMLCanvasElement>(null);
    const chartInstance = useRef<any>(null);
    const canvasRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!canvasRef.current || !nftItem.imageUrl) return;

        // --- Three.js Setup ---
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setSize(canvasRef.current.clientWidth, canvasRef.current.clientHeight);
        canvasRef.current.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableZoom = false;
        controls.enablePan = false;

        const textureLoader = new THREE.TextureLoader();
        textureLoader.setCrossOrigin(''); // Handle CORS for imgur links
        
        const texture = textureLoader.load(
            nftItem.imageUrl,
            () => { // onLoad
                const aspectRatio = texture.image ? texture.image.width / texture.image.height : 1;
                const geometry = new THREE.PlaneGeometry(5, 5 / aspectRatio);
                const material = new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide });
                const plane = new THREE.Mesh(geometry, material);
                scene.add(plane);
                renderer.render(scene, camera); // Initial render
            },
            undefined, // onProgress
            (error) => { // onError
                console.error('An error happened loading the texture:', error);
            }
        );

        camera.position.z = 5;

        const animate = function () {
            requestAnimationFrame(animate);
            controls.update();
            renderer.render(scene, camera);
        };

        animate();

        // Handle resize
        const handleResize = () => {
            if (canvasRef.current) {
                renderer.setSize(canvasRef.current.clientWidth, canvasRef.current.clientHeight);
                camera.aspect = 1;
                camera.updateProjectionMatrix();
            }
        };
        window.addEventListener('resize', handleResize);

        // Cleanup
        return () => {
            window.removeEventListener('resize', handleResize);
            if (canvasRef.current) {
                canvasRef.current.removeChild(renderer.domElement);
            }
            renderer.dispose();
        };

    }, [nftItem.imageUrl]);

    const priceHistory = nftItem.priceHistory.length > 0 ? nftItem.priceHistory : [
        { time: 'TYPE', value: 18 }, { time: 'SX3D', value: 25 }, { time: 'S2180', value: 15 },
        { time: 'G3T.94', value: 22 }, { time: '6D.94', value: 20 }, { time: '1D3310', value: 24 },
    ];

    useEffect(() => {
        if (chartRef.current) {
            if (chartInstance.current) {
                chartInstance.current.destroy();
            }

            const ctx = chartRef.current.getContext('2d');
            if (ctx) {
                const gradient = ctx.createLinearGradient(0, 0, 0, 200);
                gradient.addColorStop(0, 'rgba(139, 92, 246, 0.4)');
                gradient.addColorStop(1, 'rgba(139, 92, 246, 0)');
                
                chartInstance.current = new (window as any).Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: priceHistory.map(p => p.time),
                        datasets: [{
                            data: priceHistory.map(p => p.value),
                            borderColor: '#a78bfa',
                            backgroundColor: gradient,
                            borderWidth: 2,
                            pointRadius: 0,
                            tension: 0.4,
                            fill: true,
                        }]
                    },
                    options: {
                         responsive: true, maintainAspectRatio: false,
                         scales: {
                            y: { display: false, min: 10, max: 30 },
                            x: { 
                                ticks: { color: '#6B7280', font: { size: 10, weight: 'bold' } }, 
                                grid: { color: 'rgba(55, 65, 81, 0.3)', drawBorder: false },
                                border: { display: false }
                            }
                         },
                         plugins: { 
                            legend: { display: false }, 
                            tooltip: { 
                                enabled: true,
                                backgroundColor: '#111827',
                                titleColor: '#fff',
                                bodyColor: '#a78bfa',
                                displayColors: false,
                            } 
                        }
                    }
                });
            }
        }
    }, [nftItem]);
    
    const rootClassName = isPreview
        ? "relative w-full h-full bg-[#0B0C10] font-sans overflow-y-auto"
        : "fixed inset-0 bg-[#0B0C10] z-[300] animate-fadeIn font-sans overflow-y-auto";

    return (
        <div className={rootClassName}>
            {/* Background Grid */}
            <div className="absolute inset-0 z-[-1] overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_90%_20%,_rgba(139,92,246,0.1)_0%,_transparent_40%)]"></div>
                <div 
                    className="absolute bottom-0 left-0 w-full h-1/2"
                    style={{
                        background: 'linear-gradient(transparent, #0B0C10 80%), radial-gradient(ellipse 80% 50% at 50% 100%, rgba(139, 92, 246, 0.15), transparent)',
                    }}
                ></div>
                <div 
                    className="absolute inset-0 bg-[length:60px_60px]"
                    style={{ backgroundImage: 'linear-gradient(to right, rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.02) 1px, transparent 1px)' }}
                ></div>
            </div>

            <header className="flex justify-between items-center px-8 py-4 border-b border-white/5 sticky top-0 bg-[#0B0C10]/80 backdrop-blur-xl z-20">
                <div className="flex items-center gap-4">
                    <button onClick={closeModal} className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10">
                         <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    </button>
                    <div className="flex items-center gap-2">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6.5 12L12 6.5L17.5 12L12 17.5L6.5 12Z" stroke="#38BDF8" strokeWidth="2" strokeLinejoin="round"/>
                            <path d="M12 17.5L17.5 23L23 17.5L17.5 12L12 17.5Z" fill="#818CF8"/>
                        </svg>
                        <h2 className="text-xl font-bold text-white">CRYPTOMINT</h2>
                    </div>
                </div>
                {!isPreview && (
                    <>
                        <div className="hidden lg:flex items-center gap-6 text-sm font-semibold text-gray-400">
                            <a href="#" className="hover:text-white transition-colors">Explore</a>
                            <a href="#" className="hover:text-white transition-colors">Market</a>
                            <a href="#" className="hover:text-white transition-colors">Create</a>
                        </div>
                        <div className="flex items-center gap-4">
                            <button className="bg-[#1F2129] border border-gray-700 text-white font-semibold py-2 px-5 rounded-full hover:bg-gray-800 transition-colors text-sm">
                                Connect Wallet
                            </button>
                            <button className="text-gray-400 hover:text-white transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                            </button>
                        </div>
                    </>
                )}
            </header>

            <main className="w-full max-w-7xl mx-auto px-8 py-10 space-y-12">
                <div className="lg:grid lg:grid-cols-10 lg:gap-12 lg:items-start">
                    {/* Left Column */}
                    <section className="lg:col-span-4 relative">
                        <div className="absolute -inset-2 bg-gradient-to-br from-purple-600/30 to-blue-600/30 blur-xl opacity-40 rounded-3xl"></div>
                        <div className="relative bg-[#15171e]/80 p-5 rounded-2xl border border-white/10 backdrop-blur-md shadow-2xl">
                            <div ref={canvasRef} className="aspect-square rounded-xl overflow-hidden bg-black mb-5 cursor-grab active:cursor-grabbing">
                                {/* 3D Canvas will be mounted here */}
                            </div>
                            {!isPreview && (
                                <div className="flex items-center gap-4">
                                    <button className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 text-white font-bold py-3 rounded-xl hover:opacity-90 transition-opacity shadow-lg">
                                        BUY NOW
                                    </button>
                                    <button className="p-3 rounded-full bg-gray-800 text-gray-400 hover:text-white transition-colors border border-gray-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                                    </button>
                                     <button onClick={() => openModal(ModalType.SharePost, { content: nftItem })} className="p-3 rounded-full bg-gray-800 text-gray-400 hover:text-white transition-colors border border-gray-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                                    </button>
                                </div>
                            )}
                        </div>
                    </section>
                    
                    {/* Right Column */}
                    <section className="lg:col-span-6 space-y-8 mt-12 lg:mt-0">
                         <div>
                            <h1 className="text-4xl lg:text-5xl font-black text-white">{nftItem.name}</h1>
                            <p className="text-lg text-slate-400 mt-2">by <span className="text-cyan-400 font-semibold cursor-pointer">@{nftItem.owner.username}</span></p>
                            <p className="text-md text-slate-500 mt-1">OWNER: <span className="text-slate-400 font-semibold cursor-pointer">@cryptkiner</span></p>
                         </div>

                         <div className="flex items-center justify-between">
                             <div>
                                <p className="text-5xl lg:text-6xl font-black text-white">{nftItem.price} <span className="text-4xl text-gray-400">ETH</span></p>
                                <p className="text-sm text-slate-400 mt-2">BEST OFFER {nftItem.bestOffer} ETH</p>
                             </div>
                             {!isPreview && (
                                <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-4 px-10 rounded-xl hover:opacity-90 transition-opacity shadow-lg shadow-purple-500/20">
                                    MAKE OFFER
                                </button>
                             )}
                         </div>

                         <div className="grid grid-cols-2 gap-4">
                             <div className="bg-[#15171e]/80 p-4 rounded-xl border border-white/10">
                                 <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider mb-1">Auction Ends In:</p>
                                 <CountdownTimer />
                             </div>
                             <div className="bg-[#15171e]/80 p-4 rounded-xl border border-white/10">
                                 <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider mb-1">Reserve Price:</p>
                                 <p className="text-2xl font-black text-white">6.0 ETH</p>
                             </div>
                         </div>

                         <div className="grid grid-cols-2 gap-4">
                             <div className="bg-[#15171e]/80 p-4 rounded-xl border border-white/10">
                                 <p className="text-[10px] text-cyan-400 uppercase font-bold tracking-wider mb-2">NEURAL LINK (AI CHAT)</p>
                                 <div className="text-xs space-y-1">
                                    <p><span className="text-blue-400">User:</span> <span className="text-gray-300">What is your origin?</span></p>
                                    <p><span className="text-green-400">AI:</span> <span className="text-gray-300">I am forged from digital fire and code...</span></p>
                                 </div>
                                  <button className="w-full text-right mt-1 text-cyan-400 opacity-50 hover:opacity-100">></button>
                             </div>
                             <div className="bg-[#15171e]/80 p-4 rounded-xl border border-white/10">
                                 <p className="text-[10px] text-green-400 uppercase font-bold tracking-wider mb-2">LIVE STAKING CONSOLE</p>
                                 <p className="text-[10px] text-gray-400 uppercase">YIELD:</p>
                                 <p className="text-2xl font-black text-green-400">+0.0124</p>
                                 <p className="text-[10px] text-gray-500">TOKEN/hr</p>
                             </div>
                         </div>
                    </section>
                </div>

                <div className="grid lg:grid-cols-10 gap-12">
                    <section className="lg:col-span-6">
                         <h3 className="font-bold text-white text-xl mb-4">Description</h3>
                         <div className="h-48">
                             <canvas ref={chartRef}></canvas>
                         </div>
                    </section>
                    <section className="lg:col-span-4">
                        <h3 className="font-bold text-white text-xl mb-4">Recent Bids</h3>
                        <div className="space-y-2">
                            {[
                                { user: { username: 'Dragon', avatar: 'https://placehold.co/100x100/A78BFA/FFFFFF?text=D' }, amount: 5.353, currency: 'ETH' },
                                { user: { username: 'Dragon', avatar: 'https://placehold.co/100x100/3B82F6/FFFFFF?text=D' }, amount: 11.453, currency: 'ETH' },
                                { user: { username: 'Legand', avatar: 'https://placehold.co/100x100/10B981/FFFFFF?text=L' }, amount: 5.316, currency: 'ETH' },
                            ].map((bid, i) => (
                                <div key={i} className="flex items-center justify-between p-3 bg-[#15171e]/50 border border-gray-800 rounded-lg">
                                    <div className="flex items-center gap-3">
                                        <img src={bid.user.avatar} alt={bid.user.username} className="w-8 h-8 rounded-full" />
                                        <span className="font-semibold text-sm text-white">{bid.user.username}</span>
                                    </div>
                                    <span className="font-mono text-sm text-cyan-400">{bid.amount} {bid.currency}</span>
                                </div>
                            ))}
                        </div>
                    </section>
                </div>

                <section>
                    <h3 className="font-bold text-white text-xl mb-4">New Arrivals</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 gap-6">
                        {[
                            {...initialNftData[3], price: 5.50, owner: {username: '@digitaldreamer'}}, 
                            {...initialNftData[4], price: 2.5, currency: 'ETH'},
                            {...initialNftData[1], price: 5.8, currency: 'ETH'}
                        ].map(nft => (
                            <div key={nft.id} onClick={() => !isPreview && openModal(ModalType.ProductDetail, nft)} className="bg-[#15171e] rounded-2xl overflow-hidden border border-gray-800 cursor-pointer group shadow-lg transition-all hover:-translate-y-1 hover:shadow-purple-900/20">
                                <img src={nft.imageUrl} className="w-full aspect-square object-cover transition-transform group-hover:scale-105"/>
                                <div className="p-4">
                                    <p className="text-xs text-slate-400 truncate">{(nft.owner as any).username}</p>
                                    <p className="text-sm font-bold text-white mt-1">{nft.price} {nft.currency}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

                <section>
                    <h3 className="font-bold text-white text-xl mb-4">Top Creators</h3>
                    <div className="space-y-3">
                        {[allUsers[3], allUsers[1]].map((user, i) => (
                            <div key={user.username} className="flex items-center justify-between p-3 bg-[#15171e]/50 border border-gray-800 rounded-lg">
                                <div className="flex items-center gap-3">
                                    <img src={user.avatarImage} alt={user.username} className="w-10 h-10 rounded-full" />
                                    <div>
                                        <p className="font-semibold text-sm text-white flex items-center gap-1.5">{user.username} {user.isVerified && <svg width="14" height="14" viewBox="0 0 24 24" fill="#38BDF8"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>}</p>
                                        <p className="text-xs text-gray-400">{(user.followers / 1000).toFixed(1)}K Followers</p>
                                    </div>
                                </div>
                                 {i === 0 && <div className="text-xs font-bold bg-blue-600/20 text-blue-300 border border-blue-500/30 px-2 py-1 rounded-md">Onaylı Yaratıcı</div>}
                            </div>
                        ))}
                    </div>
                </section>
            </main>
             {!isPreview && (
                <footer className="flex justify-between items-center px-8 py-6 border-t border-white/5 mt-8">
                    <div className="flex items-center gap-6 text-sm text-gray-500 font-semibold">
                        <a href="#" className="hover:text-white transition-colors">About Us</a>
                        <a href="#" className="hover:text-white transition-colors">Support</a>
                        <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
                    </div>
                    <div className="flex items-center gap-4">
                        <button onClick={() => openModal(ModalType.SharePost, { content: nftItem })} className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white hover:bg-blue-400 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                        </button>
                    </div>
                </footer>
            )}
        </div>
    );
};

export default ProductDetailModal;