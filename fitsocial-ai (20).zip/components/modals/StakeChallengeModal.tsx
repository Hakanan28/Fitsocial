
import React, { useState } from 'react';
import Modal from '../ui/Modal';

interface StakeChallengeModalProps {
    closeModal: () => void;
    currentBalance: number;
    onStake: (details: { amount: number; durationHours: number, task: string }) => void;
    openModal: (modal: any, data?: any) => void;
}

const StakeChallengeModal: React.FC<StakeChallengeModalProps> = ({ closeModal, currentBalance, onStake }) => {
    const [amount, setAmount] = useState(50);
    const [duration, setDuration] = useState(24);
    const [task, setTask] = useState('');

    const presets = [
        "50 Pushups in one go",
        "Run 5km under 25mins",
        "No sugar for 24 hours",
        "Plank for 3 minutes"
    ];

    const handleStake = () => {
        if (amount <= 0 || amount > currentBalance) {
            alert("Invalid amount or insufficient balance.");
            return;
        }
        if (!task.trim()) {
            alert("Please specify the challenge task.");
            return;
        }

        onStake({ amount, durationHours: duration, task: task });
        closeModal();
    };
    
    return (
        <Modal title="🏆 P2P Stake Challenge" closeModal={closeModal} show={true}>
            <div className="space-y-5 animate-fadeIn">
                <div className="bg-gradient-to-r from-orange-900/40 to-black p-4 rounded-xl border border-orange-500/30 flex items-center gap-4">
                    <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-2xl shadow-lg shadow-orange-500/20">⚔️</div>
                    <div>
                        <h3 className="text-white font-bold text-lg">Challenge a Friend</h3>
                        <p className="text-orange-200/70 text-xs">Winner takes the pool. Proof required.</p>
                    </div>
                </div>
                
                {/* Task Input */}
                <div>
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-2">The Challenge</label>
                    <input 
                        type="text" 
                        value={task} 
                        onChange={e => setTask(e.target.value)} 
                        placeholder="e.g. Max Pullups video" 
                        className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-orange-500 focus:ring-1 focus:ring-orange-500/50 transition-all font-medium"
                    />
                    <div className="flex gap-2 mt-2 overflow-x-auto scrollbar-hide">
                        {presets.map((p, i) => (
                            <button key={i} onClick={() => setTask(p)} className="whitespace-nowrap px-3 py-1 bg-gray-800 border border-gray-600 rounded-full text-[10px] text-gray-300 hover:bg-gray-700 hover:text-white transition-colors">
                                {p}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Amount Input */}
                <div>
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-2">Your Stake (Locked)</label>
                    <div className="relative">
                        <input 
                            type="number" 
                            value={amount} 
                            onChange={e => setAmount(Number(e.target.value))} 
                            className="w-full p-3 bg-black border border-orange-500/50 rounded-xl text-white font-mono text-lg focus:outline-none focus:border-orange-400"
                        />
                        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-orange-400 font-black">$FIT</span>
                    </div>
                    <p className="text-[10px] text-gray-500 mt-1 text-right">Balance: {currentBalance} $FIT</p>
                </div>

                {/* Duration Slider */}
                <div>
                    <div className="flex justify-between text-xs font-bold text-gray-400 uppercase mb-2">
                        <span>Time Limit</span>
                        <span className="text-white">{duration} Hours</span>
                    </div>
                    <input 
                        type="range" 
                        min="1" 
                        max="72" 
                        value={duration} 
                        onChange={e => setDuration(Number(e.target.value))} 
                        className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                    />
                </div>

                {/* Total Pool Preview */}
                <div className="bg-gray-800 p-3 rounded-xl border border-gray-700 flex justify-between items-center">
                    <span className="text-xs text-gray-400">Total Pot Potential</span>
                    <span className="text-xl font-black text-white">{amount * 2} <span className="text-orange-500">$FIT</span></span>
                </div>

                <button onClick={handleStake} className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-4 rounded-xl font-black text-lg shadow-[0_0_20px_rgba(234,88,12,0.4)] hover:shadow-[0_0_30px_rgba(234,88,12,0.6)] transition-all transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2">
                    <span>🚀 SEND CHALLENGE</span>
                </button>
            </div>
        </Modal>
    );
};

export default StakeChallengeModal;
