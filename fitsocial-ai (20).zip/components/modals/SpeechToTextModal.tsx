import React, { useState, useRef, useEffect } from 'react';
import Modal from '../ui/Modal';
import { analyzeContent } from '../../services/geminiService';

interface SpeechToTextModalProps {
    closeModal: () => void;
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = error => reject(error);
    });
};

const SpeechToTextModal: React.FC<SpeechToTextModalProps> = ({ closeModal }) => {
    const [file, setFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [copied, setCopied] = useState(false);

    useEffect(() => {
        return () => {
            if (previewUrl) {
                URL.revokeObjectURL(previewUrl);
            }
        };
    }, [previewUrl]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (selectedFile && (selectedFile.type.startsWith('audio/') || selectedFile.type.startsWith('video/'))) {
            setFile(selectedFile);
            setResult(null);
            setError(null);
            const url = URL.createObjectURL(selectedFile);
            setPreviewUrl(url);
        } else {
            setError("Please select a valid audio or video file.");
        }
    };

    const handleAnalyze = async () => {
        if (!file) return;

        setIsLoading(true);
        setError(null);
        setResult(null);

        try {
            const base64Data = await fileToBase64(file);
            const prompt = `Transcribe the audio from this file. Return only the transcribed text, without any additional formatting or introductory phrases.`;
            const transcription = await analyzeContent(prompt, base64Data, file.type);
            setResult(transcription);
        } catch (err) {
            console.error("Transcription Error:", err);
            const errorMessage = err instanceof Error ? err.message : "An unknown error occurred.";
            setError(`Failed to transcribe: ${errorMessage}`);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleCopy = () => {
        if (!result) return;
        navigator.clipboard.writeText(result);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <Modal title="🎙️ AI Audio Transcription" closeModal={closeModal} show={true}>
            <div className="space-y-5">
                <p className="text-sm text-gray-400 text-center">Upload an audio or video file to get a written transcript powered by AI.</p>
                
                {previewUrl ? (
                    <div className="bg-black p-2 rounded-lg border border-teal-500/30">
                        {file?.type.startsWith('audio/') ? (
                            <audio src={previewUrl} controls className="w-full" />
                        ) : (
                            <video src={previewUrl} controls className="w-full h-auto max-h-48 rounded" />
                        )}
                        <button onClick={() => fileInputRef.current?.click()} className="text-xs text-teal-400 hover:text-teal-300 w-full text-center mt-2">Change file</button>
                    </div>
                ) : (
                    <label className="w-full h-32 rounded-xl border-2 border-dashed border-gray-600 hover:border-teal-500 bg-gray-900/50 flex flex-col items-center justify-center cursor-pointer transition-colors group">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-gray-500 group-hover:text-teal-400 mb-2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
                        <span className="text-sm font-semibold text-gray-400 group-hover:text-teal-300">Select Audio/Video File</span>
                    </label>
                )}
                <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="audio/*,video/*" className="hidden" />

                <button
                    onClick={handleAnalyze}
                    disabled={isLoading || !file}
                    className="w-full py-3 bg-teal-600 text-white font-bold rounded-xl hover:bg-teal-500 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                    {isLoading ? (
                        <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                    ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                    )}
                    <span>{isLoading ? 'AI is listening...' : 'Transcribe'}</span>
                </button>
                
                {error && <p className="text-red-400 text-sm text-center">{error}</p>}

                {result && (
                    <div className="bg-gray-900/50 p-4 rounded-xl border border-gray-700 animate-fadeIn space-y-3">
                        <div className="flex justify-between items-center">
                            <h4 className="text-sm font-bold text-teal-400 uppercase tracking-wider">Transcription Result</h4>
                            <button onClick={handleCopy} className="text-xs font-semibold bg-gray-700 hover:bg-gray-600 text-white px-3 py-1 rounded-md transition-colors">
                                {copied ? 'Copied!' : 'Copy'}
                            </button>
                        </div>
                        <p className="text-gray-300 text-sm whitespace-pre-wrap max-h-48 overflow-y-auto">{result}</p>
                    </div>
                )}
            </div>
        </Modal>
    );
};

export default SpeechToTextModal;