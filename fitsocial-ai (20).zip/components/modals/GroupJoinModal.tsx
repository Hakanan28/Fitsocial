
import React, { useState } from 'react';
import { Group, ModalType, UserProfile } from '../../types';
import { useTranslation } from '../../hooks/i18n';

interface GroupJoinModalProps {
    closeModal: () => void;
    group: Group;
    handleJoin: (group: Group, answer: string) => void;
    fitTokenBalance: number;
    currentUser: UserProfile;
    openModal: (modal: ModalType, data?: any) => void;
}

const GroupJoinModal: React.FC<GroupJoinModalProps> = ({ closeModal, group, handleJoin, fitTokenBalance, currentUser, openModal }) => {
    const { t } = useTranslation();
    const [answer, setAnswer] = useState('');
    const [error, setError] = useState('');

    const isMember = group.members.some(m => m.username === currentUser.username);
    const hasStakeRequirement = group.requirements?.isStaked && group.requirements.stakeAmount;
    const hasSufficientBalance = hasStakeRequirement ? fitTokenBalance >= group.requirements.stakeAmount! : true;

    const handlePrimaryAction = () => {
        if (isMember) {
            openModal(ModalType.GroupChat, group.id);
            closeModal();
            return;
        }

        setError('');
        if (!hasSufficientBalance) {
            setError(t('groups.insufficientBalance', { amount: group.requirements?.stakeAmount }) as string);
            return;
        }
        if (group.entryQuestion && !answer.trim() && !isMember) {
            setError(t('groups.answerEntryQuestion') as string);
            return;
        }

        handleJoin(group, answer);
        closeModal();
    };

    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) closeModal();
    };
    
    const getButtonText = () => {
        if (isMember) return t('groups.goToChat');
        if (hasStakeRequirement) return `${t('groups.stakeAndJoin')} ${group.requirements?.stakeAmount} $FIT`;
        return t('groups.join');
    };

    return (
        <div className="fixed inset-0 bg-black/80 z-[200] flex items-center justify-center p-4 animate-fadeIn" onClick={handleOverlayClick}>
            <div 
                className="relative bg-gray-900 w-full max-w-sm rounded-3xl shadow-2xl flex flex-col max-h-[90vh] border border-white/10 overflow-hidden"
                onClick={e => e.stopPropagation()}
            >
                {/* Header with Cover Image/Theme */}
                <div className="h-40 w-full relative flex-shrink-0">
                    {group.coverImage ? (
                        <img src={group.coverImage} alt={group.name} className="w-full h-full object-cover" />
                    ) : (
                        <div className="w-full h-full" style={{ background: group.theme.gradient }}></div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
                    <div className="absolute bottom-4 left-4">
                        <h2 className="text-2xl font-black text-white">{group.name}</h2>
                        <p className="text-sm text-gray-300 italic">"{group.motto}"</p>
                    </div>
                </div>

                <div className="flex-grow p-6 space-y-5 overflow-y-auto">
                    <div>
                        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Manifesto</h3>
                        <p className="text-sm text-gray-300 leading-relaxed">{group.description}</p>
                    </div>

                    <div className="bg-gray-800/50 p-4 rounded-xl border border-white/10 space-y-3">
                        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Giriş Şartları</h3>
                        
                        {hasStakeRequirement && (
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-gray-300 flex items-center gap-1">💰 Gerekli Stake:</span>
                                <span className={`font-bold ${hasSufficientBalance ? 'text-green-400' : 'text-red-400'}`}>
                                    {group.requirements!.stakeAmount} $FIT
                                </span>
                            </div>
                        )}

                        {group.entryQuestion && !isMember && (
                            <div>
                                <label className="text-gray-300 text-sm font-semibold mb-2 block">{group.entryQuestion}</label>
                                <textarea
                                    value={answer}
                                    onChange={e => setAnswer(e.target.value)}
                                    rows={2}
                                    className="w-full p-2 bg-gray-900 text-white rounded-lg border border-gray-600 focus:border-green-500 transition-colors text-sm"
                                    placeholder="Cevabın..."
                                />
                            </div>
                        )}
                        {!hasStakeRequirement && !group.entryQuestion && !isMember && (
                            <p className="text-sm text-gray-500 text-center py-2">{t('groups.openToEveryone')}</p>
                        )}
                         {isMember && (
                            <p className="text-sm text-green-400 text-center py-2 font-bold">{t('groups.alreadyMember')}</p>
                        )}
                    </div>
                    
                    {error && <p className="text-red-400 text-xs text-center bg-red-900/50 p-2 rounded-lg">{error}</p>}
                </div>

                <footer className="p-6 pt-0 flex-shrink-0">
                    <button 
                        onClick={handlePrimaryAction} 
                        disabled={!hasSufficientBalance && !isMember}
                        className="w-full bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition-colors transform hover:scale-105 shadow-lg shadow-green-900/30 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:transform-none"
                    >
                        {getButtonText()}
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default GroupJoinModal;
