import React, { useState, useRef } from 'react';
import Modal from '../ui/Modal';
import { GroupTheme, Group, GroupGoal, GroupRequirements, SocialLinks } from '../../types';
import { useTranslation } from '../../hooks/i18n';
import { expandImageWithAi } from '../../services/geminiService';

interface CreateGroupModalProps {
    closeModal: () => void;
    handleCreateGroup: (groupData: Partial<Group>) => void;
}

// --- CONSTANTS & DATA ---

// Helper for SVGs
const createSvgPattern = (path: string, color = '255,255,255') => 
    `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='rgba(${color},0.15)' fill-rule='evenodd'%3E%3Cpath d='${path}' /%3E%3C/g%3E%3C/svg%3E")`;

// Custom "Green Cat" Pattern
const GREEN_CAT_PATTERN = `url("data:image/svg+xml,%3Csvg width='52' height='26' viewBox='0 0 52 26' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23064e3b' fill-opacity='0.2'%3E%3Cpath d='M10 10c0-2.21-1.79-4-4-4-3.314 0-6-2.686-6-6h2c0 2.21 1.79 4 4 4 3.314 0 6 2.686 6 6 0 2.21 1.79 4 4 4 3.314 0 6 2.686 6 6 0 2.21 1.79 4 4 4v2c-3.314 0-6-2.686-6-6 0-2.21-1.79-4-4-4-3.314 0-6-2.686-6-6zm25.464-1.95l8.486 8.486-1.414 1.414-8.486-8.486 1.414-1.414z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E"), linear-gradient(135deg, #10b981 0%, #059669 100%)`;

const THEME_CATEGORIES = {
    animated: [
        { id: 'anim_cyber', name: 'Cyber Pulse', gradient: 'linear-gradient(270deg, #ff00cc, #333399)', primaryColor: '#fff', accentColor: '#ff00cc', isAnimated: true },
        { id: 'anim_fire', name: 'Inferno Flow', gradient: 'linear-gradient(270deg, #f12711, #f5af19)', primaryColor: '#fff', accentColor: '#f5af19', isAnimated: true },
        { id: 'anim_ocean', name: 'Deep Sea', gradient: 'linear-gradient(270deg, #2b5876, #4e4376)', primaryColor: '#fff', accentColor: '#4e4376', isAnimated: true },
        { id: 'anim_forest', name: 'Living Forest', gradient: 'linear-gradient(270deg, #134e5e, #71b280)', primaryColor: '#fff', accentColor: '#71b280', isAnimated: true },
        { id: 'anim_neon', name: 'Neon Night', gradient: 'linear-gradient(270deg, #00f260, #0575e6)', primaryColor: '#fff', accentColor: '#00f260', isAnimated: true },
        { id: 'anim_galaxy', name: 'Galaxy Void', gradient: 'linear-gradient(270deg, #243949, #517fa4)', primaryColor: '#fff', accentColor: '#517fa4', isAnimated: true },
        { id: 'anim_aurora', name: 'Aurora', gradient: 'linear-gradient(270deg, #00c6ff, #0072ff)', primaryColor: '#fff', accentColor: '#00c6ff', isAnimated: true },
        { id: 'anim_sunset', name: 'Sunset Drive', gradient: 'linear-gradient(270deg, #fe8c00, #f83600)', primaryColor: '#fff', accentColor: '#fe8c00', isAnimated: true },
    ],
    patterns: [
        { id: 'pat_cats', name: 'Green Cats', gradient: GREEN_CAT_PATTERN, primaryColor: '#fff', accentColor: '#064e3b' },
        { id: 'pat_gym', name: 'Gym Grid', gradient: `${createSvgPattern('M20 20h20v20H20V20zM0 0h20v20H0V0z')}, #111827`, primaryColor: '#fff', accentColor: '#6b7280' },
        { id: 'pat_food', name: 'Pizza Party', gradient: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Ccircle cx='2' cy='2' r='2' fill='rgba(255,255,255,0.2)'/%3E%3C/svg%3E"), #b91c1c`, primaryColor: '#fff', accentColor: '#fca5a5' },
        { id: 'pat_tech', name: 'Blueprint', gradient: `radial-gradient(circle, #3b82f6 1px, transparent 1px), #1e3a8a`, primaryColor: '#fff', accentColor: '#93c5fd' },
        { id: 'pat_honey', name: 'Honeycomb', gradient: `url("data:image/svg+xml,%3Csvg width='56' height='100' viewBox='0 0 56 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M28 66L0 50L0 16L28 0L56 16L56 50L28 66L28 100' fill='none' stroke='rgba(0,0,0,0.1)' stroke-width='2'/%3E%3C/svg%3E"), #fbbf24`, primaryColor: '#000', accentColor: '#78350f' },
    ],
    vibrant: [
        { id: 'vib_cyber', name: 'Cyberpunk', gradient: 'linear-gradient(135deg, #2a0845 0%, #6441a5 100%)', primaryColor: '#d946ef', accentColor: '#22d3ee' },
        { id: 'vib_ocean', name: 'Deep Ocean', gradient: 'linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%)', primaryColor: '#38bdf8', accentColor: '#7dd3fc' },
        { id: 'vib_fire', name: 'Inferno', gradient: 'linear-gradient(135deg, #93291e 0%, #ed213a 100%)', primaryColor: '#fca5a5', accentColor: '#fbbf24' },
        { id: 'vib_zen', name: 'Zen Garden', gradient: 'linear-gradient(135deg, #134e5e 0%, #71b280 100%)', primaryColor: '#86efac', accentColor: '#f0fdf4' },
        { id: 'vib_night', name: 'Midnight', gradient: 'linear-gradient(135deg, #000000 0%, #434343 100%)', primaryColor: '#e5e7eb', accentColor: '#9ca3af' },
        { id: 'vib_royal', name: 'Royal', gradient: 'linear-gradient(135deg, #536976 0%, #292E49 100%)', primaryColor: '#fff', accentColor: '#a5b4fc' },
        { id: 'vib_peach', name: 'Peach', gradient: 'linear-gradient(135deg, #ed4264 0%, #ffedbc 100%)', primaryColor: '#000', accentColor: '#ed4264' },
    ],
    solids: [
        { id: 'sol_black', name: 'Pure Black', gradient: '#000000', primaryColor: '#fff', accentColor: '#666' },
        { id: 'sol_gray', name: 'Slate', gradient: '#1f2937', primaryColor: '#fff', accentColor: '#9ca3af' },
        { id: 'sol_red', name: 'Crimson', gradient: '#7f1d1d', primaryColor: '#fff', accentColor: '#fca5a5' },
        { id: 'sol_blue', name: 'Navy', gradient: '#1e3a8a', primaryColor: '#fff', accentColor: '#93c5fd' },
        { id: 'sol_green', name: 'Forest', gradient: '#14532d', primaryColor: '#fff', accentColor: '#86efac' },
        { id: 'sol_purple', name: 'Grape', gradient: '#5b21b6', primaryColor: '#fff', accentColor: '#d8b4fe' },
    ]
};

const CreateGroupModal: React.FC<CreateGroupModalProps> = ({ closeModal, handleCreateGroup }) => {
    const { t } = useTranslation();
    const [step, setStep] = useState(1); // 1: Identity, 2: Atmosphere, 3: Purpose, 4: Governance
    
    // Step 1: Identity
    const [name, setName] = useState('');
    const [motto, setMotto] = useState('');
    const [description, setDescription] = useState('');
    const [coverImage, setCoverImage] = useState<string | null>(null);
    const [location, setLocation] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [isExpanding, setIsExpanding] = useState(false);


    // Step 2: Atmosphere
    const [selectedTheme, setSelectedTheme] = useState<GroupTheme>(THEME_CATEGORIES.animated[0]);
    const [activeThemeTab, setActiveThemeTab] = useState<'animated' | 'patterns' | 'vibrant' | 'solids'>('animated');

    // Step 3: Purpose
    const [tags, setTags] = useState<string[]>([]);
    const [tagInput, setTagInput] = useState('');
    const [goalTitle, setGoalTitle] = useState('');
    const [goalTarget, setGoalTarget] = useState<number | ''>('');
    const [goalUnit, setGoalUnit] = useState('Steps');

    // Step 4: Governance
    const [isPrivate, setIsPrivate] = useState(true);
    const [entryQuestion, setEntryQuestion] = useState('');
    const [isStaked, setIsStaked] = useState(false);
    const [stakeAmount, setStakeAmount] = useState<number | ''>(500);
    const [discordLink, setDiscordLink] = useState('');
    const [instagramLink, setInstagramLink] = useState('');

    // --- Handlers ---

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = async () => {
                const originalDataUrl = reader.result as string;
                setCoverImage(originalDataUrl); // Show original image immediately
                setIsExpanding(true);
                try {
                    // Aspect ratio for the image container is 16:9 (aspect-video)
                    const expandedDataUrl = await expandImageWithAi(originalDataUrl, 16 / 9);
                    setCoverImage(expandedDataUrl);
                } catch (error) {
                    console.error("AI image expansion failed:", error);
                    // Handle error visually if needed
                } finally {
                    setIsExpanding(false);
                }
            };
            reader.readAsDataURL(file);
        }
    };

    const handleAddTag = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && tagInput.trim()) {
            e.preventDefault();
            if (!tags.includes(tagInput.trim())) {
                setTags([...tags, tagInput.trim()]);
            }
            setTagInput('');
        }
    };

    const removeTag = (tag: string) => {
        setTags(tags.filter(t => t !== tag));
    };

    const handleSubmit = () => {
        if (!name.trim()) return;
        
        const goalData: GroupGoal | undefined = (goalTitle && goalTarget) ? {
            title: goalTitle,
            target: Number(goalTarget),
            current: 0,
            unit: goalUnit
        } : undefined;

        const requirementsData: GroupRequirements | undefined = isStaked ? {
            isStaked: true,
            stakeAmount: Number(stakeAmount) || 0
        } : undefined;

        const socialData: SocialLinks | undefined = (discordLink || instagramLink) ? {
            discord: discordLink,
            instagram: instagramLink
        } : undefined;

        handleCreateGroup({
            name,
            description,
            motto,
            coverImage: coverImage || undefined,
            tags,
            theme: selectedTheme,
            goal: goalData,
            requirements: requirementsData,
            socialLinks: socialData,
            entryQuestion: entryQuestion || "Why do you want to join us?",
            isPrivate,
            location: location || undefined
        });
        closeModal();
    };

    const nextStep = () => setStep(s => Math.min(4, s + 1));
    const prevStep = () => setStep(s => Math.max(1, s - 1));

    // --- RENDER STEPS ---

    const renderIdentityStep = () => (
        <div className="space-y-5 animate-fadeIn">
            <div 
                className="aspect-video rounded-xl bg-[#0B0E14] border-2 border-dashed border-gray-600 flex flex-col items-center justify-center cursor-pointer hover:border-green-500 hover:bg-gray-800/80 transition-all relative overflow-hidden group"
                onClick={() => !isExpanding && fileInputRef.current?.click()}
            >
                {coverImage ? (
                    <>
                        <img src={coverImage} className="w-full h-full object-cover transition-opacity" alt="Cover Preview" />
                        {!isExpanding && (
                            <div className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity">
                                <span className="bg-black/60 px-3 py-1 rounded-lg text-xs font-bold text-white">{t('createGroup.changeCover')}</span>
                            </div>
                        )}
                    </>
                ) : (
                    <div className="text-center text-gray-400 group-hover:text-green-400">
                        <span className="text-2xl mb-1 block">🖼️</span>
                        <span className="text-xs font-bold uppercase">{t('createGroup.uploadCover')}</span>
                    </div>
                )}
                <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" disabled={isExpanding} />
                {isExpanding && (
                    <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center z-10 backdrop-blur-sm">
                        <div className="w-8 h-8 border-4 border-gray-600 border-t-green-500 rounded-full animate-spin"></div>
                        <p className="text-xs text-green-400 mt-3 font-semibold animate-pulse">✨ AI expanding image...</p>
                    </div>
                )}
            </div>

            <div className="grid grid-cols-1 gap-4">
                <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 block">{t('createGroup.tribeName')}</label>
                    <input 
                        type="text" value={name} onChange={e => setName(e.target.value)} placeholder={t('createGroup.tribeNamePlaceholder') as string}
                        className="w-full bg-gray-800/50 border border-gray-700 text-white rounded-xl p-3 focus:border-green-500 transition-colors font-bold text-lg"
                        autoFocus
                    />
                </div>
                <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 block">{t('createGroup.motto')}</label>
                    <input 
                        type="text" value={motto} onChange={e => setMotto(e.target.value)} placeholder={t('createGroup.mottoPlaceholder') as string}
                        className="w-full bg-gray-800/50 border border-gray-700 text-white rounded-xl p-3 focus:border-green-500 transition-colors italic"
                    />
                </div>
                 <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 block">Location (City, Region)</label>
                    <input 
                        type="text" value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g. Istanbul, Turkey"
                        className="w-full bg-gray-800/50 border border-gray-700 text-white rounded-xl p-3 focus:border-green-500 transition-colors"
                    />
                </div>
                <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 block">{t('createGroup.manifesto')}</label>
                    <textarea 
                        value={description} onChange={e => setDescription(e.target.value)} rows={3} 
                        placeholder={t('createGroup.manifestoPlaceholder') as string}
                        className="w-full bg-gray-800/50 border border-gray-700 text-white rounded-xl p-3 focus:border-green-500 transition-colors text-sm resize-none"
                    />
                </div>
            </div>
        </div>
    );

    const renderAtmosphereStep = () => (
        <div className="space-y-4 animate-fadeIn h-full flex flex-col">
            <div className="flex-shrink-0">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2 block text-center">{t('createGroup.livePreview')}</label>
                <div 
                    className={`rounded-xl p-4 shadow-2xl transition-all duration-500 border border-white/20 h-32 flex flex-col justify-between relative overflow-hidden ${selectedTheme.isAnimated ? 'animate-gradient-x' : ''}`}
                    style={{ background: selectedTheme.gradient, backgroundSize: selectedTheme.isAnimated ? '200% 200%' : 'cover' }}
                >
                    {coverImage && (
                        <div className="absolute inset-0 bg-black/40 z-0">
                            <img src={coverImage} className="w-full h-full object-cover opacity-30" />
                        </div>
                    )}
                    <div className="flex items-center gap-3 z-10 relative">
                        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-xl shadow-inner border border-white/30 text-white">
                            {name ? name.charAt(0).toUpperCase() : '?'}
                        </div>
                        <div>
                            <h3 className="font-bold text-lg leading-none" style={{ color: selectedTheme.primaryColor }}>{name || t('createGroup.tribeName')}</h3>
                            <p className="text-[10px] opacity-80" style={{ color: selectedTheme.primaryColor }}>{motto || t('createGroup.mottoPlaceholder')}</p>
                        </div>
                    </div>
                    <div className="self-end bg-black/40 backdrop-blur-md rounded-2xl rounded-tr-sm px-3 py-2 max-w-[80%] z-10 relative">
                        <p className="text-xs text-white">{t('createGroup.welcomeMessage')}</p>
                    </div>
                </div>
            </div>

            <div className="flex-1 flex flex-col min-h-0">
                <div className="flex gap-2 mb-3 overflow-x-auto scrollbar-hide flex-shrink-0">
                    {Object.keys(THEME_CATEGORIES).map(tab => (
                        <button 
                            key={tab}
                            onClick={() => setActiveThemeTab(tab as any)}
                            className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider transition-colors whitespace-nowrap ${activeThemeTab === tab ? 'bg-white text-black' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}
                        >
                            {t(`createGroup.themes.${tab}`)}
                        </button>
                    ))}
                </div>
                <div className="grid grid-cols-4 gap-3 overflow-y-auto pr-1 pb-2">
                    {THEME_CATEGORIES[activeThemeTab].map((theme) => (
                        <button
                            key={theme.id}
                            onClick={() => setSelectedTheme(theme)}
                            className={`aspect-square rounded-xl border-2 transition-all transform hover:scale-105 ${selectedTheme.id === theme.id ? 'border-white shadow-[0_0_15px_rgba(255,255,255,0.5)] scale-105' : 'border-transparent opacity-80 hover:opacity-100'}`}
                            style={{ background: theme.gradient, backgroundSize: 'cover' }}
                            title={theme.name}
                        />
                    ))}
                </div>
            </div>
        </div>
    );

    const renderPurposeStep = () => (
        <div className="space-y-6 animate-fadeIn">
            <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2 block">{t('createGroup.tags')}</label>
                <div className="flex flex-wrap gap-2 p-3 bg-gray-800/50 border border-gray-700 rounded-xl focus-within:border-blue-500 transition-colors">
                    {tags.map((tag, i) => (
                        <span key={i} className="bg-blue-600/20 text-blue-400 px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1 border border-blue-500/30">
                            #{tag}
                            <button onClick={() => removeTag(tag)} className="hover:text-white">&times;</button>
                        </span>
                    ))}
                    <input 
                        type="text" value={tagInput} onChange={e => setTagInput(e.target.value)} onKeyDown={handleAddTag}
                        placeholder={tags.length === 0 ? t('createGroup.tagsPlaceholder') as string : ""}
                        className="bg-transparent outline-none text-white text-sm flex-1 min-w-[100px]"
                    />
                </div>
            </div>

            <div className="bg-gray-800 p-4 rounded-xl border border-gray-700">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-3 block flex items-center gap-2">
                    <span>🎯</span> {t('createGroup.goal')}
                </label>
                <div className="grid grid-cols-1 gap-3">
                    <input type="text" value={goalTitle} onChange={e => setGoalTitle(e.target.value)} placeholder={t('createGroup.goalTitlePlaceholder') as string} className="w-full bg-black/30 border border-gray-600 rounded-lg p-2 text-white text-sm" />
                    <div className="flex gap-2">
                        <input type="number" value={goalTarget} onChange={e => setGoalTarget(Number(e.target.value))} placeholder={t('createGroup.goalTargetPlaceholder') as string} className="flex-1 bg-black/30 border border-gray-600 rounded-lg p-2 text-white text-sm" />
                        <select value={goalUnit} onChange={e => setGoalUnit(e.target.value)} className="bg-black/30 border border-gray-600 rounded-lg p-2 text-white text-xs">
                            <option value="Steps">{t('createGroup.goalUnits.steps')}</option>
                            <option value="Workouts">{t('createGroup.goalUnits.workouts')}</option>
                            <option value="Calories">{t('createGroup.goalUnits.calories')}</option>
                            <option value="km">{t('createGroup.goalUnits.km')}</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    );

    const renderGovernanceStep = () => (
        <div className="space-y-5 animate-fadeIn">
            <div onClick={() => setIsPrivate(!isPrivate)} className="flex items-center justify-between bg-gray-800 p-3 rounded-xl cursor-pointer hover:bg-gray-700 transition-colors border border-gray-700">
                <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${isPrivate ? 'bg-red-500/20 text-red-400' : 'bg-blue-500/20 text-blue-400'}`}>
                        {isPrivate ? <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg> : <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="2" x2="22" y1="12" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>}
                    </div>
                    <div>
                        <p className="font-bold text-white text-sm">{isPrivate ? t('createGroup.privateTribe') : t('createGroup.publicTribe')}</p>
                        <p className="text-[10px] text-gray-400">{isPrivate ? t('createGroup.privateDesc') : t('createGroup.publicDesc')}</p>
                    </div>
                </div>
            </div>

            <div className={`bg-gradient-to-br from-yellow-900/20 to-black border ${isStaked ? 'border-yellow-500' : 'border-gray-700'} p-4 rounded-xl transition-all`}>
                <div className="flex justify-between items-center mb-3">
                    <label className="text-[10px] font-bold text-yellow-500 uppercase tracking-wider flex items-center gap-2">
                        <span>💰</span> {t('createGroup.stakeTitle')}
                    </label>
                    <button onClick={() => setIsStaked(!isStaked)} className={`relative inline-flex items-center h-5 rounded-full w-9 transition-colors ${isStaked ? 'bg-yellow-500' : 'bg-gray-600'}`}>
                        <span className={`inline-block w-3 h-3 transform bg-white rounded-full transition-transform ${isStaked ? 'translate-x-5' : 'translate-x-1'}`} />
                    </button>
                </div>
                {isStaked && (
                    <div className="animate-fadeIn">
                        <p className="text-[10px] text-gray-400 mb-2">{t('createGroup.stakeDesc')}</p>
                        <div className="flex gap-2 items-center">
                            <input type="number" value={stakeAmount} onChange={e => setStakeAmount(Number(e.target.value))} placeholder="500" className="w-24 bg-black/50 border border-yellow-700 rounded-lg p-2 text-yellow-400 font-mono text-center" />
                            <span className="font-black text-yellow-500">$FIT</span>
                        </div>
                    </div>
                )}
            </div>

            <div className="grid grid-cols-1 gap-3">
                <input type="text" value={entryQuestion} onChange={e => setEntryQuestion(e.target.value)} placeholder={t('createGroup.entryQuestionPlaceholder') as string} className="w-full bg-gray-800/50 border border-gray-700 rounded-xl p-3 text-xs" />
                <div className="flex gap-2">
                    <input type="text" value={discordLink} onChange={e => setDiscordLink(e.target.value)} placeholder={t('createGroup.discordPlaceholder') as string} className="flex-1 bg-gray-800/50 border border-gray-700 rounded-xl p-3 text-xs" />
                    <input type="text" value={instagramLink} onChange={e => setInstagramLink(e.target.value)} placeholder={t('createGroup.instagramPlaceholder') as string} className="flex-1 bg-gray-800/50 border border-gray-700 rounded-xl p-3 text-xs" />
                </div>
            </div>
        </div>
    );

    const stepLabels = t('createGroup.stepLabels') as string[];

    return (
        <Modal title={t('createGroup.title') as string} closeModal={closeModal} show={true}>
            <style>{`.animate-gradient-x { animation: gradient-x 15s ease infinite; }`}</style>
            
            <div className="flex flex-col h-[75vh] md:h-auto">
                <div className="flex justify-between items-center mb-6 px-1">
                    {stepLabels.map((label, idx) => (
                        <div key={label} className="flex flex-col items-center gap-1 cursor-pointer z-10" onClick={() => setStep(idx + 1)}>
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${step === idx + 1 ? 'bg-green-500 text-black scale-110 shadow-lg' : step > idx + 1 ? 'bg-green-900 text-green-400' : 'bg-gray-800 text-gray-500'}`}>
                                {step > idx + 1 ? '✓' : idx + 1}
                            </div>
                            <span className={`text-[8px] font-bold uppercase ${step === idx + 1 ? 'text-green-400' : 'text-gray-600'}`}>{label}</span>
                        </div>
                    ))}
                    <div className="absolute top-[4.5rem] left-8 right-8 h-0.5 bg-gray-800 -z-0">
                        <div className="h-full bg-green-900 transition-all duration-500" style={{ width: `${((step - 1) / 3) * 100}%` }}></div>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto px-1 pb-4">
                    {step === 1 && renderIdentityStep()}
                    {step === 2 && renderAtmosphereStep()}
                    {step === 3 && renderPurposeStep()}
                    {step === 4 && renderGovernanceStep()}
                </div>

                <div className="flex gap-3 pt-4 border-t border-white/10 mt-auto">
                    {step > 1 && (
                        <button onClick={prevStep} className="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 rounded-xl transition-colors">
                            {t('common.back')}
                        </button>
                    )}
                    {step < 4 ? (
                        <button onClick={nextStep} disabled={!name} className="flex-1 bg-white hover:bg-gray-200 text-black font-bold py-3 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                            {t('common.next')}
                        </button>
                    ) : (
                        <button 
                            onClick={handleSubmit} 
                            className="flex-1 font-bold py-3 rounded-xl text-white shadow-lg transform transition-all active:scale-95 hover:shadow-xl hover:scale-[1.02]"
                            style={{ background: selectedTheme.gradient }}
                        >
                            {t('createGroup.launchTribe')}
                        </button>
                    )}
                </div>
            </div>
        </Modal>
    );
};

export default CreateGroupModal;