import React, { useState, useRef } from 'react';
import { UserProfile } from '../../types';

interface EditProfileModalProps {
    closeModal: () => void;
    currentUser: UserProfile;
    onUpdateProfile: (updatedUser: UserProfile) => void;
}

const EditProfileModal: React.FC<EditProfileModalProps> = ({ closeModal, currentUser, onUpdateProfile }) => {
    const [username, setUsername] = useState(currentUser.username);
    const [bio, setBio] = useState(currentUser.bio || '');
    const [avatarImage, setAvatarImage] = useState(currentUser.avatarImage);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleAvatarClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setAvatarImage(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSave = () => {
        const updatedUser = {
            ...currentUser,
            username,
            bio,
            avatarImage,
        };
        onUpdateProfile(updatedUser);
        closeModal();
    };
    
    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) closeModal();
    };

    return (
        <div className="fixed inset-0 bg-black/80 z-[200] flex items-center justify-center p-4 animate-fadeIn" onClick={handleOverlayClick}>
            <div className="bg-gradient-to-br from-[#1f2937] to-[#111827] border border-gray-700 w-full max-w-md p-6 rounded-2xl shadow-2xl shadow-black/50 animate-slideIn flex flex-col max-h-[90vh]">
                <header className="flex justify-between items-center pb-4 border-b border-gray-600 flex-shrink-0">
                    <h3 className="text-xl font-bold text-white">Edit Profile</h3>
                    <button onClick={closeModal} className="text-gray-400 hover:text-white transition-all transform hover:rotate-90 text-2xl">&times;</button>
                </header>
                <div className="flex-grow mt-4 overflow-y-auto space-y-6">
                    <div className="flex flex-col items-center">
                        <img 
                            src={avatarImage} 
                            alt="Profile" 
                            className="w-24 h-24 rounded-full object-cover ring-2 ring-green-500 cursor-pointer"
                            onClick={handleAvatarClick}
                        />
                        <button onClick={handleAvatarClick} className="text-sm font-semibold text-green-400 mt-2 hover:underline">
                            Change Profile Photo
                        </button>
                        <input 
                            type="file" 
                            ref={fileInputRef} 
                            onChange={handleFileChange} 
                            className="hidden" 
                            accept="image/*"
                        />
                    </div>
                    <div>
                        <label htmlFor="username" className="text-sm font-bold text-gray-300 block mb-1">Username</label>
                        <input 
                            type="text" 
                            id="username"
                            value={username}
                            onChange={e => setUsername(e.target.value)}
                            className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 focus:ring-2 focus:ring-green-500/50 transition-all"
                        />
                    </div>
                     <div>
                        <label htmlFor="bio" className="text-sm font-bold text-gray-300 block mb-1">Bio</label>
                        <textarea 
                            id="bio"
                            value={bio}
                            onChange={e => setBio(e.target.value)}
                            rows={3}
                            className="w-full p-3 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-green-500 focus:ring-2 focus:ring-green-500/50 transition-all"
                            placeholder="Tell us about yourself..."
                        />
                    </div>
                </div>
                <footer className="mt-6 flex-shrink-0">
                    <button onClick={handleSave} className="w-full bg-green-500 text-white font-bold py-3 rounded-xl hover:bg-green-600 transition-colors transform hover:scale-105">
                        Save Changes
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default EditProfileModal;