
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';

interface QuantumHrvModalProps {
    closeModal: () => void;
}

const QuantumHrvModal: React.FC<QuantumHrvModalProps> = ({ closeModal }) => {
    const [hrv, setHrv] = useState(0);
    const [advice, setAdvice] = useState('');
    const [color, setColor] = useState('text-green-400');
    
    useEffect(() => {
        const score = 75; // Simulated score
        setTimeout(() => setHrv(score), 100);
        if (score >= 65) {
            setAdvice("Excellent Readiness. Ideal for a new record attempt!");
            setColor('text-green-400');
        } else if (score >= 50) {
            setAdvice("Good Readiness. Focus on volume and technique.");
            setColor('text-yellow-400');
        } else {
            setAdvice("Low Readiness. Prioritize active recovery.");
            setColor('text-red-400');
        }
    }, []);

    return (
        <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4 animate-fadeIn" onClick={closeModal}>
            <div className="bg-gradient-to-br from-[#1f2937] to-[#0f172a] border-2 border-blue-500 w-full max-w-xs p-6 rounded-2xl shadow-2xl shadow-blue-900/50 text-center animate-slideIn" onClick={e => e.stopPropagation()}>
                <h3 className="text-2xl font-extrabold text-blue-400 mb-4" style={{textShadow: '0 0 8px #3B82F6'}}>💙 Quantum HRV Analysis</h3>
                <p className="text-sm text-gray-300 mb-6">Nervous system readiness based on your morning sensor readings.</p>
                <div className="space-y-4">
                    <div className="bg-gray-900/50 p-4 rounded-xl border border-blue-700/50">
                        <span className="text-xl font-semibold text-white">HRV Score (RMSSD)</span>
                        <span className={`text-5xl font-extrabold ${color} block my-2`}>{hrv} ms</span>
                        <div className="h-2 rounded-full bg-black/50 border border-blue-700"><div className="bg-blue-500 h-full rounded-full transition-all duration-1000 ease-out" style={{ width: `${(hrv / 100) * 100}%` }}></div></div>
                    </div>
                     <div className="bg-gray-900/50 p-4 rounded-xl border border-blue-700/50">
                        <span className="text-xl font-semibold text-white">Today's Advice</span>
                        <p className="text-lg font-bold text-white mt-2">{advice}</p>
                    </div>
                </div>
                <button onClick={closeModal} className="w-full bg-blue-500 text-white py-3 rounded-xl font-bold mt-6 hover:bg-blue-600 transition-colors transform hover:scale-105">Close</button>
            </div>
        </div>
    );
};

export default QuantumHrvModal;