
import React, { useState } from 'react';
import Modal from '../ui/Modal';
import { ModalType, ActivityRecord, UserProfile, AdaptiveWorkoutPlan } from '../../types';
import { useTranslation, supportedLanguages } from '../../hooks/i18n';
import { generateAdaptiveWorkout } from '../../services/geminiService';

interface AdaptiveWorkoutModalProps {
    closeModal: () => void;
    openModal: (modal: ModalType, data?: any) => void;
    activityHistory: ActivityRecord[];
    userProfileData: any;
    currentUser: UserProfile;
}

const AdaptiveWorkoutModal: React.FC<AdaptiveWorkoutModalProps> = ({ closeModal, openModal, activityHistory, userProfileData, currentUser }) => {
    const { t, language } = useTranslation();
    const [step, setStep] = useState<'input' | 'loading' | 'result'>('input');
    const [error, setError] = useState<string | null>(null);
    const [generatedPlan, setGeneratedPlan] = useState<AdaptiveWorkoutPlan | null>(null);

    // Input state
    const [energyLevel, setEnergyLevel] = useState(3);
    const [soreMuscles, setSoreMuscles] = useState<string[]>([]);
    const [location, setLocation] = useState<'home' | 'gym'>('gym');

    const energyLevelLabels = t('adaptiveWorkout.step1.energyLevels') as string[];
    const energyLevels = energyLevelLabels.map((label, index) => ({
        value: index + 1,
        label: label,
    }));
    
    const sorenessAreas = t('adaptiveWorkout.step1.sorenessAreas') as string[];

    const handleSorenessToggle = (area: string) => {
        setSoreMuscles(prev =>
            prev.includes(area) ? prev.filter(item => item !== area) : [...prev, area]
        );
    };

    const handleGenerate = async (regenerate = false) => {
        setStep('loading');
        setError(null);
        if (!regenerate) {
            setGeneratedPlan(null);
        }

        try {
            const primaryGoal = userProfileData.targetWeight < userProfileData.weight ? 'Lose Weight' : 'Build Lean Muscle';
            
            const planOptions = {
                userName: currentUser.username,
                age: userProfileData.age,
                primaryGoal,
                fitnessLevel: 'Intermediate', // Assuming intermediate, a real app would store this
                location,
                equipment: location === 'gym' ? ['Full Gym Access'] : ['Bodyweight', 'Dumbbells', 'Resistance Bands'],
                recentActivity: activityHistory.slice(0, 3),
                energyLevel: energyLevel,
                soreMuscles: soreMuscles,
            };
            const languageName = supportedLanguages[language]?.name || 'English';

            const plan = await generateAdaptiveWorkout(planOptions, languageName);
            setGeneratedPlan(plan);
            setStep('result');
        } catch (err: any) {
            setError(err.message || t('adaptiveWorkout.error') as string);
            setStep('input');
        }
    };

    const handleStartWorkout = () => {
        closeModal();
        openModal(ModalType.WorkoutMode);
    };

    const renderInputStep = () => (
        <div className="space-y-6 animate-fadeIn">
            <div>
                <label className="text-md font-bold text-gray-200 block mb-2">{t('adaptiveWorkout.step1.energyLabel') as string}</label>
                <div className="flex justify-between">
                    {energyLevels.map(({value, label}) => (
                        <div key={value} className="text-center">
                            <input type="radio" id={`energy-${value}`} name="energy" value={value} checked={energyLevel === value} onChange={() => setEnergyLevel(value)} className="hidden"/>
                            <label htmlFor={`energy-${value}`} className={`block w-12 h-12 rounded-full border-2 flex items-center justify-center font-bold text-lg cursor-pointer transition-all ${energyLevel === value ? 'bg-purple-500 border-purple-300 text-white' : 'bg-gray-700 border-gray-600 text-gray-300 hover:border-purple-500'}`}>{value}</label>
                            <span className="text-xs text-gray-400 mt-1">{label}</span>
                        </div>
                    ))}
                </div>
            </div>
             <div>
                <label className="text-md font-bold text-gray-200 block mb-2">{t('adaptiveWorkout.step1.sorenessLabel') as string}</label>
                <div className="grid grid-cols-3 gap-2">
                    {sorenessAreas.map(area => (
                        <button key={area} onClick={() => handleSorenessToggle(area)} className={`p-2 text-sm font-semibold rounded-lg border-2 transition-colors ${soreMuscles.includes(area) ? 'bg-purple-500/20 border-purple-500 text-white' : 'bg-gray-800 border-gray-700 text-gray-300'}`}>{area}</button>
                    ))}
                </div>
            </div>
             <div>
                <label className="text-md font-bold text-gray-200 block mb-2">{t('exercise.tabs.library') as string}</label>
                <div className="flex p-1 bg-gray-800 rounded-lg font-semibold">
                    <button onClick={() => setLocation('home')} className={`w-1/2 py-2 rounded-md transition-colors ${location === 'home' ? 'bg-purple-600 text-white' : 'text-gray-400'}`}>{t('exercise.atHome') as string}</button>
                    <button onClick={() => setLocation('gym')} className={`w-1/2 py-2 rounded-md transition-colors ${location === 'gym' ? 'bg-purple-600 text-white' : 'text-gray-400'}`}>{t('exercise.gym') as string}</button>
                </div>
            </div>
            {error && <p className="text-red-400 text-sm text-center">{error}</p>}
            <button onClick={() => handleGenerate(false)} className="w-full bg-purple-600 text-white font-bold py-3 rounded-xl hover:bg-purple-700 transition-colors transform hover:scale-105">
                {t('adaptiveWorkout.step1.generateButton') as string}
            </button>
        </div>
    );

    const renderLoadingStep = () => (
        <div className="flex flex-col items-center justify-center h-48">
            <div className="w-10 h-10 border-4 border-t-purple-400 border-gray-600 rounded-full animate-spin"></div>
            <p className="text-purple-300 mt-4 font-semibold animate-pulse">{t('adaptiveWorkout.loading') as string}</p>
        </div>
    );
    
    const renderResultStep = () => (
        <div className="space-y-4 animate-fadeIn">
            <h3 className="text-2xl font-bold text-white text-center">{generatedPlan?.workoutTitle}</h3>
            <div className="p-3 bg-gray-800 rounded-xl border border-purple-500/50">
                <h4 className="text-sm font-bold text-purple-400 mb-1">{t('adaptiveWorkout.result.aiInsight') as string}</h4>
                <p className="text-sm text-gray-300 italic">"{generatedPlan?.aiRationale}"</p>
            </div>

            <div className="space-y-3 text-sm">
                <div>
                    <h4 className="font-semibold text-gray-200 mb-2">{t('adaptiveWorkout.result.warmup') as string}</h4>
                    <ul className="list-disc list-inside space-y-1 pl-2 text-gray-400">
                        {generatedPlan?.warmup?.map((item, i) => <li key={i}>{item.name} ({item.duration})</li>)}
                    </ul>
                </div>
                <div className="border-t border-gray-700 pt-3">
                    <h4 className="font-semibold text-gray-200 mb-2">{t('adaptiveWorkout.result.mainWorkout') as string}</h4>
                    {generatedPlan?.exercises?.map((ex, i) => (
                        <div key={i} className="flex justify-between items-center bg-gray-800/50 p-2 rounded-md mb-2">
                           <span className="font-semibold text-white flex-1">{ex.name}</span>
                           <div className="flex gap-4 text-xs">
                                <span>{ex.sets} sets</span>
                                <span>{ex.reps} reps</span>
                                <span>{ex.rest} rest</span>
                           </div>
                        </div>
                    ))}
                </div>
                <div className="border-t border-gray-700 pt-3">
                    <h4 className="font-semibold text-gray-200 mb-2">{t('adaptiveWorkout.result.cooldown') as string}</h4>
                     <ul className="list-disc list-inside space-y-1 pl-2 text-gray-400">
                        {generatedPlan?.cooldown?.map((item, i) => <li key={i}>{item.name} ({item.duration})</li>)}
                    </ul>
                </div>
            </div>
            
            <div className="flex gap-4 pt-4">
                 <button onClick={() => handleGenerate(true)} className="w-full bg-gray-600 text-white font-bold py-3 rounded-xl hover:bg-gray-700 transition-colors">
                    {t('adaptiveWorkout.result.regenerate') as string}
                </button>
                <button onClick={handleStartWorkout} className="w-full bg-green-500 text-white font-bold py-3 rounded-xl hover:bg-green-600 transition-colors">
                    {t('adaptiveWorkout.result.start') as string}
                </button>
            </div>
        </div>
    );


    return (
        <Modal title={t('adaptiveWorkout.title') as string} closeModal={closeModal} show={true}>
            {step === 'input' && renderInputStep()}
            {step === 'loading' && renderLoadingStep()}
            {step === 'result' && generatedPlan && renderResultStep()}
        </Modal>
    );
};

export default AdaptiveWorkoutModal;
