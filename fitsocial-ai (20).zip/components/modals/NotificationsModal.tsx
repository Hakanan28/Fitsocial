

import React from 'react';
import { useTranslation } from '../../hooks/i18n';
import { ModalType, Notification, NotificationType, UserProfile } from '../../types';

interface NotificationsModalProps {
    closeModal: () => void;
    notifications: Notification[];
    users: UserProfile[];
    markAsRead: (id: string) => void;
    markAllAsRead: () => void;
    openModal: (modal: ModalType, data?: any) => void;
}

const timeAgo = (timestamp: number): string => {
    const now = Date.now();
    const seconds = Math.floor((now - timestamp) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
}

const getIconForType = (type: NotificationType): string => {
    switch(type) {
        case NotificationType.Like: return '❤️';
        case NotificationType.Comment: return '💬';
        case NotificationType.Follow: return '👋';
        case NotificationType.Share: return '➡️';
        case NotificationType.Download: return '💾';
        case NotificationType.Security: return '🛡️';
        default: return '🔔';
    }
}


const NotificationsModal: React.FC<NotificationsModalProps> = ({ closeModal, notifications, markAsRead, markAllAsRead, openModal }) => {
    const { t } = useTranslation();
    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) {
            closeModal();
        }
    };

    const handleViewProfile = (e: React.MouseEvent, user: UserProfile) => {
        e.stopPropagation();
        openModal(ModalType.Profile, user);
    };

    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-0" onClick={handleOverlayClick}>
             <div className="bg-[#1E1E1E] w-full max-w-md h-full md:h-[80vh] md:max-h-[700px] rounded-none md:rounded-2xl shadow-2xl flex flex-col animate-slideIn">
                <header className="flex justify-between items-center p-4 border-b border-gray-700">
                    <h3 className="text-xl font-bold text-white">{t('notifications_modal.title')}</h3>
                    <div className="flex items-center gap-4">
                         <button onClick={markAllAsRead} className="text-sm text-green-400 font-semibold hover:text-green-300">Mark all as read</button>
                         <button onClick={closeModal} className="text-gray-400 hover:text-white text-2xl">&times;</button>
                    </div>
                </header>
                <div className="flex-1 overflow-y-auto">
                    {notifications.length > 0 ? (
                        notifications.map((n) => (
                            <div key={n.id} onClick={() => markAsRead(n.id)} className={`flex items-start p-4 space-x-3 cursor-pointer border-b border-gray-700 transition-colors ${!n.isRead ? 'bg-green-900/20 hover:bg-green-900/30' : 'hover:bg-gray-700/50'}`}>
                                <div className="relative cursor-pointer" onClick={(e) => handleViewProfile(e, n.actor)}>
                                    <img src={n.actor.avatarImage} alt={n.actor.username} className="w-10 h-10 rounded-full" />
                                    <span className="absolute -bottom-1 -right-1 text-lg">{getIconForType(n.type)}</span>
                                </div>
                                <div className="flex-1">
                                    <p className="text-sm text-white">
                                        <b className="font-semibold cursor-pointer hover:underline" onClick={(e) => handleViewProfile(e, n.actor)}>{n.actor.username}</b> <span className="text-gray-300">{n.message}</span>
                                    </p>
                                    <span className="text-xs text-gray-500">{timeAgo(n.timestamp)}</span>
                                </div>
                                {n.contentPreview && (
                                     <img src={n.contentPreview} alt="Content preview" className="w-12 h-12 object-cover rounded-md flex-shrink-0" />
                                )}
                                {!n.isRead && <div className="w-2.5 h-2.5 bg-green-400 rounded-full self-center flex-shrink-0"></div>}
                            </div>
                        ))
                    ) : (
                        <div className="text-center text-gray-500 py-20">
                            <span className="text-4xl">🔕</span>
                            <p className="mt-4 font-semibold">All caught up!</p>
                            <p className="text-sm">You have no new notifications.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default NotificationsModal;
