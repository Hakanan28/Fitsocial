import React, { useState, useRef, useEffect } from 'react';
import { ModalType, UserProfile, Post, Reel, Story } from '../../types';
import { useTranslation } from '../../hooks/i18n';

interface UnifiedCreateModalProps {
    closeModal: () => void;
    openModal: (modal: ModalType, data?: any) => void;
    onMediaSelected: (file: File, type: ContentType) => void;
    handleCreatePost: (postData: Omit<Post, 'id' | 'author' | 'avatarText' | 'likes' | 'comments' | 'isLiked'>) => void;
    handleCreateReel: (reelData: Omit<Reel, 'id' | 'user' | 'likes' | 'comments' | 'isLiked'>) => void;
    handleCreateStory: (storyData: Omit<Story, 'user' | 'avatarImage'>) => void;
    currentUser: UserProfile;
    users: UserProfile[];
    modalData?: any;
}

type ContentType = 'post' | 'reel' | 'story';

const AiToolCard: React.FC<{ icon: React.ReactNode; title: string; description: string; onClick: () => void; color: 'emerald' | 'purple' | 'cyan' | 'amber' | 'rose' | 'sky' | 'teal'; }> = ({ icon, title, description, onClick, color }) => {
    const colorClasses = {
        emerald: { glow: 'group-hover:shadow-[0_0_40px_rgba(16,185,129,0.7)]', border: 'group-hover:border-emerald-500/80', text: 'text-emerald-400', iconGlow: 'group-hover:shadow-[0_0_30px_rgba(16,185,129,0.8)]' },
        purple: { glow: 'group-hover:shadow-[0_0_40px_rgba(168,85,247,0.7)]', border: 'group-hover:border-purple-500/80', text: 'text-purple-400', iconGlow: 'group-hover:shadow-[0_0_30px_rgba(168,85,247,0.8)]' },
        cyan: { glow: 'group-hover:shadow-[0_0_40px_rgba(6,182,212,0.7)]', border: 'group-hover:border-cyan-500/80', text: 'text-cyan-400', iconGlow: 'group-hover:shadow-[0_0_30px_rgba(6,182,212,0.8)]' },
        amber: { glow: 'group-hover:shadow-[0_0_40px_rgba(245,158,11,0.7)]', border: 'group-hover:border-amber-500/80', text: 'text-amber-400', iconGlow: 'group-hover:shadow-[0_0_30px_rgba(245,158,11,0.8)]' },
        rose: { glow: 'group-hover:shadow-[0_0_40px_rgba(244,63,94,0.7)]', border: 'group-hover:border-rose-500/80', text: 'text-rose-400', iconGlow: 'group-hover:shadow-[0_0_30px_rgba(244,63,94,0.8)]' },
        sky: { glow: 'group-hover:shadow-[0_0_40px_rgba(56,189,248,0.7)]', border: 'group-hover:border-sky-500/80', text: 'text-sky-400', iconGlow: 'group-hover:shadow-[0_0_30px_rgba(56,189,248,0.8)]' },
        teal: { glow: 'group-hover:shadow-[0_0_40px_rgba(20,184,166,0.7)]', border: 'group-hover:border-teal-500/80', text: 'text-teal-400', iconGlow: 'group-hover:shadow-[0_0_30px_rgba(20,184,166,0.8)]' },
    };
    const classes = colorClasses[color];

    return (
        <button onClick={onClick} className={`relative p-4 w-full bg-glass-surface rounded-2xl border border-glass-border backdrop-blur-xl transition-all duration-300 group ${classes.border} ${classes.glow} text-left flex flex-col items-center text-center gap-4 overflow-hidden`}>
            <div className={`relative flex-shrink-0 w-20 h-20 rounded-lg bg-black/50 flex items-center justify-center transition-all duration-300 group-hover:scale-110 ${classes.text} ${classes.iconGlow}`}>
                {icon}
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent rounded-lg opacity-80"></div>
            </div>
            <div>
                <h4 className="font-bold text-white text-base">{title}</h4>
                <p className="text-xs text-slate-400 mt-1 leading-tight">{description}</p>
            </div>
        </button>
    );
};


const UnifiedCreateModal: React.FC<UnifiedCreateModalProps> = ({ closeModal, openModal, onMediaSelected, handleCreatePost, handleCreateReel, handleCreateStory, currentUser, users, modalData }) => {
    const [contentType, setContentType] = useState<ContentType | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { t } = useTranslation();

    useEffect(() => {
        if (modalData?.contentType) {
            triggerFileInput(modalData.contentType);
        }
    }, [modalData]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file && contentType) {
            onMediaSelected(file, contentType);
        }
    };

    const triggerFileInput = (type: ContentType) => {
        setContentType(type);
        fileInputRef.current?.setAttribute('accept', type === 'post' || type === 'story' ? 'image/*,video/*' : 'video/*');
        fileInputRef.current?.click();
    };
    
    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) {
            closeModal();
        }
    };

    const aiTools = [
        { icon: <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m22 8-6 4 6 4V8Z"/><rect width="14" height="12" x="2" y="6" rx="2" ry="2"/></svg>, title: t('create.aiTools.genVideo.title') as string, description: t('create.aiTools.genVideo.description') as string, onClick: () => openModal(ModalType.VideoGeneration), color: 'cyan' as const },
        { icon: <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>, title: t('create.aiTools.genImage.title') as string, description: t('create.aiTools.genImage.description') as string, onClick: () => openModal(ModalType.ImageGeneration), color: 'purple' as const },
        { icon: <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>, title: t('create.aiTools.editImage.title') as string, description: t('create.aiTools.editImage.description') as string, onClick: () => openModal(ModalType.ImageEditing), color: 'emerald' as const },
        { icon: <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M12 5v2"/><path d="M12 17v2"/><path d="M5 12h2"/><path d="M17 12h2"/></svg>, title: t('create.aiTools.analyze.title') as string, description: t('create.aiTools.analyze.description') as string, onClick: () => openModal(ModalType.ContentAnalysis), color: 'amber' as const },
        { icon: <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20.2 6 3 11l-.9-2.4c-.3-1.1.4-2.2 1.5-2.5l13-3.2c-1.1-.3-2.2.4-2.5 1.5L20.2 6Z"/><path d="m7 11 13 4.8.9 2.4c.3 1.1-.4 2.2-1.5 2.5l-13 3.2c-1.1.3-2.2-.4-2.5-1.5L3 11Z"/></svg>, title: t('create.aiTools.genReel.title') as string, description: t('create.aiTools.genReel.description') as string, onClick: () => openModal(ModalType.AiReelGenerator), color: 'rose' as const },
        { icon: <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"/><path d="M12 12v9"/><path d="M8 17l4 4 4-4"/></svg>, title: t('create.aiTools.tts.title') as string, description: t('create.aiTools.tts.description') as string, onClick: () => openModal(ModalType.TextToSpeech), color: 'sky' as const },
        { icon: <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>, title: t('create.aiTools.stt.title') as string, description: t('create.aiTools.stt.description') as string, onClick: () => openModal(ModalType.SpeechToText), color: 'teal' as const }
    ];

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xl z-[200] flex items-end" onClick={handleOverlayClick}>
            <div 
                className="bg-[#0B0E14] border-t border-glass-border rounded-t-[28px] w-full max-h-[85vh] flex flex-col animate-slideInUp"
                onClick={e => e.stopPropagation()}
            >
                <div className="w-12 h-1.5 bg-gray-700 rounded-full mx-auto my-3 flex-shrink-0"></div>
                
                <header className="flex-shrink-0 flex justify-between items-center px-6 pb-4">
                    <h2 className="text-2xl font-extrabold text-white">{t('create.title')}</h2>
                    <button onClick={closeModal} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                    </button>
                </header>

                <main className="flex-1 overflow-y-auto space-y-6 px-6 pb-6 no-scrollbar">
                    <section>
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">{t('create.contentType')}</h3>
                        <div className="grid grid-cols-3 gap-3">
                             <button onClick={() => triggerFileInput('post')} className="h-40 bg-glass-surface rounded-2xl border border-glass-border hover:bg-white/10 transition-colors flex flex-col items-center justify-center gap-3 group"><span className="text-6xl transition-transform group-hover:scale-110">📝</span><span className="text-lg font-bold text-white">{t('create.post')}</span></button>
                            <button onClick={() => triggerFileInput('reel')} className="h-40 bg-glass-surface rounded-2xl border border-glass-border hover:bg-white/10 transition-colors flex flex-col items-center justify-center gap-3 group"><span className="text-6xl transition-transform group-hover:scale-110">🎬</span><span className="text-lg font-bold text-white">{t('create.reel')}</span></button>
                            <button onClick={() => triggerFileInput('story')} className="h-40 bg-glass-surface rounded-2xl border border-glass-border hover:bg-white/10 transition-colors flex flex-col items-center justify-center gap-3 group"><span className="text-6xl transition-transform group-hover:scale-110">⚡️</span><span className="text-lg font-bold text-white">{t('create.story')}</span></button>
                        </div>
                        <input type="file" ref={fileInputRef} onChange={(e) => contentType && handleFileChange(e)} className="hidden" />
                    </section>
                    
                    <section>
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">{t('create.aiStudioTitle')}</h3>
                        <div className="grid grid-cols-2 gap-4">
                            {aiTools.map(tool => <AiToolCard key={tool.title as string} {...tool} />)}
                        </div>
                    </section>
                </main>
            </div>
        </div>
    );
};

export default UnifiedCreateModal;
