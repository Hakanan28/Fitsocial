
import React, { useState, useRef } from 'react';
import { Post, UserProfile, ModalType } from '../../types';
import { findUser } from '../../data/users';
import CommentsOverlay from '../ui/CommentsOverlay';

interface PostDetailModalProps {
    closeModal: () => void;
    post: Post;
    openModal: (modal: ModalType, data?: any) => void;
    handleLikePost: (id: number) => void;
    onAddComment: (id: number, text: string) => void;
    viewUserProfile: (user: UserProfile) => void;
    users: UserProfile[];
    currentUser?: UserProfile; // Added to props to support comments
}

const PostDetailModal: React.FC<PostDetailModalProps> = ({
    closeModal,
    post,
    openModal,
    handleLikePost,
    onAddComment,
    viewUserProfile,
    users,
    currentUser // Assume this is passed or we find it (better to pass it from App)
}) => {
    const [showHeartAnimation, setShowHeartAnimation] = useState(false);
    const [showComments, setShowComments] = useState(false);
    const clickTimeoutRef = useRef<any>(null);

    // If currentUser is not passed (legacy compatibility), try to find it or mock it
    // Ideally, App.tsx should pass currentUser to PostDetailModal
    const effectiveCurrentUser = currentUser || users[0]; 

    const handleMediaClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (clickTimeoutRef.current) {
            clearTimeout(clickTimeoutRef.current);
            clickTimeoutRef.current = null;
            if (!post.isLiked) {
                handleLikePost(post.id);
            }
            setShowHeartAnimation(true);
            setTimeout(() => setShowHeartAnimation(false), 800);
        } else {
            clickTimeoutRef.current = setTimeout(() => {
                clickTimeoutRef.current = null;
                // Single click could toggle controls, but we keep it simple
            }, 250);
        }
    };

    const handleProfileClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        const user = findUser(post.author, users);
        if (user) viewUserProfile(user);
    };

    const handleLike = (e: React.MouseEvent) => {
        e.stopPropagation();
        handleLikePost(post.id);
    };

    const handleCommentClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setShowComments(true);
    };

    return (
        <div className="fixed inset-0 bg-black z-[200] flex flex-col animate-fadeIn">
            
            {/* Top Bar (Overlay) */}
            <div className="absolute top-0 left-0 right-0 p-4 z-50 flex justify-between items-center bg-gradient-to-b from-black/60 to-transparent pointer-events-none">
                <div className="pointer-events-auto" onClick={closeModal}>
                     <button className="text-white drop-shadow-md p-2 rounded-full hover:bg-white/10 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
                    </button>
                </div>
                <div className="text-white font-bold text-sm shadow-black drop-shadow-md">Post</div>
                <div className="w-8"></div>
            </div>

            {/* Main Media Area */}
            <div 
                className="flex-1 relative w-full h-full flex items-center justify-center overflow-hidden bg-black"
                onClick={handleMediaClick}
            >
                {post.mediaType === 'video' ? (
                    <video 
                        src={post.mediaUrl} 
                        className="w-full h-full object-contain" 
                        style={{ filter: post.filter }}
                        controls={false} 
                        autoPlay 
                        loop 
                        playsInline
                        muted={false}
                    />
                ) : (
                    <img 
                        src={post.mediaUrl} 
                        alt={post.caption} 
                        className="w-full h-full object-contain"
                        style={{ filter: post.filter }}
                    />
                )}

                {showHeartAnimation && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-40">
                        <svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 24 24" fill="#ef4444" stroke="none" className="animate-like drop-shadow-2xl opacity-90"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                    </div>
                )}

                {/* Right Side Actions (Vertical Stack) */}
                <div className="absolute bottom-20 right-3 flex flex-col items-center gap-5 z-40 pointer-events-auto pb-6">
                    <div className="flex flex-col items-center gap-1">
                        <button onClick={handleProfileClick} className="w-10 h-10 rounded-full border-2 border-white overflow-hidden mb-2 shadow-lg">
                            <img src={`https://placehold.co/100x100/333/FFF?text=${post.avatarText}`} className="w-full h-full object-cover" alt={post.author} />
                        </button>
                    </div>

                    <button onClick={handleLike} className="flex flex-col items-center gap-1 group">
                        <div className="p-2 rounded-full group-active:scale-90 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill={post.isLiked ? "#ef4444" : "rgba(0,0,0,0.2)"} stroke={post.isLiked ? "#ef4444" : "white"} strokeWidth="2" className={`drop-shadow-lg ${post.isLiked ? 'scale-110' : ''}`}><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                        </div>
                        <span className="text-xs font-bold text-white drop-shadow-md">{post.likes}</span>
                    </button>

                    <button onClick={handleCommentClick} className="flex flex-col items-center gap-1 group">
                        <div className="p-2 rounded-full group-active:scale-90 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="rgba(0,0,0,0.2)" stroke="white" strokeWidth="2" className="drop-shadow-lg"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                        </div>
                        <span className="text-xs font-bold text-white drop-shadow-md">{post.comments.length}</span>
                    </button>

                    <button onClick={() => openModal(ModalType.SharePost, { mediaUrl: post.mediaUrl, author: post.author })} className="flex flex-col items-center gap-1 group">
                        <div className="p-2 rounded-full group-active:scale-90 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="rgba(0,0,0,0.2)" stroke="white" strokeWidth="2" className="drop-shadow-lg"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                        </div>
                        <span className="text-xs font-bold text-white drop-shadow-md">Share</span>
                    </button>
                </div>

                {/* Bottom Info Overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-4 pb-8 pointer-events-none z-30 bg-gradient-to-t from-black/90 via-black/40 to-transparent">
                    <div className="flex flex-col pr-16 pointer-events-auto">
                        <div className="flex items-center gap-2 mb-2" onClick={handleProfileClick}>
                            <h4 className="font-bold text-white text-sm shadow-black drop-shadow-md">{post.author}</h4>
                            {post.location && <span className="text-[10px] text-gray-300 flex items-center gap-1">📍 {post.location}</span>}
                        </div>
                        <p className="text-sm text-gray-200 leading-snug shadow-black drop-shadow-md line-clamp-3">
                            {post.caption}
                        </p>
                        {/* Tags if any */}
                        {post.taggedUsers && post.taggedUsers.length > 0 && (
                            <div className="flex gap-1 mt-2 flex-wrap">
                                {post.taggedUsers.map(u => (
                                    <span key={u} className="text-[10px] font-bold text-blue-400">@{u}</span>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Comments Overlay */}
            <CommentsOverlay 
                isOpen={showComments}
                onClose={() => setShowComments(false)}
                comments={post.comments}
                currentUser={effectiveCurrentUser}
                users={users}
                onAddComment={(text) => onAddComment(post.id, text)}
            />
        </div>
    );
};

export default PostDetailModal;
