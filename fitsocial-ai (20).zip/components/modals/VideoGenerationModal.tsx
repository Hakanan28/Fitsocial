
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { generateVideo, getVideoOperationStatus } from '../../services/geminiService';
import Modal from '../ui/Modal';

interface VideoGenerationModalProps {
    closeModal: () => void;
}

const loadingMessages = [
    "Initializing Veo Motion Engine...",
    "Directing the scene...",
    "Rendering light physics...",
    "Synthesizing frames...",
    "Finalizing cinematic output...",
];

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = error => reject(error);
    });
};

const VideoGenerationModal: React.FC<VideoGenerationModalProps> = ({ closeModal }) => {
    const [prompt, setPrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [apiKeySelected, setApiKeySelected] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
    
    const intervalRef = useRef<number | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const checkApiKey = useCallback(async () => {
        if (window.aistudio && await window.aistudio.hasSelectedApiKey()) {
            setApiKeySelected(true);
        } else {
            setApiKeySelected(false);
        }
    }, []);

    useEffect(() => {
        checkApiKey();
    }, []);

    useEffect(() => {
        if (isLoading) {
            intervalRef.current = window.setInterval(() => {
                setLoadingMessage(prev => {
                    const currentIndex = loadingMessages.indexOf(prev);
                    return loadingMessages[(currentIndex + 1) % loadingMessages.length];
                });
            }, 3000);
        } else {
            if(intervalRef.current) clearInterval(intervalRef.current);
        }
        return () => {
            if(intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [isLoading]);
    
    const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setImageFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleGenerate = async () => {
        if ((!prompt.trim() && !imageFile) || !apiKeySelected) return;

        setIsLoading(true);
        setVideoUrl(null);
        setError(null);

        try {
            let imagePayload: { imageBytes: string; mimeType: string } | undefined = undefined;
            if (imageFile) {
                const imageBytes = await fileToBase64(imageFile);
                imagePayload = { imageBytes, mimeType: imageFile.type };
            }

            let operation = await generateVideo(prompt, aspectRatio, imagePayload);
            
            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000));
                try {
                    operation = await getVideoOperationStatus(operation);
                } catch (e: any) {
                    if (e.message?.includes("Requested entity was not found.")) {
                       setError("API Key error. Please re-select your key.");
                       setApiKeySelected(false);
                       setIsLoading(false);
                       return;
                    }
                    throw e;
                }
            }

            const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
            if (downloadLink) {
                const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                setVideoUrl(url);
            } else {
                setError("Video generation failed. No video URI returned.");
            }
        } catch (err) {
            console.error(err);
            setError("An error occurred during video generation.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleSelectKey = async () => {
        if(window.aistudio) {
            await window.aistudio.openSelectKey();
            setApiKeySelected(true);
            setError(null);
        }
    };

    return (
        <Modal title="🎥 Veo Motion Engine" closeModal={closeModal} show={true}>
            <div className="relative z-10 flex flex-col gap-5">
                {/* Background Glows */}
                <div className="absolute top-0 right-0 w-40 h-40 bg-cyan-500/10 rounded-full blur-[60px] pointer-events-none"></div>

                {!apiKeySelected ? (
                    <div className="bg-cyan-900/20 border border-cyan-500/30 p-6 rounded-2xl text-center backdrop-blur-sm">
                        <div className="w-12 h-12 bg-cyan-500/20 rounded-full flex items-center justify-center mx-auto mb-3 text-cyan-400">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
                        </div>
                        <p className="text-cyan-200 font-bold mb-2">Access Required</p>
                        <p className="text-cyan-400/60 text-xs mb-4">To unleash the Veo Motion Engine, please verify your API access.</p>
                        <button onClick={handleSelectKey} className="bg-cyan-500 text-black font-bold py-2 px-6 rounded-lg hover:bg-cyan-400 transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(6,182,212,0.3)]">
                            Connect API Key
                        </button>
                    </div>
                ) : (
                    <>
                        {/* Image Input (Optional) */}
                         <div>
                            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1 mb-2 block">Reference Image (Optional)</label>
                            <div 
                                onClick={() => !isLoading && fileInputRef.current?.click()}
                                className={`relative w-full h-20 rounded-xl border border-dashed border-gray-700 bg-[#0a0a0a] flex items-center justify-center cursor-pointer hover:border-cyan-500/50 transition-colors overflow-hidden group ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                            >
                                {imagePreview ? (
                                    <>
                                        <img src={imagePreview} alt="Ref" className="w-full h-full object-cover opacity-50 group-hover:opacity-30 transition-opacity" />
                                        <div className="absolute inset-0 flex items-center justify-center">
                                            <span className="text-xs font-bold text-white bg-black/50 px-2 py-1 rounded">Change Image</span>
                                        </div>
                                    </>
                                ) : (
                                    <div className="flex items-center gap-2 text-gray-500 group-hover:text-cyan-400 transition-colors">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
                                        <span className="text-xs font-medium">Upload Start Frame</span>
                                    </div>
                                )}
                                <input
                                    ref={fileInputRef}
                                    type="file"
                                    accept="image/*"
                                    onChange={handleImageFileChange}
                                    className="hidden"
                                    disabled={isLoading}
                                />
                            </div>
                        </div>

                        {/* Text Prompt */}
                        <div>
                            <label className="text-[10px] font-bold text-cyan-500 uppercase tracking-widest ml-1 mb-2 block">Director's Prompt</label>
                             <textarea
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder={imageFile ? "Describe how the image should move..." : "Describe a scene: 'A neon hologram of a cat driving at top speed'"}
                                className="w-full h-28 p-4 bg-[#0a0a0a] text-white rounded-xl border border-white/10 focus:border-cyan-500/50 focus:ring-0 transition-all resize-none placeholder-gray-600 text-sm leading-relaxed"
                                disabled={isLoading}
                            />
                        </div>

                        {/* Settings Row */}
                        <div className="flex items-center justify-between bg-[#0a0a0a] p-2 rounded-lg border border-white/5">
                            <span className="text-xs text-gray-400 font-medium ml-2">Format</span>
                            <div className="flex bg-white/5 p-1 rounded-md">
                                <button 
                                    onClick={() => setAspectRatio('16:9')}
                                    className={`px-3 py-1 rounded text-[10px] font-bold transition-all ${aspectRatio === '16:9' ? 'bg-cyan-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}
                                >
                                    16:9
                                </button>
                                <button 
                                    onClick={() => setAspectRatio('9:16')}
                                    className={`px-3 py-1 rounded text-[10px] font-bold transition-all ${aspectRatio === '9:16' ? 'bg-cyan-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}
                                >
                                    9:16
                                </button>
                            </div>
                        </div>

                        {/* Generate Button */}
                        <button
                            onClick={handleGenerate}
                            disabled={isLoading || (!prompt.trim() && !imageFile)}
                            className="group relative w-full py-4 rounded-xl font-bold text-white overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-cyan-900/20 mt-2"
                        >
                            <div className="absolute inset-0 bg-gradient-to-r from-cyan-600 via-blue-600 to-cyan-600 bg-[length:200%_auto] animate-gradient-x"></div>
                            <div className="relative flex items-center justify-center gap-2">
                                {isLoading ? (
                                    <>
                                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                                        <span className="tracking-wider text-sm uppercase">Rendering...</span>
                                    </>
                                ) : (
                                    <>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                                        <span className="tracking-wider text-sm uppercase">Action!</span>
                                    </>
                                )}
                            </div>
                        </button>
                    </>
                )}
                
                {/* Loading State Overlay */}
                {isLoading && (
                    <div className="bg-[#0a0a0a]/80 absolute inset-0 z-20 rounded-xl flex flex-col items-center justify-center backdrop-blur-sm">
                         <div className="w-16 h-16 relative">
                             <div className="absolute inset-0 rounded-full border-4 border-cyan-900"></div>
                             <div className="absolute inset-0 rounded-full border-4 border-cyan-500 border-t-transparent animate-spin"></div>
                         </div>
                         <p className="text-cyan-300 mt-4 font-mono text-xs animate-pulse">{loadingMessage}</p>
                    </div>
                )}

                {/* Error Message */}
                {error && <p className="text-red-400 text-center text-xs bg-red-900/20 p-2 rounded border border-red-500/20">{error}</p>}

                {/* Result Video */}
                {videoUrl && (
                    <div className="mt-2 animate-fadeIn p-1 bg-gradient-to-b from-cyan-500/20 to-transparent rounded-2xl">
                        <div className="bg-black rounded-xl overflow-hidden shadow-2xl">
                            <video src={videoUrl} controls autoPlay loop className="w-full rounded-lg" />
                        </div>
                    </div>
                )}
            </div>
        </Modal>
    );
};

export default VideoGenerationModal;
