import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import { Challenge, UserProfile } from '../../types';

interface CreateChallengeModalProps {
    closeModal: () => void;
    showNotification: (message: string, type?: 'success' | 'error') => void;
    handleCreateChallenge: (challengeData: Omit<Challenge, 'id' | 'creator' | 'participants'>) => void;
    currentUser: UserProfile;
}

const CATEGORIES = [
    { id: 'cardio', label: 'Cardio', icon: '🏃‍♂️', suggestions: ['Run 5km daily', '10,000 Steps', '30 min Cycling'] },
    { id: 'strength', label: 'Strength', icon: '💪', suggestions: ['100 Pushups', '50 Pullups', 'Max Plank'] },
    { id: 'flexibility', label: 'Flexibility', icon: '🧘‍♀️', suggestions: ['20 min Yoga', 'Daily Stretching', 'Split Training'] },
    { id: 'mindset', label: 'Mindset', icon: '🧠', suggestions: ['10 min Meditation', 'Read 10 pages', 'Cold Shower'] },
    { id: 'hydration', label: 'Health', icon: '💧', suggestions: ['3L Water', 'No Sugar', 'Eat Greens'] },
];

const DIFFICULTIES = ['Beginner', 'Intermediate', 'Advanced', 'Elite'];

const CreateChallengeModal: React.FC<CreateChallengeModalProps> = ({ closeModal, showNotification, handleCreateChallenge }) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [duration, setDuration] = useState(7);
    const [goal, setGoal] = useState('');
    const [prizePool, setPrizePool] = useState<number>(0);
    const [selectedCategory, setSelectedCategory] = useState(CATEGORIES[0]);
    const [selectedDifficulty, setSelectedDifficulty] = useState('Intermediate');
    const [privacy, setPrivacy] = useState<'public' | 'friends'>('public');

    // Smart preset handler
    const handlePresetClick = (suggestion: string) => {
        setGoal(suggestion);
    };

    const handleCreate = () => {
        if (!title.trim() || !description.trim() || !goal.trim()) {
            showNotification("Please fill out all required fields.", "error");
            return;
        }

        // Enriched description with metadata tags since we can't change the DB schema types
        const enrichedDescription = `${description}\n\n----------------\n🏷️ Category: ${selectedCategory.label}\n🔥 Difficulty: ${selectedDifficulty}\n🔒 Privacy: ${privacy === 'public' ? 'Public' : 'Friends Only'}`;

        // Prepend icon to title for visual flair
        const enrichedTitle = `${selectedCategory.icon} ${title}`;

        handleCreateChallenge({
            title: enrichedTitle,
            description: enrichedDescription,
            duration,
            goal,
            prizePool,
            isAiChallenge: false
        });
        closeModal();
    };

    return (
        <Modal title="🚀 Create Challenge" closeModal={closeModal} show={true}>
            <div className="space-y-6 animate-fadeIn pb-4">
                
                {/* Category Selector */}
                <div>
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-3">Choose Category</label>
                    <div className="grid grid-cols-5 gap-2">
                        {CATEGORIES.map((cat) => (
                            <button
                                key={cat.id}
                                onClick={() => setSelectedCategory(cat)}
                                className={`flex flex-col items-center justify-center p-2 rounded-xl border-2 transition-all ${selectedCategory.id === cat.id ? 'border-green-500 bg-green-500/20 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)]' : 'border-gray-700 bg-gray-800 text-gray-400 hover:bg-gray-700 hover:border-gray-500'}`}
                            >
                                <span className="text-2xl mb-1">{cat.icon}</span>
                                <span className="text-[9px] font-bold">{cat.label}</span>
                            </button>
                        ))}
                    </div>
                </div>

                {/* Basic Info */}
                <div className="space-y-3">
                    <div>
                        <label htmlFor="challenge-title" className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-1">Challenge Title</label>
                        <input
                            type="text"
                            id="challenge-title"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            placeholder="e.g. Summer Shred 2024"
                            className="w-full p-3 bg-gray-900 text-white rounded-xl border border-gray-700 focus:border-green-500 focus:ring-1 focus:ring-green-500/50 transition-all font-bold placeholder-gray-600"
                        />
                    </div>
                    
                    <div>
                        <label htmlFor="challenge-goal" className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-1">Daily Goal</label>
                        <input
                            type="text"
                            id="challenge-goal"
                            value={goal}
                            onChange={(e) => setGoal(e.target.value)}
                            placeholder={`e.g. ${selectedCategory.suggestions[0]}`}
                            className="w-full p-3 bg-gray-900 text-white rounded-xl border border-gray-700 focus:border-green-500 focus:ring-1 focus:ring-green-500/50 transition-all"
                        />
                        {/* Smart Suggestions */}
                        <div className="flex gap-2 mt-2 overflow-x-auto scrollbar-hide">
                            {selectedCategory.suggestions.map((s, i) => (
                                <button 
                                    key={i} 
                                    onClick={() => handlePresetClick(s)}
                                    className="whitespace-nowrap px-3 py-1 rounded-full bg-gray-800 border border-gray-600 text-[10px] text-gray-300 hover:bg-green-500/20 hover:border-green-500 hover:text-green-400 transition-colors"
                                >
                                    + {s}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-1">Difficulty</label>
                        <select 
                            value={selectedDifficulty} 
                            onChange={(e) => setSelectedDifficulty(e.target.value)}
                            className="w-full p-3 bg-gray-900 text-white rounded-xl border border-gray-700 focus:border-green-500"
                        >
                            {DIFFICULTIES.map(d => <option key={d} value={d}>{d}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-1">Prize Pool ($FIT)</label>
                        <input
                            type="number"
                            value={prizePool}
                            onChange={(e) => setPrizePool(Number(e.target.value))}
                            className="w-full p-3 bg-gray-900 text-white rounded-xl border border-gray-700 focus:border-green-500 font-mono"
                            placeholder="0"
                        />
                    </div>
                </div>

                {/* Duration Slider */}
                <div>
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-1">Duration: <span className="text-white">{duration} Days</span></label>
                    <div className="flex items-center bg-gray-900 rounded-xl border border-gray-700 p-3">
                        <span className="text-xs text-gray-500 mr-2">1d</span>
                        <input
                            type="range"
                            min="1"
                            max="30"
                            value={duration}
                            onChange={(e) => setDuration(parseInt(e.target.value, 10))}
                            className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-green-500"
                        />
                        <span className="text-xs text-gray-500 ml-2">30d</span>
                    </div>
                </div>

                {/* Description */}
                <div>
                    <label htmlFor="challenge-desc" className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-1">Mission Brief</label>
                    <textarea
                        id="challenge-desc"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        rows={3}
                        placeholder="Describe the rules and motivation..."
                        className="w-full p-3 bg-gray-900 text-white rounded-xl border border-gray-700 focus:border-green-500 transition-all text-sm resize-none"
                    />
                </div>

                {/* Privacy Toggle */}
                <div className="flex items-center justify-between bg-gray-800/50 p-3 rounded-xl border border-gray-700">
                    <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${privacy === 'public' ? 'bg-blue-500/20 text-blue-400' : 'bg-purple-500/20 text-purple-400'}`}>
                            {privacy === 'public' ? (
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="2" x2="22" y1="12" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                            ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                            )}
                        </div>
                        <div>
                            <p className="text-sm font-bold text-white">{privacy === 'public' ? 'Public Challenge' : 'Friends Only'}</p>
                            <p className="text-[10px] text-gray-400">{privacy === 'public' ? 'Anyone on FitSocial can join' : 'Only your followers can join'}</p>
                        </div>
                    </div>
                    <button 
                        onClick={() => setPrivacy(prev => prev === 'public' ? 'friends' : 'public')}
                        className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${privacy === 'public' ? 'bg-blue-600' : 'bg-purple-600'}`}
                    >
                        <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${privacy === 'friends' ? 'translate-x-6' : 'translate-x-1'}`} />
                    </button>
                </div>

                <button onClick={handleCreate} className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 rounded-xl font-black text-lg shadow-[0_0_20px_rgba(16,185,129,0.4)] hover:shadow-[0_0_30px_rgba(16,185,129,0.6)] transition-all transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2">
                    <span>🚀 LAUNCH CHALLENGE</span>
                </button>
            </div>
        </Modal>
    );
};

export default CreateChallengeModal;