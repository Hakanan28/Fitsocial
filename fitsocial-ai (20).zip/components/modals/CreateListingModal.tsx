import React, { useState, useRef, useEffect } from 'react';
import { NFT, GearItem, UserProfile, ItemDesign, CustomLayout, CustomLayoutElement } from '../../types';
import { generateText, analyzeContent } from '../../services/geminiService';
import ProductDetailModal from './ProductDetailModal';

interface CreateListingModalProps {
    closeModal: () => void;
    handleCreateNFT: (nft: NFT) => void;
    handleCreateGear: (gear: GearItem) => void;
    currentUser: UserProfile;
}

type Currency = '$' | 'FIT';
type ListingType = 'fixed' | 'auction';
type DrawingTool = 'pencil' | 'line' | 'rect' | 'circle' | 'star' | 'arrow' | 'text' | 'eraser' | 'select';

interface UploadedMedia {
    id: string;
    url: string;
    type: 'image' | 'video';
    file: File;
}

interface SpecItem {
    id: string;
    key: string;
    value: string;
}

// Canvas Object Interface for Vector-like manipulation
interface CanvasObject {
    id: string;
    type: DrawingTool;
    x: number;
    y: number;
    w?: number; // width or endX
    h?: number; // height or endY
    text?: string;
    points?: {x: number, y: number}[]; // For pencil
    color: string;
}

// Helper: Convert File to Data URL
const fileToDataUrl = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
    });
};


// Helper Components for Form Layout
const FormSection = ({ title, icon, children }: { title: string, icon: string, children?: React.ReactNode }) => (
    <div className="bg-[#121212] rounded-3xl p-6 border border-white/5 relative overflow-hidden group hover:border-white/10 transition-all">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-5 flex items-center gap-2 pb-2 border-b border-white/5">
            <span className="text-lg p-1.5 bg-white/5 rounded-lg">{icon}</span> {title}
        </h3>
        <div className="space-y-5 relative z-10">
            {children}
        </div>
    </div>
);

const InputGroup = ({ label, children }: { label: string, children?: React.ReactNode }) => (
    <div className="group">
        <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 block group-focus-within:text-emerald-400 transition-colors">{label}</label>
        {children}
    </div>
);

const ProInput = ({ label, value, onChange, placeholder, type = "text", prefix, suffix, className }: any) => (
    <div className={`group ${className}`}>
        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5 block group-focus-within:text-emerald-400 transition-colors">{label}</label>
        <div className="relative flex items-center bg-[#0A0A0A] border border-gray-800 rounded-xl overflow-hidden group-focus-within:border-emerald-500/50 group-focus-within:ring-1 group-focus-within:ring-emerald-500/20 transition-all shadow-inner">
            {prefix && <div className="pl-3 text-gray-500 text-sm font-bold select-none">{prefix}</div>}
            <input 
                type={type} 
                value={value} 
                onChange={onChange} 
                placeholder={placeholder} 
                className="w-full bg-transparent border-none text-white px-3 py-3 text-sm focus:ring-0 placeholder-gray-700 font-medium" 
            />
            {suffix && <div className="pr-3 text-gray-500 text-xs font-bold select-none">{suffix}</div>}
        </div>
    </div>
);

const CreateListingModal: React.FC<CreateListingModalProps> = ({ closeModal, handleCreateNFT, handleCreateGear, currentUser }) => {
    const [activeTab, setActiveTab] = useState<'nft' | 'gear'>('gear');
    const [step, setStep] = useState<'edit' | 'review' | 'design'>('edit');
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    // --- AI & Loading ---
    const [isAiLoading, setIsAiLoading] = useState(false);
    const [magicFillInput, setMagicFillInput] = useState('');

    // --- Common Data ---
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [mediaFiles, setMediaFiles] = useState<UploadedMedia[]>([]);
    const [coverImageId, setCoverImageId] = useState<string | null>(null);
    const [price, setPrice] = useState('');
    const [currency, setCurrency] = useState<Currency>('$');

    // --- Gear Data (Physical) ---
    const [category, setCategory] = useState('Supplement');
    const [condition, setCondition] = useState('New');
    const [brand, setBrand] = useState('');
    const [specs, setSpecs] = useState<SpecItem[]>([]);
    const [stock, setStock] = useState('1');
    const [sku, setSku] = useState('');
    const [barcode, setBarcode] = useState('');
    const [weight, setWeight] = useState('');
    const [dimensions, setDimensions] = useState({ l: '', w: '', h: '' });
    const [shippingCarrier, setShippingCarrier] = useState('Standard');
    const [deliveryTime, setDeliveryTime] = useState('3-5 Days');
    
    // --- NFT Data (Digital) ---
    const [listingType, setListingType] = useState<ListingType>('fixed');
    const [blockchain, setBlockchain] = useState('ETH');
    const [royalties, setRoyalties] = useState('5');
    const [collection, setCollection] = useState('');
    const [nftProperties, setNftProperties] = useState<SpecItem[]>([]);
    const [auctionDuration, setAuctionDuration] = useState('7 Days');
    const [reservePrice, setReservePrice] = useState('');

    // --- Profit Calc Data ---
    const [costPerItem, setCostPerItem] = useState('');

    // --- Design Studio State (Advanced) ---
    const [customDesign, setCustomDesign] = useState<ItemDesign | null>(null);
    const [customLayout, setCustomLayout] = useState<CustomLayout | null>(null);
    
    // Canvas State
    const [canvasObjects, setCanvasObjects] = useState<CanvasObject[]>([]);
    const [currentTool, setCurrentTool] = useState<DrawingTool>('pencil');
    const [drawColor, setDrawColor] = useState('#00ffcc');
    
    // Interaction State
    const [isInteracting, setIsInteracting] = useState(false); // drawing or dragging
    const [dragStart, setDragStart] = useState<{x: number, y: number} | null>(null);
    const [selectedObjectId, setSelectedObjectId] = useState<string | null>(null);
    
    // Text Input State
    const [textInputVisible, setTextInputVisible] = useState(false);
    const [textInputPos, setTextInputPos] = useState({ x: 0, y: 0 });
    const [tempText, setTempText] = useState('');

    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    // --- Helpers ---
    const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const newFiles = Array.from(e.target.files);
            newFiles.forEach((file: File) => {
                const reader = new FileReader();
                reader.onloadend = () => {
                    const newMedia: UploadedMedia = {
                        id: Math.random().toString(36).substr(2, 9),
                        url: reader.result as string,
                        type: file.type.startsWith('video') ? 'video' : 'image',
                        file: file
                    };
                    setMediaFiles(prev => {
                        const updated = [...prev, newMedia];
                        if (!coverImageId) setCoverImageId(newMedia.id);
                        return updated;
                    });
                };
                reader.readAsDataURL(file);
            });
        }
    };

    const removeMedia = (id: string) => {
        setMediaFiles(prev => prev.filter(m => m.id !== id));
        if (coverImageId === id) setCoverImageId(null);
    };

    const handleAddSpec = (isNft: boolean) => {
        const newItem = { id: Date.now().toString(), key: '', value: '' };
        if (isNft) setNftProperties(prev => [...prev, newItem]);
        else setSpecs(prev => [...prev, newItem]);
    };

    const updateSpec = (isNft: boolean, id: string, field: 'key' | 'value', text: string) => {
        if (isNft) {
            setNftProperties(prev => prev.map(s => s.id === id ? { ...s, [field]: text } : s));
        } else {
            setSpecs(prev => prev.map(s => s.id === id ? { ...s, [field]: text } : s));
        }
    };

    const removeSpec = (isNft: boolean, id: string) => {
         if (isNft) setNftProperties(prev => prev.filter(s => s.id !== id));
         else setSpecs(prev => prev.filter(s => s.id !== id));
    };

    const handleMagicFill = async () => {
        if (!magicFillInput.trim()) return;
        setIsAiLoading(true);
        try {
            const prompt = `Act as an e-commerce expert. Parse this input: "${magicFillInput}". 
            Return JSON with keys: title, description (professional marketing copy), category, price (number), condition (New, Used), brand, weight (number), specs (array of {key, value}).`;
            const response = await generateText(prompt, false, false, false);
            const data = JSON.parse(response.text?.replace(/```json|```/g, '').trim() || '{}');
            
            if (data.title) setTitle(data.title);
            if (data.description) setDescription(data.description);
            if (data.price) setPrice(data.price.toString());
            if (data.category) setCategory(data.category);
            if (data.condition) setCondition(data.condition);
            if (data.brand) setBrand(data.brand);
            if (data.weight) setWeight(data.weight.toString());
            if (data.specs && Array.isArray(data.specs)) {
                setSpecs(data.specs.map((s: any, i: number) => ({ id: `ai-${i}`, key: s.key, value: s.value })));
            }
        } catch (e) {
            console.error("AI Fill failed", e);
        } finally {
            setIsAiLoading(false);
            setMagicFillInput('');
        }
    };

    // --- ADVANCED DESIGN STUDIO LOGIC ---

    // 1. Main Render Loop for Canvas
    useEffect(() => {
        if (step !== 'design') return;
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Clear Canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Draw All Objects
        canvasObjects.forEach(obj => {
            ctx.strokeStyle = obj.color;
            ctx.lineWidth = 3;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.fillStyle = obj.color;
            ctx.font = "bold 20px Inter, sans-serif";

            ctx.beginPath();
            if (obj.type === 'pencil' && obj.points) {
                if (obj.points.length > 0) {
                    ctx.moveTo(obj.points[0].x, obj.points[0].y);
                    obj.points.forEach(p => ctx.lineTo(p.x, p.y));
                }
                ctx.stroke();
            } else if (obj.type === 'rect' && obj.w && obj.h) {
                ctx.strokeRect(obj.x, obj.y, obj.w, obj.h);
            } else if (obj.type === 'circle' && obj.w) {
                ctx.arc(obj.x, obj.y, Math.abs(obj.w), 0, 2 * Math.PI);
                ctx.stroke();
            } else if (obj.type === 'star' && obj.w) {
                const radius = Math.abs(obj.w);
                const spikes = 5;
                const inset = radius / 2;
                ctx.moveTo(obj.x, obj.y - radius);
                for (let i = 0; i < spikes; i++) {
                    ctx.rotate(Math.PI / spikes);
                    ctx.lineTo(obj.x, obj.y - inset);
                    ctx.rotate(Math.PI / spikes);
                    ctx.lineTo(obj.x, obj.y - radius);
                }
                ctx.closePath();
                ctx.stroke();
            } else if (obj.type === 'line' && obj.w && obj.h) {
                ctx.moveTo(obj.x, obj.y);
                ctx.lineTo(obj.w, obj.h); // w/h reused as endX/endY for lines
                ctx.stroke();
            } else if (obj.type === 'arrow' && obj.w && obj.h) {
                // Draw Line
                ctx.moveTo(obj.x, obj.y);
                ctx.lineTo(obj.w, obj.h);
                ctx.stroke();
                // Draw Head
                const angle = Math.atan2(obj.h - obj.y, obj.w - obj.x);
                ctx.beginPath();
                ctx.moveTo(obj.w, obj.h);
                ctx.lineTo(obj.w - 15 * Math.cos(angle - Math.PI / 6), obj.h - 15 * Math.sin(angle - Math.PI / 6));
                ctx.lineTo(obj.w - 15 * Math.cos(angle + Math.PI / 6), obj.h - 15 * Math.sin(angle + Math.PI / 6));
                ctx.lineTo(obj.w, obj.h);
                ctx.fill();
            } else if (obj.type === 'text' && obj.text) {
                ctx.fillText(obj.text, obj.x, obj.y);
            }

            // Highlight selection
            if (selectedObjectId === obj.id) {
                ctx.strokeStyle = '#FFFF00';
                ctx.lineWidth = 1;
                ctx.setLineDash([5, 5]);
                // Simple bounding box estimation
                if (obj.type === 'text') {
                     const width = ctx.measureText(obj.text || '').width;
                     ctx.strokeRect(obj.x - 5, obj.y - 25, width + 10, 35);
                } else if (obj.type === 'rect' && obj.w && obj.h) {
                     ctx.strokeRect(obj.x - 5, obj.y - 5, obj.w + 10, obj.h + 10);
                }
                ctx.setLineDash([]);
            }
        });
    }, [canvasObjects, step, selectedObjectId]);

    // 2. Input Handlers
    const getPointerPos = (e: React.MouseEvent | React.TouchEvent) => {
        const canvas = canvasRef.current;
        if (!canvas) return { x: 0, y: 0 };
        const rect = canvas.getBoundingClientRect();
        let clientX = 0, clientY = 0;
        if ('touches' in e) {
            const touch = e.touches[0] || e.changedTouches[0];
            if (touch) {
                clientX = touch.clientX;
                clientY = touch.clientY;
            }
        } else {
            clientX = (e as React.MouseEvent).clientX;
            clientY = (e as React.MouseEvent).clientY;
        }
        return { x: clientX - rect.left, y: clientY - rect.top };
    };

    const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
        const pos = getPointerPos(e);
        
        // SELECT Mode: Try to find an object
        if (currentTool === 'select') {
            // Simple hit detection (very basic for demo)
            const hit = canvasObjects.find(obj => {
               return Math.abs(obj.x - pos.x) < 30 && Math.abs(obj.y - pos.y) < 30; // Generous hit area
            });
            if (hit) {
                setSelectedObjectId(hit.id);
                setIsInteracting(true);
                setDragStart(pos);
            } else {
                setSelectedObjectId(null);
            }
            return;
        }

        // TEXT Mode
        if (currentTool === 'text') {
            setTextInputPos(pos);
            setTextInputVisible(true);
            return;
        }

        // DRAWING Modes
        setIsInteracting(true);
        setDragStart(pos);
        setSelectedObjectId(null);

        // Create temp object
        const newId = Date.now().toString();
        const newObj: CanvasObject = {
            id: newId,
            type: currentTool,
            x: pos.x,
            y: pos.y,
            color: drawColor,
            w: 0, h: 0,
            points: currentTool === 'pencil' ? [pos] : []
        };
        setCanvasObjects(prev => [...prev, newObj]);
    };

    const handlePointerMove = (e: React.MouseEvent | React.TouchEvent) => {
        if (!isInteracting) return;
        const pos = getPointerPos(e);

        if (currentTool === 'select' && selectedObjectId && dragStart) {
            // Dragging existing object
            const dx = pos.x - dragStart.x;
            const dy = pos.y - dragStart.y;
            setCanvasObjects(prev => prev.map(obj => 
                obj.id === selectedObjectId ? { ...obj, x: obj.x + dx, y: obj.y + dy } : obj
            ));
            setDragStart(pos); // Reset drag anchor
            return;
        }

        // Drawing new object
        setCanvasObjects(prev => {
            const last = prev[prev.length - 1];
            if (!last || last.type !== currentTool) return prev;

            if (currentTool === 'pencil') {
                 return prev.map((obj, i) => i === prev.length - 1 ? { ...obj, points: [...(obj.points || []), pos] } : obj);
            } else if (currentTool === 'rect') {
                return prev.map((obj, i) => i === prev.length - 1 ? { ...obj, w: pos.x - obj.x, h: pos.y - obj.y } : obj);
            } else if (currentTool === 'circle' || currentTool === 'star') {
                const radius = Math.sqrt(Math.pow(pos.x - last.x, 2) + Math.pow(pos.y - last.y, 2));
                return prev.map((obj, i) => i === prev.length - 1 ? { ...obj, w: radius } : obj); // w used as radius
            } else if (currentTool === 'line' || currentTool === 'arrow') {
                return prev.map((obj, i) => i === prev.length - 1 ? { ...obj, w: pos.x, h: pos.y } : obj); // w/h used as end points
            }
            return prev;
        });
    };

    const handlePointerUp = () => {
        setIsInteracting(false);
        setDragStart(null);
    };

    const handleTextSubmit = () => {
        if (tempText.trim()) {
            const newObj: CanvasObject = {
                id: Date.now().toString(),
                type: 'text',
                x: textInputPos.x,
                y: textInputPos.y,
                color: '#ffffff',
                text: tempText
            };
            setCanvasObjects(prev => [...prev, newObj]);
        }
        setTextInputVisible(false);
        setTempText('');
        setCurrentTool('select'); // Auto switch to select after typing
    };

    const generateLayoutFromSketch = async () => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        
        setIsAiLoading(true);
        setCustomLayout(null);

        try {
            const imageData = canvas.toDataURL('image/png').split(',')[1];
            
            // Enhanced Prompt for BEAUTIFICATION & SHAPE RECOGNITION
            const prompt = `
                You are a UI UX Expert & Frontend Architect.
                Analyze this sketch. The user has drawn a desired layout for a product page.
                
                **TASK:**
                1. **Interpret Intent:** Even if the drawing is messy, straight lines, align boxes to a perfect grid, and fix proportions.
                2. **Recognize Shapes:** 
                   - If the user drew a STAR and wrote "Image" or "Img" inside, the image slot MUST be star-shaped.
                   - If they drew a CIRCLE, it must be circular.
                   - If they drew a BOX, it is a rectangle.
                3. **Identify Components:** Map text labels to components:
                   - "Image", "Photo" -> type: 'image-slot'
                   - "Buy", "Cart" -> type: 'buy-button'
                   - "Title", "Name" -> type: 'title'
                   - "Price", "$" -> type: 'price'
                   - "Desc", "Text" -> type: 'description'
                
                **OUTPUT JSON ONLY:**
                {
                   "background": "Suggest a professional background color (hex) based on the vibe (e.g. #111111)",
                   "elements": [
                      { 
                        "id": "el_1", 
                        "type": "image-slot", 
                        "x": 10, "y": 10, "w": 40, "h": 40, 
                        "shape": "star" // or 'rect', 'circle', 'rounded'
                      },
                      ...
                   ]
                }
                All coordinates (x,y,w,h) are percentages (0-100). 
                BEAUTIFY THE LAYOUT. Don't just copy the mess. Make it look like a pro app.
            `;
            
            const result = await analyzeContent(prompt, imageData, 'image/png');
            const cleanJson = result.replace(/```json|```/g, '').trim();
            const layoutData: CustomLayout = JSON.parse(cleanJson);
            
            setCustomLayout(layoutData);
            // We keep the user in design mode but show the AI result
            setStep('review'); 

        } catch (e) {
            console.error("Layout generation failed", e);
            alert("Could not generate layout from sketch.");
        } finally {
            setIsAiLoading(false);
        }
    };

    const clearCanvas = () => {
        setCanvasObjects([]);
        setCustomLayout(null);
    };

    const undo = () => {
        setCanvasObjects(prev => prev.slice(0, -1));
    };

    // --- Review & Submit ---
    const getPreviewItem = (): Omit<NFT, 'id'> | Omit<GearItem, 'id'> => {
        const coverUrl = mediaFiles.find(m => m.id === coverImageId)?.url || mediaFiles[0]?.url || '';
        
        const commonProps = {
            description: description || 'No description provided.',
            reviews: [],
            customDesign: customDesign || undefined,
            customLayout: customLayout || undefined
        };
        
        if (activeTab === 'nft') {
            return {
                name: title || 'Untitled NFT',
                collection: collection || 'FitSocial Collection',
                imageUrl: coverUrl,
                owner: { username: currentUser.username, avatar: currentUser.avatarImage || '' },
                price: parseFloat(price) || 0,
                currency: blockchain,
                bestOffer: 0,
                description: description || 'No description provided',
                reservePrice: listingType === 'auction' ? parseFloat(reservePrice) || undefined : undefined,
                auctionEndsIn: listingType === 'auction' ? auctionDuration : undefined,
                bids: [],
                priceHistory: [],
                ...commonProps
            } as Omit<NFT, 'id'>;
        } else {
            return {
                title: title || 'Untitled Product',
                price: parseFloat(price) || 0,
                currency,
                image: coverUrl,
                category: category as any,
                condition: condition as any,
                seller: currentUser,
                specs: specs,
                logistics: {
                    weight,
                    dimensions: `${dimensions.l}x${dimensions.w}x${dimensions.h}`,
                    carrier: shippingCarrier,
                    deliveryTime
                },
                ...commonProps
            } as Omit<GearItem, 'id'>;
        }
    };

    const handlePublish = async () => {
        let item = getPreviewItem();
        
        const coverMedia = mediaFiles.find(m => m.id === coverImageId);
        
        if (coverMedia) {
            // FIX: Convert blob URL to a permanent data URL before publishing
            const dataUrl = await fileToDataUrl(coverMedia.file);
            if (activeTab === 'nft') {
                (item as Omit<NFT, 'id'>).imageUrl = dataUrl;
            } else {
                (item as Omit<GearItem, 'id'>).image = dataUrl;
            }
        }
    
        const itemWithDesign = { ...item, customDesign, customLayout };
    
        if (activeTab === 'nft') {
            handleCreateNFT({ ...itemWithDesign as NFT, id: Date.now().toString() });
        } else {
            handleCreateGear({ ...itemWithDesign as GearItem, id: Date.now().toString() });
        }
        closeModal();
    };

    // --- Calculations ---
    const numPrice = parseFloat(price) || 0;
    const numCost = parseFloat(costPerItem) || 0;
    const fees = numPrice * 0.05;
    const profit = numPrice - fees - numCost;
    const margin = numPrice > 0 ? (profit / numPrice) * 100 : 0;

    const renderGearForm = () => (
        <div className="space-y-8">
            <FormSection title="Product Identity" icon="🏷️">
                 <ProInput label="Product Title" value={title} onChange={(e:any) => setTitle(e.target.value)} placeholder="e.g. Adjustable Dumbbell Set" />
                 <div className="grid grid-cols-2 gap-4">
                    <InputGroup label="Category">
                         <select value={category} onChange={e => setCategory(e.target.value)} className="w-full bg-[#0A0A0A] border border-gray-800 rounded-xl px-3 py-3 text-white text-sm focus:border-emerald-500 outline-none appearance-none">
                            <option>Supplement</option><option>Equipment</option><option>Clothing</option><option>Tech</option><option>Accessories</option>
                        </select>
                    </InputGroup>
                     <InputGroup label="Condition">
                         <select value={condition} onChange={e => setCondition(e.target.value)} className="w-full bg-[#0A0A0A] border border-gray-800 rounded-xl px-3 py-3 text-white text-sm focus:border-emerald-500 outline-none appearance-none">
                            <option>New</option><option>Used - Like New</option><option>Used - Good</option><option>Used - Fair</option>
                        </select>
                    </InputGroup>
                </div>
                <ProInput label="Brand / Manufacturer" value={brand} onChange={(e:any) => setBrand(e.target.value)} placeholder="e.g. Nike, Optimum Nutrition" />
                <InputGroup label="Description">
                    <textarea value={description} onChange={e => setDescription(e.target.value)} rows={5} className="w-full bg-[#0A0A0A] border border-gray-800 rounded-xl px-4 py-3 text-white text-sm focus:border-emerald-500 focus:ring-0 resize-none placeholder-gray-700" placeholder="Describe key features, benefits, and condition..." />
                </InputGroup>
            </FormSection>

            <FormSection title="Logistics & Inventory" icon="📦">
                <div className="grid grid-cols-2 gap-4">
                    <ProInput label="Stock Quantity" value={stock} onChange={(e:any) => setStock(e.target.value)} type="number" />
                    <ProInput label="SKU (Stock Keeping Unit)" value={sku} onChange={(e:any) => setSku(e.target.value)} placeholder="PROD-001" />
                </div>
                <ProInput label="Barcode (GTIN/UPC/EAN)" value={barcode} onChange={(e:any) => setBarcode(e.target.value)} placeholder="000000000000" />
                
                <div className="bg-[#0A0A0A] p-4 rounded-xl border border-white/5 mt-2">
                     <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-3 block">Shipping Details</label>
                     <div className="grid grid-cols-4 gap-3 mb-3">
                         <ProInput label="Weight (kg)" value={weight} onChange={(e:any) => setWeight(e.target.value)} placeholder="0.5" />
                         <ProInput label="Length" value={dimensions.l} onChange={(e:any) => setDimensions({...dimensions, l: e.target.value})} placeholder="cm" />
                         <ProInput label="Width" value={dimensions.w} onChange={(e:any) => setDimensions({...dimensions, w: e.target.value})} placeholder="cm" />
                         <ProInput label="Height" value={dimensions.h} onChange={(e:any) => setDimensions({...dimensions, h: e.target.value})} placeholder="cm" />
                     </div>
                     <div className="grid grid-cols-2 gap-4">
                          <InputGroup label="Shipping Carrier">
                            <select value={shippingCarrier} onChange={e => setShippingCarrier(e.target.value)} className="w-full bg-[#0A0A0A] border border-gray-800 rounded-xl px-3 py-3 text-white text-sm focus:border-emerald-500 outline-none">
                                <option>Standard (Post)</option><option>DHL Express</option><option>FedEx</option><option>UPS</option><option>Local Delivery</option>
                            </select>
                        </InputGroup>
                        <ProInput label="Est. Delivery Time" value={deliveryTime} onChange={(e:any) => setDeliveryTime(e.target.value)} placeholder="3-5 Days" />
                     </div>
                </div>
            </FormSection>

             <FormSection title="Pricing & Financials" icon="💰">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
                
                <div className="grid grid-cols-2 gap-6 mb-6">
                    <InputGroup label="Currency">
                        <div className="flex p-1 bg-[#0A0A0A] rounded-lg border border-gray-800">
                            <button onClick={() => setCurrency('$')} className={`flex-1 py-2 rounded text-xs font-bold transition-all ${currency === '$' ? 'bg-emerald-600 text-white' : 'text-gray-500'}`}>USD ($)</button>
                            <button onClick={() => setCurrency('FIT')} className={`flex-1 py-2 rounded text-xs font-bold transition-all ${currency === 'FIT' ? 'bg-orange-500 text-white' : 'text-gray-500'}`}>$FIT</button>
                        </div>
                    </InputGroup>
                    <ProInput label="Sale Price" value={price} onChange={(e:any) => setPrice(e.target.value)} placeholder="0.00" prefix={currency} />
                </div>

                <ProInput label="Cost per Item (For Profit Calc)" value={costPerItem} onChange={(e:any) => setCostPerItem(e.target.value)} placeholder="0.00" prefix={currency} />

                {/* Live Profit Calculator */}
                <div className="mt-6 bg-[#0A0A0A] p-4 rounded-xl border border-emerald-500/20 relative overflow-hidden">
                    <div className="flex justify-between items-end mb-2 relative z-10">
                        <span className="text-xs text-gray-400 font-bold uppercase">Estimated Profit</span>
                        <span className={`text-2xl font-black ${profit > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                             {currency}{profit.toFixed(2)} <span className="text-xs font-normal text-gray-500">({margin.toFixed(1)}% margin)</span>
                        </span>
                    </div>
                    <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden flex relative z-10">
                        <div className="bg-blue-500 h-full" style={{ width: `${Math.min(100, (numCost / numPrice) * 100)}%` }} title="Cost"></div>
                        <div className="bg-yellow-500 h-full" style={{ width: '5%' }} title="Fees"></div>
                        <div className="bg-emerald-500 h-full" style={{ width: `${Math.max(0, (profit / numPrice) * 100)}%` }} title="Profit"></div>
                    </div>
                    <div className="flex justify-between text-[9px] text-gray-500 mt-1 font-mono uppercase relative z-10">
                        <span className="flex items-center gap-1"><div className="w-2 h-2 bg-blue-500 rounded-full"></div> Cost</span>
                        <span className="flex items-center gap-1"><div className="w-2 h-2 bg-yellow-500 rounded-full"></div> Fees (5%)</span>
                        <span className="flex items-center gap-1"><div className="w-2 h-2 bg-emerald-500 rounded-full"></div> Net Profit</span>
                    </div>
                </div>
            </FormSection>

            <FormSection title="Technical Specifications" icon="🛠️">
                 <div className="space-y-2">
                    {specs.map(s => (
                        <div key={s.id} className="flex gap-2">
                            <input value={s.key} onChange={e => updateSpec(false, s.id, 'key', e.target.value)} className="w-1/3 bg-[#0A0A0A] border border-gray-800 rounded-lg p-3 text-xs text-white focus:border-emerald-500 outline-none" placeholder="Feature (e.g. Flavor)" />
                            <input value={s.value} onChange={e => updateSpec(false, s.id, 'value', e.target.value)} className="flex-1 bg-[#0A0A0A] border border-gray-800 rounded-lg p-3 text-xs text-white focus:border-emerald-500 outline-none" placeholder="Value (e.g. Chocolate)" />
                            <button onClick={() => removeSpec(false, s.id)} className="text-red-500 hover:text-red-400 px-2 font-bold">&times;</button>
                        </div>
                    ))}
                    <button onClick={() => handleAddSpec(false)} className="w-full py-3 border border-dashed border-gray-700 rounded-xl text-gray-500 text-xs font-bold hover:text-emerald-400 hover:border-emerald-500 transition-all mt-2 bg-[#0A0A0A] hover:bg-[#111]">
                        + Add Specification
                    </button>
                </div>
            </FormSection>
        </div>
    );

    const renderNftForm = () => (
        <div className="space-y-8">
            <FormSection title="Asset Details" icon="💎">
                 <div className="space-y-5">
                     <ProInput label="NFT Name" value={title} onChange={(e:any) => setTitle(e.target.value)} placeholder="e.g. Cyber Punk #2077" />
                     <ProInput label="Collection Name" value={collection} onChange={(e:any) => setCollection(e.target.value)} placeholder="Create or Select Collection" />
                     <InputGroup label="Blockchain Network">
                        <div className="grid grid-cols-3 gap-3">
                             {['ETH', 'SOL', 'POLY'].map(chain => (
                                 <button key={chain} onClick={() => setBlockchain(chain)} className={`py-3 rounded-xl border font-bold text-xs transition-all ${blockchain === chain ? 'bg-purple-900/20 border-purple-500 text-purple-400' : 'bg-[#0A0A0A] border-gray-800 text-gray-500'}`}>
                                     {chain}
                                 </button>
                             ))}
                        </div>
                    </InputGroup>
                     <InputGroup label="Description">
                        <textarea value={description} onChange={e => setDescription(e.target.value)} rows={5} className="w-full bg-[#0A0A0A] border border-gray-800 rounded-xl px-4 py-3 text-white text-sm focus:border-purple-500 focus:ring-0 resize-none placeholder-gray-700" placeholder="Describe the artwork, utility, or story..." />
                    </InputGroup>
                 </div>
            </FormSection>

            <FormSection title="Sale Configuration" icon="🏷️">
                 <div className="space-y-6">
                     <InputGroup label="Listing Type">
                        <div className="flex gap-4">
                            <button onClick={() => setListingType('fixed')} className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border transition-all ${listingType === 'fixed' ? 'bg-purple-500/10 border-purple-500 text-purple-400' : 'bg-[#0A0A0A] border-gray-800 text-gray-500'}`}>
                                <span>⚡</span> <span className="text-xs font-bold">Fixed Price</span>
                            </button>
                            <button onClick={() => setListingType('auction')} className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border transition-all ${listingType === 'auction' ? 'bg-purple-500/10 border-purple-500 text-purple-400' : 'bg-[#0A0A0A] border-gray-800 text-gray-500'}`}>
                                <span>⏳</span> <span className="text-xs font-bold">Timed Auction</span>
                            </button>
                        </div>
                    </InputGroup>

                    <div className="grid grid-cols-2 gap-6">
                        <ProInput label={listingType === 'fixed' ? "Price" : "Starting Bid"} value={price} onChange={(e:any) => setPrice(e.target.value)} placeholder="0.00" prefix={blockchain} />
                        
                        {listingType === 'auction' && (
                            <ProInput label="Reserve Price" value={reservePrice} onChange={(e: any) => setReservePrice(e.target.value)} placeholder="0.00" prefix={blockchain} />
                        )}

                        {listingType === 'auction' && (
                            <InputGroup label="Duration">
                                <select value={auctionDuration} onChange={e => setAuctionDuration(e.target.value)} className="w-full bg-[#0A0A0A] border border-gray-800 rounded-xl px-3 py-3 text-white text-sm focus:border-purple-500 outline-none appearance-none">
                                    <option>1 Day</option><option>3 Days</option><option>7 Days</option><option>30 Days</option>
                                </select>
                            </InputGroup>
                        )}
                        <ProInput label="Creator Royalties" value={royalties} onChange={(e:any) => setRoyalties(e.target.value)} placeholder="5" suffix="%" />
                    </div>
                 </div>
            </FormSection>

            <FormSection title="Traits & Properties" icon="🧬">
                 <div className="space-y-2">
                    {nftProperties.map(s => (
                        <div key={s.id} className="flex gap-2">
                            <input value={s.key} onChange={e => updateSpec(true, s.id, 'key', e.target.value)} className="w-1/3 bg-[#0A0A0A] border border-gray-800 rounded-lg p-3 text-xs text-white focus:border-purple-500 outline-none" placeholder="Trait Type (e.g. Background)" />
                            <input value={s.value} onChange={e => updateSpec(true, s.id, 'value', e.target.value)} className="flex-1 bg-[#0A0A0A] border border-gray-800 rounded-lg p-3 text-xs text-white focus:border-purple-500 outline-none" placeholder="Value (e.g. Gold)" />
                            <button onClick={() => removeSpec(true, s.id)} className="text-red-500 hover:text-red-400 px-2 font-bold">&times;</button>
                        </div>
                    ))}
                    <button onClick={() => handleAddSpec(true)} className="w-full py-3 border border-dashed border-gray-700 rounded-xl text-gray-500 text-xs font-bold hover:text-purple-400 hover:border-purple-500 transition-all mt-2 bg-[#0A0A0A] hover:bg-[#111]">
                        + Add Property
                    </button>
                </div>
            </FormSection>
        </div>
    );
    
    // --- Design Studio Render ---
    if (step === 'design') {
        return (
            <div className="fixed inset-0 bg-[#050505] z-[300] flex flex-col animate-fadeIn">
                {/* Studio Header */}
                <div className="flex justify-between items-center p-4 border-b border-white/10 bg-[#0e0e10] z-20">
                     <div className="flex items-center gap-3">
                        <button onClick={() => setStep('edit')} className="text-gray-400 hover:text-white p-2 rounded-full hover:bg-white/5 transition-colors">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                        </button>
                        <div>
                            <h3 className="text-white font-bold text-lg tracking-tight flex items-center gap-2">
                                <span className="text-xl">🎨</span> AI Design Studio
                            </h3>
                            <p className="text-[10px] text-gray-500 uppercase tracking-wider">Prototype & Drag 'n Drop</p>
                        </div>
                    </div>
                    <div className="flex gap-2 items-center">
                        <div className="flex bg-gray-800 rounded-lg p-1 mr-4">
                            <button onClick={() => { setCurrentTool('select'); }} className={`p-2 rounded-md transition-all ${currentTool === 'select' ? 'bg-blue-600 text-white' : 'text-gray-400'}`} title="Select/Move">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/><path d="M13 13l6 6"/></svg>
                            </button>
                            <button onClick={() => setCurrentTool('pencil')} className={`p-2 rounded-md transition-all ${currentTool === 'pencil' ? 'bg-blue-600 text-white' : 'text-gray-400'}`} title="Freehand"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 3a2.828 2.828 0 114 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg></button>
                            <button onClick={() => setCurrentTool('line')} className={`p-2 rounded-md transition-all ${currentTool === 'line' ? 'bg-blue-600 text-white' : 'text-gray-400'}`} title="Line"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="22" y1="2" x2="2" y2="22"/></svg></button>
                            <button onClick={() => setCurrentTool('rect')} className={`p-2 rounded-md transition-all ${currentTool === 'rect' ? 'bg-blue-600 text-white' : 'text-gray-400'}`} title="Rectangle"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/></svg></button>
                            <button onClick={() => setCurrentTool('circle')} className={`p-2 rounded-md transition-all ${currentTool === 'circle' ? 'bg-blue-600 text-white' : 'text-gray-400'}`} title="Circle"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/></svg></button>
                            <button onClick={() => setCurrentTool('star')} className={`p-2 rounded-md transition-all ${currentTool === 'star' ? 'bg-blue-600 text-white' : 'text-gray-400'}`} title="Star"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></button>
                            <button onClick={() => setCurrentTool('arrow')} className={`p-2 rounded-md transition-all ${currentTool === 'arrow' ? 'bg-blue-600 text-white' : 'text-gray-400'}`} title="Arrow"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></button>
                            <button onClick={() => setCurrentTool('text')} className={`p-2 rounded-md transition-all ${currentTool === 'text' ? 'bg-blue-600 text-white' : 'text-gray-400'}`} title="Text"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg></button>
                            
                            <button onClick={clearCanvas} className="p-2 text-red-400 hover:text-red-300 ml-2 border-l border-white/10" title="Clear"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>
                            <button onClick={undo} className="p-2 text-gray-400 hover:text-white" title="Undo"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/></svg></button>
                        </div>

                        <button onClick={generateLayoutFromSketch} disabled={isAiLoading} className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 hover:shadow-lg hover:shadow-purple-500/30 transition-all disabled:opacity-50">
                            {isAiLoading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : "✨ AI Build Layout"}
                        </button>
                    </div>
                </div>

                {/* Studio Canvas Area */}
                <div className="flex-1 relative overflow-hidden flex items-center justify-center bg-[#111] cursor-crosshair" ref={containerRef}>
                    
                    {/* Rendered Objects Layer */}
                    <canvas
                        ref={canvasRef}
                        width={window.innerWidth}
                        height={window.innerHeight}
                        className="absolute inset-0 z-10 touch-none"
                        onMouseDown={handlePointerDown}
                        onMouseMove={handlePointerMove}
                        onMouseUp={handlePointerUp}
                        onMouseLeave={handlePointerUp}
                        onTouchStart={handlePointerDown}
                        onTouchMove={handlePointerMove}
                        onTouchEnd={handlePointerUp}
                    />

                    {/* Text Input Overlay */}
                    {textInputVisible && (
                         <input
                            type="text"
                            value={tempText}
                            onChange={e => setTempText(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && handleTextSubmit()}
                            onBlur={handleTextSubmit}
                            autoFocus
                            placeholder="Type text..."
                            style={{
                                position: 'absolute',
                                left: textInputPos.x,
                                top: textInputPos.y - 15,
                                zIndex: 50,
                            }}
                            className="bg-black/80 text-white border border-blue-500 p-2 rounded-lg outline-none min-w-[100px]"
                         />
                    )}

                    <div className="absolute bottom-4 left-4 bg-black/50 p-2 rounded-lg text-xs text-gray-400 pointer-events-none z-0">
                         {isInteracting ? (currentTool === 'select' ? 'Dragging...' : 'Drawing...') : 'Ready'} | Objects: {canvasObjects.length}
                    </div>
                </div>
            </div>
        );
    }

    // --- Review Mode Render ---
    if (step === 'review') {
        return (
            <div className="fixed inset-0 bg-black z-[250] flex flex-col animate-fadeIn">
                {/* Review Top Bar (Absolute Positioned Overlay) */}
                <div className="absolute top-0 left-0 right-0 p-6 z-[500] flex justify-between items-center pointer-events-auto bg-gradient-to-b from-black/80 to-transparent">
                    <button onClick={() => setStep('edit')} className="text-white flex items-center gap-2 font-bold bg-black/40 backdrop-blur-md px-5 py-2.5 rounded-full hover:bg-white/10 transition-all shadow-lg border border-white/10 group">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="group-hover:-translate-x-1 transition-transform"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                        Back
                    </button>
                    
                    <div className="flex gap-3">
                         <button onClick={() => setStep('design')} className="bg-purple-600/80 backdrop-blur-md text-white border border-purple-400/30 px-5 py-2.5 rounded-full font-bold text-sm hover:bg-purple-500 shadow-lg transition-all flex items-center gap-2 transform hover:scale-105">
                            <span>🎨</span> Edit Design
                        </button>
                    </div>
                </div>
                
                {/* Main Content (Preview) */}
                <div className="flex-1 relative overflow-hidden bg-black">
                    <ProductDetailModal 
                        isPreview={true}
                        closeModal={() => setStep('edit')} 
                        item={{ ...getPreviewItem() as NFT, customLayout }} 
                        openModal={() => {}} 
                    />
                </div>

                {/* Review Bottom Bar (Absolute Positioned Overlay) */}
                <div className="absolute bottom-0 left-0 right-0 p-6 flex justify-center z-[500] pointer-events-auto bg-gradient-to-t from-black/90 via-black/50 to-transparent pb-10">
                    <button onClick={handlePublish} className="w-full max-w-md bg-emerald-500 text-white px-6 py-4 rounded-2xl font-black text-lg shadow-[0_0_30px_rgba(16,185,129,0.4)] hover:bg-emerald-400 transition-transform hover:scale-[1.02] flex items-center justify-center gap-2 border border-emerald-400/50">
                        <span>🚀</span> PUBLISH LISTING
                    </button>
                </div>
            </div>
        );
    }

    // --- Edit Mode Render (Seller Central) ---
    return (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-sm z-[200] flex items-center justify-center p-4 overflow-hidden">
            <div className="w-full max-w-7xl h-[90vh] bg-[#050505] rounded-[2rem] shadow-2xl flex flex-col overflow-hidden border border-white/10 relative animate-scaleIn">
                
                {/* Header */}
                <div className="relative shrink-0">
                    <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-emerald-500 to-transparent opacity-50"></div>
                    <div className="bg-[#0e0e10] p-4 flex justify-between items-center z-10 relative">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-900 to-black border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.2)]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                            </div>
                            <div>
                                <h2 className="text-xl font-black text-white tracking-tight">SELLER <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">CENTRAL</span></h2>
                                <p className="text-[10px] text-gray-500 font-medium tracking-widest uppercase">Create Listing</p>
                            </div>
                        </div>
                        
                        <div className="flex bg-black/50 p-1 rounded-xl border border-white/10">
                            <button onClick={() => setActiveTab('gear')} className={`px-6 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${activeTab === 'gear' ? 'bg-[#202020] text-white shadow-lg border border-white/10' : 'text-gray-500 hover:text-gray-300'}`}>📦 Physical</button>
                            <button onClick={() => setActiveTab('nft')} className={`px-6 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${activeTab === 'nft' ? 'bg-gradient-to-r from-purple-900 to-indigo-900 text-white shadow-lg border border-white/10' : 'text-gray-500 hover:text-gray-300'}`}>💎 Digital Asset</button>
                        </div>

                        <button onClick={closeModal} className="w-8 h-8 flex items-center justify-center rounded-full bg-white/5 hover:bg-red-500/20 hover:text-red-500 text-gray-400 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                        </button>
                    </div>
                </div>

                {/* Content */}
                <div className="flex flex-1 overflow-hidden">
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
                        <div className="max-w-6xl mx-auto space-y-8">
                            
                            {/* AI Bar */}
                            <div className="relative group mb-8">
                                <div className="absolute -inset-0.5 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-xl opacity-20 group-hover:opacity-40 transition duration-500 blur"></div>
                                <div className="relative flex items-center bg-[#050505] rounded-xl border border-white/10 overflow-hidden">
                                    <div className="pl-4 text-emerald-400 animate-pulse">
                                        <svg className={`w-5 h-5 ${isAiLoading ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                                    </div>
                                    <input 
                                        type="text" 
                                        value={magicFillInput}
                                        onChange={e => setMagicFillInput(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && handleMagicFill()}
                                        placeholder={activeTab === 'gear' ? "AI Magic: 'Selling used 20kg dumbbells for $50'..." : "AI Magic: 'Cyberpunk style NFT character, rare, 5 ETH'..."}
                                        className="w-full bg-transparent border-none text-sm text-white placeholder-gray-600 focus:ring-0 py-3.5 px-3"
                                    />
                                    <button onClick={handleMagicFill} className="mr-2 bg-[#1a1a1a] hover:bg-emerald-600 hover:text-black text-white text-[10px] font-bold px-4 py-2 rounded-lg transition-all border border-white/10">AUTO-FILL</button>
                                </div>
                            </div>

                            <div className="grid grid-cols-12 gap-8">
                                {/* Left Column: Details */}
                                <div className="col-span-7 space-y-6">
                                    
                                    {/* Media Section */}
                                    <FormSection title="Gallery" icon="📸">
                                        <div className="grid grid-cols-4 gap-4">
                                            {mediaFiles.map((media) => (
                                                <div key={media.id} className="relative aspect-square rounded-xl overflow-hidden border border-white/10 group">
                                                    {media.type === 'video' ? <video src={media.url} className="w-full h-full object-cover" /> : <img src={media.url} className="w-full h-full object-cover" />}
                                                    <button onClick={() => removeMedia(media.id)} className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"><svg width="12" height="12" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                                                </div>
                                            ))}
                                            <div onClick={() => fileInputRef.current?.click()} className="aspect-square rounded-xl border-2 border-dashed border-[#333] hover:border-emerald-500 cursor-pointer flex items-center justify-center text-gray-500 hover:text-emerald-400 transition-all bg-[#0a0a0a]">
                                                <span className="text-2xl">+</span>
                                            </div>
                                        </div>
                                        <input type="file" ref={fileInputRef} onChange={handleMediaUpload} multiple accept="image/*,video/*" className="hidden" />
                                    </FormSection>

                                    {activeTab === 'gear' ? renderGearForm() : renderNftForm()}
                                </div>

                                {/* Right Column: Sidebar / Summary */}
                                <div className="col-span-5">
                                    <div className="sticky top-4 bg-[#121212] rounded-3xl p-6 border border-white/5 shadow-2xl">
                                         <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Listing Summary</h3>
                                         
                                         <div className="space-y-4 text-sm">
                                             <div className="flex justify-between pb-2 border-b border-white/5">
                                                 <span className="text-gray-500">Title</span>
                                                 <span className="text-white font-medium text-right truncate max-w-[200px]">{title || 'Untitled'}</span>
                                             </div>
                                             <div className="flex justify-between pb-2 border-b border-white/5">
                                                 <span className="text-gray-500">Price</span>
                                                 <span className="text-white font-medium">{price || '0.00'} {currency}</span>
                                             </div>
                                             {activeTab === 'gear' && (
                                                 <div className="flex justify-between pb-2 border-b border-white/5">
                                                     <span className="text-gray-500">Shipping</span>
                                                     <span className="text-white font-medium">{shippingCarrier}</span>
                                                 </div>
                                             )}
                                             <div className="flex justify-between pb-2 border-b border-white/5">
                                                 <span className="text-gray-500">Media Count</span>
                                                 <span className="text-white font-medium">{mediaFiles.length}</span>
                                             </div>
                                         </div>

                                         <div className="mt-6 pt-4 border-t border-white/10 space-y-3">
                                             <button onClick={() => setStep('design')} className="w-full bg-[#1a1a1a] text-white py-4 rounded-xl text-sm font-bold uppercase tracking-wider border border-white/10 hover:bg-[#222] transition-all flex items-center justify-center gap-2">
                                                <span>🎨</span> Open Design Studio
                                             </button>
                                             <button onClick={() => setStep('review')} className="w-full bg-white text-black font-black py-4 rounded-xl text-sm uppercase tracking-wider shadow-lg hover:bg-gray-200 transition-all">
                                                 Preview & Publish
                                             </button>
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <style>{`
                .custom-scrollbar::-webkit-scrollbar { width: 6px; }
                .custom-scrollbar::-webkit-scrollbar-track { background: #050505; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #333; border-radius: 20px; }
                @keyframes scaleIn { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
                .animate-scaleIn { animation: scaleIn 0.3s ease-out; }
            `}</style>
        </div>
    );
};

export default CreateListingModal;