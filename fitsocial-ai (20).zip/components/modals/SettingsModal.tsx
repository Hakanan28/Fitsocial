import React, { useState, useEffect } from 'react';
import { ModalType, CustomTheme, UserProfile } from '../../types';
import { useTranslation, supportedLanguages } from '../../hooks/i18n';

interface SettingsModalProps {
    closeModal: () => void;
    theme: 'light' | 'dark';
    setTheme: (theme: 'light' | 'dark') => void;
    showNotification: (message: string, type?: 'success' | 'error') => void;
    fitTokenBalance: number;
    handleLogout: () => void;
    openModal: (modal: ModalType, data?: any) => void;
    customTheme: CustomTheme | null;
    setCustomTheme: (theme: CustomTheme | null) => void;
    currentUser: UserProfile;
    onUpdateProfile: (updatedUser: UserProfile) => void;
}

const SettingsToggle: React.FC<{ isEnabled: boolean; onToggle: () => void; }> = ({ isEnabled, onToggle }) => (
    <button onClick={onToggle} className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${isEnabled ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`}>
        <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${isEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
    </button>
);

const SettingsRow: React.FC<{ icon?: React.ReactNode; label: string; onClick?: () => void; children?: React.ReactNode; hasChevron?: boolean; }> = ({ icon, label, onClick, children, hasChevron = false }) => (
    <div 
        onClick={onClick} 
        className={`flex items-center ${onClick ? 'cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700' : ''} p-3 rounded-lg transition-colors`}
    >
        {icon && <div className="text-gray-500 dark:text-gray-400 mr-4">{icon}</div>}
        <div className="flex-1 text-gray-800 dark:text-gray-200 font-medium">{label}</div>
        {children}
        {hasChevron && <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400"><path d="m9 18 6-6-6-6"/></svg>}
    </div>
);

const SettingsSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <section className="border-b border-gray-200 dark:border-gray-700 pb-4">
        <h4 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider px-3 mb-2">{title}</h4>
        {children}
    </section>
);


const SettingsModal: React.FC<SettingsModalProps> = ({ closeModal, theme, setTheme, showNotification, handleLogout, openModal, currentUser, onUpdateProfile }) => {
    const { t, language, setLanguage } = useTranslation();
    const [view, setView] = useState<'main' | 'blocked'>('main');

    // State for all settings
    const [notifications, setNotifications] = useState({ likes: true, comments: true, followers: true });
    const [isPrivate, setIsPrivate] = useState(false);
    const [fontSize, setFontSize] = useState(1);
    const [isHighContrast, setIsHighContrast] = useState(false);

    const handleNotificationToggle = (key: keyof typeof notifications) => {
        setNotifications(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const handleUnblock = (userToUnblock: string) => {
        const updatedBlockedUsers = currentUser.blockedUsers?.filter(user => user !== userToUnblock) || [];
        onUpdateProfile({ ...currentUser, blockedUsers: updatedBlockedUsers });
        showNotification(`${userToUnblock} has been unblocked.`);
    };
    
    const handleClearCache = () => {
        // FIX: Cast result of t() to string for showNotification
        showNotification(t('notifications_toast.clearingCache') as string, "success");
        setTimeout(() => {
            showNotification(t('notifications_toast.cacheCleared') as string, "success");
        }, 1500);
    };

    const handleExportData = () => {
        // FIX: Cast result of t() to string for showNotification
        showNotification(t('notifications_toast.preparingExport') as string, "success");
        setTimeout(() => {
            showNotification(t('notifications_toast.exportReady') as string, "success");
        }, 2000);
    };
    
    const handlePresenceToggle = () => {
        onUpdateProfile({ ...currentUser, presenceHidden: !currentUser.presenceHidden });
    };

    useEffect(() => {
        document.documentElement.style.setProperty('--font-size-multiplier', String(fontSize));
    }, [fontSize]);

    useEffect(() => {
        const root = document.documentElement;
        if (isHighContrast) {
            root.classList.add('high-contrast');
        } else {
            root.classList.remove('high-contrast');
        }
        return () => root.classList.remove('high-contrast');
    }, [isHighContrast]);

    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) closeModal();
    };

    const renderMainView = () => (
        <>
            {/* FIX: Cast result of t() to string for title prop */}
            <SettingsSection title={t('settings.account.title') as string}>
                <SettingsRow 
                    label={t('settings.account.editProfile') as string} 
                    onClick={() => {
                        closeModal();
                        openModal(ModalType.EditProfile);
                    }}
                    hasChevron 
                    icon={<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>} 
                />
                <SettingsRow label={t('settings.account.changePassword') as string} hasChevron icon={<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>} />
            </SettingsSection>

            <SettingsSection title={t('settings.security.title') as string}>
                <SettingsRow label={t('settings.security.blocked') as string} onClick={() => setView('blocked')} hasChevron icon={<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg>} />
                <SettingsRow label={t('settings.security.private') as string}>
                    <SettingsToggle isEnabled={isPrivate} onToggle={() => setIsPrivate(p => !p)} />
                </SettingsRow>
                <SettingsRow label={t('settings.security.showActivity') as string}>
                    <SettingsToggle isEnabled={!currentUser.presenceHidden} onToggle={handlePresenceToggle} />
                </SettingsRow>
            </SettingsSection>
            
            <SettingsSection title={t('settings.notifications.title') as string}>
                <SettingsRow label={t('settings.notifications.likes') as string}><SettingsToggle isEnabled={notifications.likes} onToggle={() => handleNotificationToggle('likes')} /></SettingsRow>
                <SettingsRow label={t('settings.notifications.comments') as string}><SettingsToggle isEnabled={notifications.comments} onToggle={() => handleNotificationToggle('comments')} /></SettingsRow>
                <SettingsRow label={t('settings.notifications.followers') as string}><SettingsToggle isEnabled={notifications.followers} onToggle={() => handleNotificationToggle('followers')} /></SettingsRow>
            </SettingsSection>
            
            <SettingsSection title={t('settings.accessibility.title') as string}>
                <SettingsRow label={t('settings.accessibility.darkMode') as string}>
                    <SettingsToggle isEnabled={theme === 'dark'} onToggle={() => setTheme(theme === 'light' ? 'dark' : 'light')} />
                </SettingsRow>
                <SettingsRow label="Customize Appearance" hasChevron onClick={() => openModal(ModalType.ThemeCustomization)} icon={<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>} />
                <SettingsRow label={t('settings.accessibility.highContrast') as string}>
                    <SettingsToggle isEnabled={isHighContrast} onToggle={() => setIsHighContrast(p => !p)} />
                </SettingsRow>
                <SettingsRow label={t('settings.accessibility.fontSize') as string} >
                    <input type="range" min="0.8" max="1.3" step="0.1" value={fontSize} onChange={e => setFontSize(Number(e.target.value))} className="w-24 accent-green-500"/>
                </SettingsRow>
            </SettingsSection>

            <SettingsSection title={t('settings.language.title') as string}>
                 <div className="p-3">
                    <select value={language} onChange={e => setLanguage(e.target.value)} className="w-full p-2 bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white rounded-xl border border-gray-300 dark:border-gray-700 focus:border-green-500 text-sm">
                        {Object.entries(supportedLanguages).map(([code, { name }]) => (
                            <option key={code} value={code}>{name}</option>
                        ))}
                    </select>
                </div>
            </SettingsSection>
            
            <SettingsSection title={t('settings.data.title') as string}>
                <SettingsRow label={t('settings.data.clearCache') as string} onClick={handleClearCache} icon={<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M21 21v-5h-5"/></svg>} />
                <SettingsRow label={t('settings.data.exportData') as string} onClick={handleExportData} icon={<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>} />
            </SettingsSection>

            <SettingsSection title={t('settings.about.title') as string}>
                <SettingsRow label={t('settings.about.help') as string} hasChevron icon={<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>} />
                <SettingsRow label={t('settings.about.terms') as string} hasChevron icon={<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/></svg>} />
            </SettingsSection>
            
            <div className="p-4">
                 <button onClick={handleLogout} className="w-full text-red-500 font-bold text-sm text-center hover:bg-red-500/10 py-3 rounded-xl transition-colors">{t('settings.logout')}</button>
            </div>
        </>
    );

    const renderBlockedView = () => (
        <>
            {(currentUser.blockedUsers && currentUser.blockedUsers.length > 0) ? (
                 <div className="space-y-2">
                    {currentUser.blockedUsers.map(user => (
                        <div key={user} className="flex items-center p-3">
                            <span className="font-semibold text-gray-800 dark:text-gray-200 flex-1">{user}</span>
                            <button onClick={() => handleUnblock(user)} className="text-sm font-bold text-red-500 hover:text-red-400">{t('common.unblock')}</button>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-center text-gray-500 p-8">{t('settings.security.noBlocked')}</p>
            )}
        </>
    );

    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-0 md:p-4" onClick={handleOverlayClick}>
            <div className="bg-white dark:bg-[#1E1E1E] w-full max-w-md h-full rounded-none md:rounded-2xl shadow-2xl flex flex-col animate-slideIn max-h-full md:max-h-[90vh]">
                 <header className="flex items-center p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
                    {view === 'blocked' && (
                        <button onClick={() => setView('main')} className="text-gray-500 dark:text-gray-300 rtl:ml-4 ltr:mr-4">
                             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M15 18l-6-6 6-6"/></svg>
                        </button>
                    )}
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white flex-1">
                        {view === 'main' ? t('settings.title') : t('settings.security.blocked')}
                    </h3>
                    <button onClick={closeModal} className="text-gray-400 hover:text-gray-800 dark:hover:text-white text-3xl">&times;</button>
                </header>
                <div className="flex-grow pt-4 space-y-4 overflow-y-auto">
                    {view === 'main' ? renderMainView() : renderBlockedView()}
                </div>
            </div>
        </div>
    );
};

export default SettingsModal;