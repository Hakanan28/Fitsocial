
import React, { useState, useEffect, useRef, useMemo, memo } from 'react';
import { Group, UserProfile, GroupMessage, ModalType, Page, CallLog, Post, Reel, NFT } from '../../types';
import { useTranslation } from '../../hooks/i18n';
import GroupInfoModal from './GroupInfoModal'; 
import { GroupNav } from '../layout/NavBar';

interface GroupChatModalProps {
    closeModal: () => void;
    initialGroup?: Group;
    currentUser: UserProfile;
    joinedGroups?: Group[];
    messages: Record<string, GroupMessage[]>;
    onSendMessage: (groupId: string, text: string, type?: 'text' | 'action_gym' | 'action_panic' | 'image' | 'video' | 'stake_challenge', mediaUrl?: string, stakeDetails?: any) => void;
    onSendDm: (recipientUsername: string, text: string, type?: 'text' | 'image' | 'video' | 'stake_challenge', mediaUrl?: string, stakeDetails?: any) => void;
    onProcessRequest?: (groupId: string, userId: string, approved: boolean) => void;
    onPinMessage: (groupId: string, messageId: string | null) => void;
    fitTokenBalance: number;
    openModal: (modal: ModalType, data?: any) => void;
    users: UserProfile[];
    setCurrentPage: (page: Page) => void;
    handleToggleFollow: (username: string) => void;
    showNotification: (message: string, type?: 'success' | 'error') => void;
    handleBlockUser: (username: string) => void;
    callLogs: CallLog[];
    onAddCallLog: (logData: Omit<CallLog, 'id' | 'timestamp'>) => void;
}

const QUICK_REPLIES = [
    "Sounds good!", "On my way.", "Can't talk right now.", "What's up?", "😂", "👍",
    "💪 In the gym", "Thanks!", "Let's do it.", "Maybe tomorrow?", "Details?",
    "Perfect.", "Checking...", "Running late!", "Reschedule?", "Got it.",
    "Let's gooo! 🔥", "Good vibes ✨", "Catch up soon."
];

const ChatListView = memo((props: {
    chatList: any[];
    onSelectChat: (id: string, type: 'group' | 'dm') => void;
    currentUser: UserProfile;
    closeModal: () => void;
    allUsers: UserProfile[];
}) => {
    const [searchQuery, setSearchQuery] = useState('');
    const { t } = useTranslation();

    // Combined list: existing chats + global user search
    const combinedList = useMemo(() => {
        const lowerQuery = searchQuery.toLowerCase().trim();
        
        // If no search query, just return existing chats
        if (!lowerQuery) {
            return props.chatList;
        }

        // Filter existing chats
        const filteredExisting = props.chatList.filter(c => c.name.toLowerCase().includes(lowerQuery));
        
        // Find users who match the query but are NOT in the existing chat list
        // We also exclude the current user
        const existingChatIds = new Set(props.chatList.map(c => c.id));
        
        const globalMatches = props.allUsers
            .filter(u => 
                u.username.toLowerCase().includes(lowerQuery) && 
                u.username !== props.currentUser.username &&
                !existingChatIds.has(u.username)
            )
            .map(u => ({
                id: u.username,
                type: 'dm' as const,
                name: u.username,
                avatar: u.avatarImage,
                lastMessageText: 'Start a new conversation',
                lastMessageTimestamp: 0,
                lastMessageSender: '',
                data: u,
                isNew: true // Flag to visually distinguish new chats
            }));

        return [...filteredExisting, ...globalMatches];

    }, [searchQuery, props.chatList, props.allUsers, props.currentUser.username]);

    return (
        <div className="flex flex-col h-full bg-[#1a1c23] relative animate-fadeIn">
            <header className="p-4 bg-[#20232b]/90 backdrop-blur-md flex justify-between items-center z-10 sticky top-0 border-b border-white/5">
                <h2 className="text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-blue-500">{t('dms.messages')}</h2>
                <div className="flex gap-3">
                     <button onClick={props.closeModal} className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center text-slate-300 hover:bg-red-500/20 hover:text-red-400 transition-all shadow-lg">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                     </button>
                </div>
            </header>
            <div className="px-4 pb-2 pt-2">
                <div className="relative">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                    <input type="search" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder={t('groups.search') as string} className="w-full bg-[#2a2e37] text-white text-sm rounded-2xl pl-10 pr-4 py-3 border border-slate-700/50 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all placeholder-gray-500" />
                </div>
            </div>
            <main className="flex-1 overflow-y-auto p-2 space-y-1">
                {combinedList.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-center p-6 opacity-60">
                        <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-4 border border-slate-700">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-slate-400"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                        </div>
                        <h3 className="text-lg font-bold text-white mb-2">No chats yet</h3>
                        <p className="text-sm text-slate-400">Search for friends or create a new tribe to start messaging.</p>
                    </div>
                ) : (
                    combinedList.map((chat: any) => (
                        <div key={chat.id} onClick={() => props.onSelectChat(chat.id, chat.type)} className="flex items-center gap-4 p-3 hover:bg-slate-800/50 rounded-3xl cursor-pointer transition-all group border border-transparent hover:border-slate-700/50">
                            <div className="relative">
                                <img src={chat.avatar} alt={chat.name} className={`w-14 h-14 object-cover border-2 transition-colors ${chat.type === 'group' ? 'rounded-2xl' : 'rounded-full'} border-slate-700 group-hover:border-emerald-500`} />
                                {chat.type === 'dm' && chat.data.isOnline && (
                                    <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-[#1a1c23]"></div>
                                )}
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-center mb-1">
                                    <h3 className="font-bold text-slate-100 truncate text-base">{chat.name}</h3>
                                    {chat.lastMessageTimestamp > 0 && <span className="text-[11px] text-slate-500 font-medium">{new Date(chat.lastMessageTimestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>}
                                </div>
                                <p className={`text-sm truncate group-hover:text-slate-300 transition-colors ${chat.isNew ? 'text-blue-400 italic' : 'text-slate-400'}`}>
                                    {chat.isNew ? 'Tap to message' : (
                                        <>
                                            {chat.lastMessageSender && <span className="font-semibold text-emerald-400/80">{chat.lastMessageSender === props.currentUser.username ? 'You' : chat.lastMessageSender}: </span>}
                                            {chat.lastMessageText}
                                        </>
                                    )}
                                </p>
                            </div>
                        </div>
                    ))
                )}
            </main>
        </div>
    );
});

const ChatInputFooter: React.FC<{
    input: string;
    setInput: (val: string) => void;
    onSend: () => void;
    isGroup: boolean;
    onSendMessage: (groupId: string, text: string, type: 'action_gym' | 'action_panic' | 'image' | 'video' | 'stake_challenge', mediaUrl?: string, stakeDetails?: any) => void;
    activeChatId: string;
    onMediaSelected: (file: File) => void;
    openModal: (modal: ModalType, data?: any) => void;
}> = (props) => {
    const { t } = useTranslation();
    const [showActions, setShowActions] = useState(false);
    const [isListening, setIsListening] = useState(false);
    
    const fileInputRef = useRef<HTMLInputElement>(null);
    const cameraInputRef = useRef<HTMLInputElement>(null);
    const videoCameraInputRef = useRef<HTMLInputElement>(null);

    const handleQuickReply = (reply: string) => {
        props.setInput(reply);
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            props.onMediaSelected(file);
            setShowActions(false);
        }
    };

    const handleStakeChallenge = (details: { amount: number, durationHours: number, task: string }) => {
        props.onSendMessage(props.activeChatId, "I challenge you!", 'stake_challenge', undefined, {
             amount: details.amount,
             task: details.task,
             durationHours: details.durationHours,
             status: 'pending',
             challengerId: 'me',
             poolTotal: details.amount * 2
        });
        setShowActions(false);
    };

    return (
        <div className="p-2 bg-[#15171e]/95 backdrop-blur-xl border-t border-white/10 sticky bottom-0 z-30 safe-area-pb">
            <div className="flex gap-2 overflow-x-auto pb-2 mb-1 scrollbar-hide mask-linear-fade">
                {QUICK_REPLIES.map((reply, idx) => (
                    <button 
                        key={idx} 
                        onClick={() => handleQuickReply(reply)} 
                        className="whitespace-nowrap px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700 text-slate-300 text-xs font-medium hover:bg-emerald-500/20 hover:text-emerald-400 hover:border-emerald-500/50 transition-all flex-shrink-0 active:scale-95"
                    >
                        {reply}
                    </button>
                ))}
            </div>

            {showActions && (
                <div className="absolute bottom-20 left-4 bg-[#2a2e37] border border-gray-700 rounded-2xl p-4 shadow-2xl animate-slideInUp z-40 w-64 grid grid-cols-2 gap-3">
                     {!props.isGroup && (
                         <button onClick={() => { props.openModal(ModalType.StakeChallenge, { onStake: handleStakeChallenge }); setShowActions(false); }} className="col-span-2 p-3 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl text-center text-xs font-bold text-white hover:shadow-lg shadow-orange-500/20 transition-all transform hover:scale-105 flex items-center justify-center gap-2">
                             <span>🏆</span> CREATE STAKE CHALLENGE
                         </button>
                     )}

                    <button onClick={() => cameraInputRef.current?.click()} className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors">
                        <div className="w-10 h-10 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg></div>
                        <span className="text-xs font-bold text-slate-300">Camera</span>
                    </button>
                    <button onClick={() => videoCameraInputRef.current?.click()} className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors">
                         <div className="w-10 h-10 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m22 8-6 4 6 4V8Z"/><rect width="14" height="12" x="2" y="6" rx="2" ry="2"/></svg></div>
                        <span className="text-xs font-bold text-slate-300">Video</span>
                    </button>
                    <button onClick={() => fileInputRef.current?.click()} className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors">
                         <div className="w-10 h-10 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg></div>
                        <span className="text-xs font-bold text-slate-300">Gallery</span>
                    </button>
                    <button onClick={() => fileInputRef.current?.click()} className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors">
                         <div className="w-10 h-10 rounded-full bg-yellow-500/20 text-yellow-400 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg></div>
                        <span className="text-xs font-bold text-slate-300">File</span>
                    </button>
                    
                    {props.isGroup && (
                        <>
                            <button onClick={() => { props.onSendMessage(props.activeChatId, '', 'action_gym'); setShowActions(false); }} className="col-span-1 p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl text-center text-xs font-bold hover:bg-emerald-500/20 transition-colors">💪 GYM Mode</button>
                            <button onClick={() => { props.onSendMessage(props.activeChatId, '', 'action_panic'); setShowActions(false); }} className="col-span-1 p-3 bg-red-500/10 border border-red-500/30 text-red-400 rounded-xl text-center text-xs font-bold hover:bg-red-500/20 transition-colors">🚨 Panic Mode</button>
                        </>
                    )}
                </div>
            )}

            <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} />
            <input type="file" ref={cameraInputRef} accept="image/*" capture="environment" className="hidden" onChange={handleFileChange} />
            <input type="file" ref={videoCameraInputRef} accept="video/*" capture="environment" className="hidden" onChange={handleFileChange} />

            <div className="flex items-end gap-2">
                <button 
                    onClick={() => setShowActions(s => !s)} 
                    className={`p-3 rounded-full transition-all duration-300 ${showActions ? 'bg-white text-black rotate-45' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
                >
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14"/></svg>
                </button>
                
                <div className="flex-1 relative bg-slate-800 rounded-3xl border border-slate-700 focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500/50 transition-all">
                    <textarea 
                        value={props.input} 
                        onChange={e => props.setInput(e.target.value)} 
                        onKeyPress={e => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), props.onSend())} 
                        rows={1} 
                        placeholder={t('groups.messagePlaceholder') as string} 
                        className="w-full bg-transparent text-white text-sm px-4 py-3.5 max-h-32 resize-none focus:outline-none placeholder-slate-500"
                    />
                </div>

                {props.input ? (
                    <button onClick={props.onSend} className="p-3 bg-emerald-500 rounded-full text-white hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/20 transform hover:scale-105 active:scale-95">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                    </button>
                ) : (
                    <button onClick={() => setIsListening(s => !s)} className={`p-3 rounded-full transition-all ${isListening ? 'bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/30' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>
                    </button>
                )}
            </div>
        </div>
    );
};

const ChatView = memo((props: GroupChatModalProps & {
    activeChatId: string;
    activeChatType: 'group' | 'dm';
    onBack: () => void;
    onViewInfo: (data: Group | UserProfile) => void;
    onMediaSelected: (file: File) => void;
    onRequestAccept: () => void; // New prop for accepting request
    onViewMainProfile: (user: UserProfile) => void;
}) => {
    const { activeChatId, activeChatType, currentUser, onBack, onAddCallLog, onViewInfo, onMediaSelected, messages: dmMessages, joinedGroups, onRequestAccept, onViewMainProfile } = props;
    const { t, language } = useTranslation();
    
    const activeChat = useMemo(() => {
        if (activeChatType === 'group') {
            return joinedGroups?.find(g => g.id === activeChatId);
        } else {
            return props.users.find(u => u.username === activeChatId);
        }
    }, [activeChatId, activeChatType, joinedGroups, props.users]);

    const isGroup = activeChatType === 'group';
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const [input, setInput] = useState('');
    const [contextMenu, setContextMenu] = useState<{ msgId: string, text: string, x: number, y: number } | null>(null);
    const [shareMenuOpen, setShareMenuOpen] = useState(false);
    
    const messages: GroupMessage[] = activeChat 
        ? (isGroup ? (activeChat as Group).messages : (dmMessages[(activeChat as UserProfile).username] || []))
        : [];

    const chatStatus = useMemo(() => {
        if (isGroup) return 'active';
        if (messages.length === 0) return 'active'; // New empty chat is active for sending
        
        const hasMyMessages = messages.some(m => m.sender.username === currentUser.username);
        const hasTheirMessages = messages.some(m => m.sender.username !== currentUser.username);

        if (hasMyMessages && hasTheirMessages) return 'active';
        if (hasMyMessages && !hasTheirMessages) return 'request_sent';
        if (!hasMyMessages && hasTheirMessages) return 'request_received';
        
        return 'active';
    }, [messages, isGroup, currentUser.username]);


    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages.length, activeChatId]);
    
    const handleContextMenu = (e: React.MouseEvent, msg: GroupMessage) => {
        e.preventDefault();
        setContextMenu({ msgId: msg.id, text: msg.text || (msg.mediaUrl ? 'Media content' : ''), x: e.clientX, y: e.clientY });
    };

    const pinnedMessageId = isGroup ? (activeChat as Group).pinnedMessageId : undefined;
    const pinnedMessage = pinnedMessageId ? messages.find(m => m.id === pinnedMessageId) : null;
    const [pinnedMessageVisible, setPinnedMessageVisible] = useState(!!pinnedMessage);

    useEffect(() => {
        setPinnedMessageVisible(!!pinnedMessage);
    }, [pinnedMessageId]);

    const handleSend = () => {
        if (!input.trim()) return;
        
        if (isGroup) {
            props.onSendMessage(activeChatId, input, 'text');
        } else {
            props.onSendDm(activeChatId, input, 'text');
        }
        setInput('');
    };
    
    const handleCall = (type: 'voice' | 'video') => {
        if (!activeChat) return;
        onAddCallLog({ type, direction: 'outgoing', participants: [activeChat] });
        const name = isGroup ? (activeChat as Group).name : (activeChat as UserProfile).username;
        props.showNotification(`Starting ${type} call with ${name}...`, 'success');
    };

    const formatDateHeader = (timestamp: number) => {
        return new Date(timestamp).toLocaleDateString(language === 'tr' ? 'tr-TR' : 'en-US', {
            day: '2-digit', month: '2-digit', year: 'numeric', weekday: 'long'
        });
    };

    const formatMessageTime = (timestamp: number) => {
        return new Date(timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    };

    const isSameDay = (ts1: number, ts2: number) => {
        const d1 = new Date(ts1);
        const d2 = new Date(ts2);
        return d1.getFullYear() === d2.getFullYear() &&
               d1.getMonth() === d2.getMonth() &&
               d1.getDate() === d2.getDate();
    };

    const handleShareExternally = async (text: string) => {
        if (navigator.share) {
            try {
                await navigator.share({ title: 'FitSocial Message', text: text });
                props.showNotification("Shared successfully!", "success");
            } catch (err) { console.log('Share canceled'); }
        } else {
            props.showNotification("Native sharing not available on this device.", "error");
        }
        setContextMenu(null);
        setShareMenuOpen(false);
    };

    const handleShareToApp = (app: 'whatsapp' | 'telegram', text: string) => {
        const encodedText = encodeURIComponent(text);
        if (app === 'whatsapp') window.open(`https://wa.me/?text=${encodedText}`, '_blank');
        else if (app === 'telegram') window.open(`https://t.me/share/url?url=https://fitsocial.app&text=${encodedText}`, '_blank');
        setContextMenu(null);
        setShareMenuOpen(false);
    };

    if (!activeChat) return <div className="flex-1 bg-black flex items-center justify-center text-gray-500">Loading...</div>;

    const avatar = isGroup ? (activeChat as Group).coverImage : (activeChat as UserProfile).avatarImage;
    const name = isGroup ? (activeChat as Group).name : (activeChat as UserProfile).username;
    const subtitle = isGroup ? `${(activeChat as Group).memberCount} members` : ((activeChat as UserProfile).isOnline ? 'Online' : 'Offline');

    return (
        <div className="flex flex-col h-full bg-[#15171e] relative animate-fadeIn">
            <header className="flex items-center p-3 gap-3 bg-[#20232b]/90 backdrop-blur-md border-b border-white/5 sticky top-0 z-20">
                <button onClick={onBack} className="text-slate-300 p-2.5 rounded-full hover:bg-slate-700 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M15 18l-6-6 6-6"/></svg>
                </button>
                <div className="flex-1 flex items-center gap-3 cursor-pointer" onClick={() => onViewInfo(activeChat)}>
                    <img src={avatar} alt={name} className={`w-11 h-11 object-cover ${isGroup ? 'rounded-2xl' : 'rounded-full'} border border-white/10`} />
                    <div>
                        <h3 className="font-bold text-white text-base">{name}</h3>
                        <p className="text-xs text-slate-400 font-medium">{subtitle}</p>
                    </div>
                </div>
                <div className="flex gap-2">
                    <button onClick={() => handleCall('video')} className="text-slate-300 p-2.5 rounded-full hover:bg-slate-700 transition-colors"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M16 16v-3.27a2.73 2.73 0 0 0-2.73-2.73H8.73A2.73 2.73 0 0 0 6 12.73V16"/><path d="M12 16H8a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-4v3l-2-3z"/></svg></button>
                    <button onClick={() => handleCall('voice')} className="text-slate-300 p-2.5 rounded-full hover:bg-slate-700 transition-colors"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg></button>
                </div>
            </header>

            {pinnedMessage && pinnedMessageVisible && (
                <div className="bg-slate-800/90 backdrop-blur-md p-2 px-4 flex items-center justify-between gap-3 border-b border-white/5 sticky top-[70px] z-10 animate-fadeIn shadow-lg mx-2 mt-2 rounded-xl">
                    <div className="w-1 h-8 bg-emerald-500 rounded-full"></div>
                    <div className="flex-1 min-w-0">
                        <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">Pinned Message</p>
                        <p className="text-xs text-slate-200 truncate font-medium">{pinnedMessage.sender.username}: {pinnedMessage.text}</p>
                    </div>
                    <button onClick={() => setPinnedMessageVisible(false)} className="text-slate-500 p-1.5 hover:text-white hover:bg-white/10 rounded-full transition-colors">&times;</button>
                </div>
            )}

            <main className="flex-1 overflow-y-auto p-4 space-y-2">
                
                {/* REQUEST BANNERS */}
                {chatStatus === 'request_sent' && (
                    <div className="bg-[#2a2e37] p-4 rounded-xl text-center mb-4 border border-slate-700">
                        <p className="text-slate-300 text-sm">You sent a message request.</p>
                        <p className="text-slate-500 text-xs mt-1">Notifications are muted for the recipient until they accept.</p>
                    </div>
                )}
                
                {chatStatus === 'request_received' && (
                    <div className="bg-[#2a2e37] p-4 rounded-xl text-center mb-4 border border-slate-700 sticky top-0 z-10">
                        <p className="text-white font-bold text-sm">{name} wants to send you a message.</p>
                        <p className="text-slate-400 text-xs mt-1 mb-3">Do you want to let them send you messages? They won't know you've seen their message until you accept.</p>
                        <div className="flex gap-3 justify-center">
                            <button className="bg-slate-700 text-white px-4 py-2 rounded-lg text-xs font-bold">Block</button>
                            <button className="bg-slate-700 text-white px-4 py-2 rounded-lg text-xs font-bold">Delete</button>
                            <button onClick={onRequestAccept} className="bg-blue-600 text-white px-6 py-2 rounded-lg text-xs font-bold hover:bg-blue-500">Accept</button>
                        </div>
                    </div>
                )}

                {messages.map((msg: GroupMessage, index: number) => {
                    const isMe = msg.sender?.username === currentUser.username;
                    const prevMsg = messages[index - 1];
                    const showDateHeader = !prevMsg || !isSameDay(msg.timestamp, prevMsg.timestamp);

                    const content = msg.sharedNft || msg.sharedPost;
                    let author: UserProfile | undefined;
                    let mediaUrl: string | undefined;
                    let title: string | undefined;
                    let subtitle: string | undefined;
                    let price: string | undefined;

                    if (content) {
                        if ('collection' in content) { // It's an NFT
                            author = props.users.find(u => u.username === content.owner.username);
                            mediaUrl = content.imageUrl;
                            title = content.name;
                            subtitle = content.collection;
                            price = `${content.price} ${content.currency}`;
                        } else { // It's a Post or Reel
                            author = props.users.find(u => u.username === ('author' in content ? content.author : content.user));
                            mediaUrl = 'mediaUrl' in content ? content.mediaUrl : content.videoSrc;
                            title = content.caption.substring(0, 30) + '...';
                            subtitle = 'Shared Post';
                        }
                    }

                    return (
                        <React.Fragment key={msg.id}>
                            {showDateHeader && (
                                <div className="flex justify-center my-6">
                                    <span className="bg-slate-800/60 text-slate-400 text-[11px] font-bold px-3 py-1 rounded-full backdrop-blur-sm border border-white/5 shadow-sm">
                                        {formatDateHeader(msg.timestamp)}
                                    </span>
                                </div>
                            )}

                             {(msg.type === 'post_share' || msg.type === 'nft_share') && content && (
                                <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} animate-fadeIn`}>
                                     <div onContextMenu={e => handleContextMenu(e, msg)} className={`max-w-[250px] w-full rounded-2xl overflow-hidden shadow-lg ${isMe ? 'bg-emerald-900/40 border-emerald-500/20' : 'bg-slate-800 border-slate-700/50'} border`}>
                                        <div className="flex items-center p-2.5 gap-2 bg-black/20">
                                            <img src={author?.avatarImage} alt={author?.username} className="w-6 h-6 rounded-full" />
                                            <span className="text-xs font-bold text-white truncate">{author?.username}</span>
                                        </div>
                                        <div onClick={() => props.openModal(msg.type === 'nft_share' ? ModalType.ProductDetail : ModalType.PostDetail, content)} className="relative aspect-square bg-black cursor-pointer group">
                                            {mediaUrl && (mediaUrl.endsWith('.mp4') ? <video src={mediaUrl} className="w-full h-full object-cover" muted loop /> : <img src={mediaUrl} alt="Shared content" className="w-full h-full object-cover" />)}
                                            <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                <div className="bg-white/20 backdrop-blur-md p-2 rounded-full"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></div>
                                            </div>
                                        </div>
                                        <div className="p-2.5">
                                            <p className="text-xs font-bold text-white truncate">{title}</p>
                                            <div className="flex justify-between items-center mt-1">
                                                <p className="text-[10px] text-gray-400">{subtitle}</p>
                                                {price && <p className="text-[10px] font-bold text-emerald-400">{price}</p>}
                                            </div>
                                        </div>
                                    </div>
                                    <span className={`text-[9px] mt-1 px-2 ${isMe ? 'text-emerald-200/50' : 'text-slate-500'}`}>
                                        {formatMessageTime(msg.timestamp)} {isMe && '✓'}
                                    </span>
                                </div>
                            )}

                            {(msg.type === 'action_gym' || msg.type === 'action_panic') && (
                                <div className="flex justify-center my-4 animate-fadeIn">
                                    <div className={`flex items-center gap-3 px-5 py-3 rounded-2xl border ${msg.type === 'action_gym' ? 'bg-emerald-900/20 border-emerald-500/30' : 'bg-red-900/20 border-red-500/30'} backdrop-blur-sm shadow-lg`}>
                                        <span className="text-2xl">{msg.type === 'action_gym' ? '💪' : '🚨'}</span>
                                        <div>
                                            <p className="text-sm text-white font-bold">
                                                {msg.sender?.username} {msg.type === 'action_gym' ? 'started a workout!' : 'is in PANIC MODE!'}
                                            </p>
                                            <p className="text-[10px] text-gray-400 text-right mt-1">{formatMessageTime(msg.timestamp)}</p>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {msg.type === 'stake_challenge' && msg.stakeDetails && (
                                <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} animate-fadeIn`}>
                                    <div className="max-w-[280px] w-full bg-gray-900 border border-orange-500/50 rounded-2xl overflow-hidden shadow-2xl">
                                        <div className="bg-gradient-to-r from-orange-700 to-red-800 p-3 flex justify-between items-center">
                                             <span className="font-black text-white text-xs tracking-wider">P2P BET</span>
                                             <span className="text-xs font-bold text-white/80">{msg.stakeDetails.durationHours}h LIMIT</span>
                                        </div>
                                        <div className="p-4 space-y-3">
                                            <div className="text-center">
                                                <p className="text-xs text-gray-400 uppercase font-bold">Total Pool</p>
                                                <p className="text-3xl font-black text-white">{msg.stakeDetails.poolTotal} <span className="text-lg text-orange-500">$FIT</span></p>
                                            </div>
                                            <div className="bg-gray-800 p-2 rounded-lg text-center border border-gray-700">
                                                <p className="text-xs text-gray-400 mb-1">Challenge</p>
                                                <p className="text-sm text-white font-bold">"{msg.stakeDetails.task}"</p>
                                            </div>
                                            
                                            {msg.stakeDetails.status === 'pending' && (
                                                !isMe ? (
                                                    <button onClick={() => props.showNotification("You accepted the stake! 50 FIT locked.", "success")} className="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-2 rounded-lg text-xs transition-all shadow-lg">
                                                        ACCEPT & LOCK {msg.stakeDetails.amount} FIT
                                                    </button>
                                                ) : (
                                                    <p className="text-center text-xs text-orange-400 font-medium animate-pulse">Waiting for acceptance...</p>
                                                )
                                            )}
                                             {msg.stakeDetails.status === 'accepted' && (
                                                <button className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-lg text-xs transition-all shadow-lg">
                                                    SUBMIT PROOF
                                                </button>
                                            )}
                                        </div>
                                        <div className="px-3 py-2 bg-black/40 flex justify-between items-center">
                                             <span className="text-[10px] text-gray-500">{formatMessageTime(msg.timestamp)}</span>
                                             <span className="text-[10px] font-bold text-orange-500">{msg.stakeDetails.status.toUpperCase()}</span>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {(msg.type === 'text' || msg.type === 'image' || msg.type === 'video') && (
                                <div 
                                    onContextMenu={e => handleContextMenu(e, msg)} 
                                    onTouchStart={(e) => {
                                        e.persist();
                                        const timer = setTimeout(() => handleContextMenu({ clientX: e.touches[0].clientX, clientY: e.touches[0].clientY, preventDefault: () => {} } as any, msg), 600);
                                        (e.target as any).dataset.longPressTimer = Number(timer);
                                    }}
                                    onTouchEnd={(e) => clearTimeout(Number((e.target as any).dataset.longPressTimer))}
                                    className={`flex items-end gap-2.5 ${isMe ? 'justify-end' : ''} group relative`}
                                >
                                    {!isMe && (
                                        <img src={msg.sender?.avatarImage} alt={msg.sender?.username} className="w-8 h-8 rounded-full self-end border border-white/10 shadow-sm mb-1" />
                                    )}
                                    <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-[75%]`}>
                                        {!isMe && isGroup && <span className="text-[10px] text-slate-400 ml-1 mb-1">{msg.sender?.username}</span>}
                                        
                                        {msg.mediaUrl ? (
                                            <div className={`rounded-2xl overflow-hidden shadow-md border border-white/5 ${isMe ? 'rounded-br-sm' : 'rounded-bl-sm'} relative`}>
                                                {msg.type === 'video' ? (
                                                    <video src={msg.mediaUrl} controls className="max-w-full max-h-64 object-cover" />
                                                ) : (
                                                    <img src={msg.mediaUrl} alt="Attachment" className="max-w-full max-h-64 object-cover" />
                                                )}
                                                {msg.text && <div className={`p-2 pb-6 text-sm ${isMe ? 'bg-emerald-600 text-white' : 'bg-[#2a2e37] text-slate-200'}`}>{msg.text}</div>}
                                                <span className={`absolute bottom-1 right-2 text-[9px] font-medium drop-shadow-md ${msg.text ? 'text-white/70' : 'text-white/90 bg-black/30 px-1 rounded'}`}>
                                                     {/* Hide read receipt in request mode */}
                                                     {formatMessageTime(msg.timestamp)} {chatStatus !== 'request_sent' && isMe && '✓'}
                                                </span>
                                            </div>
                                        ) : (
                                            <div className={`px-3 py-2 rounded-2xl text-sm leading-relaxed shadow-md transition-all relative min-w-[60px] ${isMe ? 'bg-emerald-600 text-white rounded-br-sm' : 'bg-[#2a2e37] text-slate-200 rounded-bl-sm'}`}>
                                                <span className="block mb-1">{msg.text}</span>
                                                <span className={`text-[9px] block text-right ${isMe ? 'text-emerald-200' : 'text-slate-500'}`}>
                                                    {/* Hide read receipt in request mode */}
                                                    {formatMessageTime(msg.timestamp)} {chatStatus !== 'request_sent' && isMe && '✓'}
                                                </span>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </React.Fragment>
                    );
                })}
                <div ref={messagesEndRef} />
            </main>
            
            {/* Hide input if request received and not accepted */}
            {chatStatus !== 'request_received' && (
                <ChatInputFooter 
                    input={input} 
                    setInput={setInput} 
                    onSend={handleSend}
                    isGroup={isGroup}
                    onSendMessage={props.onSendMessage as any}
                    activeChatId={activeChatId}
                    onMediaSelected={onMediaSelected}
                    openModal={props.openModal}
                />
            )}

            {contextMenu && (
                <div onClick={() => { setContextMenu(null); setShareMenuOpen(false); }} className="fixed inset-0 z-[60]">
                    <div style={{ top: contextMenu.y, left: contextMenu.x }} className="absolute bg-[#2a2e37] border border-white/10 rounded-xl p-1.5 shadow-2xl animate-fadeIn min-w-[160px] flex flex-col gap-1">
                         {shareMenuOpen ? (
                             <>
                                <button onClick={() => setShareMenuOpen(false)} className="w-full text-left px-3 py-2 text-xs font-bold text-slate-400 hover:bg-white/5 rounded-lg border-b border-white/5 mb-1">← Back</button>
                                <button onClick={() => handleShareExternally(contextMenu.text)} className="w-full text-left px-3 py-2 text-xs font-medium text-slate-200 hover:bg-white/10 rounded-lg flex items-center gap-2">📱 System Share</button>
                                <button onClick={() => handleShareToApp('whatsapp', contextMenu.text)} className="w-full text-left px-3 py-2 text-xs font-medium text-green-400 hover:bg-white/10 rounded-lg flex items-center gap-2">💬 WhatsApp</button>
                                <button onClick={() => handleShareToApp('telegram', contextMenu.text)} className="w-full text-left px-3 py-2 text-xs font-medium text-blue-400 hover:bg-white/10 rounded-lg flex items-center gap-2">✈️ Telegram</button>
                                <button onClick={() => { props.onSendDm('Select Friend', contextMenu.text, 'text'); setContextMenu(null); }} className="w-full text-left px-3 py-2 text-xs font-medium text-slate-200 hover:bg-white/10 rounded-lg flex items-center gap-2">↪️ Forward Internally</button>
                             </>
                         ) : (
                            <>
                                {isGroup && <button onClick={() => { props.onPinMessage(activeChatId, contextMenu.msgId); setContextMenu(null); }} className="w-full text-left px-3 py-2 text-xs font-medium text-slate-200 hover:bg-white/10 rounded-lg flex items-center gap-2">📌 Pin Message</button>}
                                <button onClick={() => { navigator.clipboard.writeText(contextMenu.text); setContextMenu(null); }} className="w-full text-left px-3 py-2 text-xs font-medium text-slate-200 hover:bg-white/10 rounded-lg flex items-center gap-2">📋 Copy Text</button>
                                <button onClick={(e) => { e.stopPropagation(); setShareMenuOpen(true); }} className="w-full text-left px-3 py-2 text-xs font-medium text-emerald-400 hover:bg-white/10 rounded-lg flex items-center gap-2">🚀 Share & Forward</button>
                            </>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
});

const CallHistoryView: React.FC<{callLogs: CallLog[]}> = ({callLogs}) => {
    const getParticipantInfo = (log: CallLog): {name: string, avatar: string} => {
        const p = log.participants[0];
        if (!p) return { name: 'Unknown', avatar: '' };
        if ('members' in p) {
            return { name: p.name, avatar: p.coverImage || ''};
        }
        return { name: p.username, avatar: p.avatarImage || ''};
    };

    return (
        <div className="flex flex-col h-full bg-[#1a1c23]">
            <header className="p-4 bg-[#20232b]/80 backdrop-blur-md flex justify-between items-center z-10 sticky top-0 border-b border-white/5">
                <h2 className="text-2xl font-bold text-white">Calls</h2>
            </header>
            <main className="flex-1 overflow-y-auto p-2 space-y-1">
                {callLogs.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-center p-6 opacity-60">
                         <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-4 border border-slate-700">
                             <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-slate-400"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                         </div>
                         <h3 className="text-lg font-bold text-white mb-2">No recent calls</h3>
                         <p className="text-sm text-slate-400">Start a voice or video call from a chat.</p>
                    </div>
                ) : (
                    callLogs.map(log => {
                        const info = getParticipantInfo(log);
                        const isGroup = log.participants[0] && 'members' in log.participants[0];
                        const directionIcon = log.direction === 'outgoing' ? '↗' : log.direction === 'incoming' ? '↙' : '⊘';
                        const color = log.direction === 'missed' ? 'text-red-400' : 'text-slate-400';
                        return (
                            <div key={log.id} className="flex items-center p-3 gap-4 hover:bg-slate-800/50 rounded-2xl cursor-pointer transition-colors border border-transparent hover:border-slate-700/50">
                                <img src={info.avatar} className={`w-12 h-12 object-cover ${isGroup ? 'rounded-xl' : 'rounded-full'}`} />
                                <div className="flex-1">
                                    <h3 className={`font-bold text-base ${log.direction === 'missed' ? 'text-red-400' : 'text-slate-100'}`}>{info.name}</h3>
                                    <p className={`text-xs flex items-center gap-1.5 font-medium ${color}`}>
                                        <span>{directionIcon}</span>
                                        {log.type === 'video' ? 'Video' : 'Voice'} Call • {new Date(log.timestamp).toLocaleDateString()}
                                    </p>
                                </div>
                                <button className="text-slate-400 p-3 hover:bg-white/5 rounded-full transition-colors"><svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg></button>
                            </div>
                        );
                    })
                )}
            </main>
        </div>
    );
};

const GroupChatModal: React.FC<GroupChatModalProps> = (props) => {
    const { initialGroup, joinedGroups = [] } = props;
    
    const [activeChatId, setActiveChatId] = useState<string | null>(initialGroup ? initialGroup.id : null);
    const [activeChatType, setActiveChatType] = useState<'group' | 'dm' | null>(initialGroup ? 'group' : null);
    
    const [view, setView] = useState<'list' | 'chat' | 'calls' | 'discover' | 'group-info' | 'profile'>(initialGroup ? 'chat' : 'list');
    
    const chatList = useMemo(() => {
        const groupChats = joinedGroups.map(group => {
            const lastMessage = group.messages[group.messages.length - 1];
            return {
                id: group.id, type: 'group' as const, name: group.name, avatar: group.coverImage,
                lastMessageText: lastMessage ? (lastMessage.type.includes('action') ? 'Sent an action' : lastMessage.text || 'Sent a file') : 'No messages yet',
                lastMessageTimestamp: lastMessage?.timestamp || 0,
                lastMessageSender: lastMessage?.sender?.username || '',
                data: group
            };
        });
        const dmChats = Object.keys(props.messages).map(username => {
            const user = props.users.find(u => u.username === username);
            if (!user) return null;
            const chatHistory = props.messages[username];
            const lastMessage = chatHistory[chatHistory.length - 1];
            return {
                id: user.username, type: 'dm' as const, name: user.username, avatar: user.avatarImage,
                lastMessageText: lastMessage ? lastMessage.text || 'Shared content' : 'No messages yet',
                lastMessageTimestamp: lastMessage?.timestamp || 0,
                lastMessageSender: lastMessage?.sender?.username || '',
                data: user
            };
        }).filter((c): c is NonNullable<typeof c> => c !== null);

        const allChats = [...groupChats, ...dmChats];
        allChats.sort((a, b) => b.lastMessageTimestamp - a.lastMessageTimestamp);
        return allChats;
    }, [joinedGroups, props.messages, props.users]);
    
    const handleTabChange = (tab: 'chats' | 'calls' | 'discover' | 'profile') => {
        setView(tab === 'chats' ? 'list' : tab);
        setActiveChatId(null);
    };

    const handleMediaUpload = (file: File) => {
        if (!activeChatId) return;
        const mediaUrl = URL.createObjectURL(file);
        const type = file.type.startsWith('video') ? 'video' : 'image';
        if (activeChatType === 'group') {
            props.onSendMessage(activeChatId, '', type, mediaUrl);
        } else {
            props.onSendDm(activeChatId, '', type, mediaUrl);
        }
    };
    
    const renderContent = () => {
        switch(view) {
            case 'calls':
                return <CallHistoryView callLogs={props.callLogs} />;
            case 'discover':
                return <div className="h-full flex items-center justify-center text-slate-500">Discover view coming soon.</div>
            case 'profile':
                 return <GroupInfoModal
                    data={props.currentUser}
                    currentUser={props.currentUser}
                    onBack={() => {}} // Back button hidden in tab mode
                    onViewProfile={(u) => props.openModal(ModalType.Profile, u)}
                    onViewMainProfile={(u) => props.openModal(ModalType.Profile, u)}
                    isTab={true}
                />;
            case 'chat':
                if (activeChatId && activeChatType) {
                    return <ChatView 
                        {...props} 
                        activeChatId={activeChatId}
                        activeChatType={activeChatType}
                        onBack={() => { setView('list'); setActiveChatId(null); }} 
                        onViewInfo={(data) => { setActiveChatId(activeChatType === 'group' ? (data as Group).id : (data as UserProfile).username); setView('group-info'); }}
                        onMediaSelected={handleMediaUpload}
                        onViewMainProfile={(u) => props.openModal(ModalType.Profile, u)}
                        onRequestAccept={() => { 
                            props.onSendDm(activeChatId, 'Accepted request', 'text');
                        }}
                    />;
                }
                // Fallthrough if chat state is invalid
            case 'list':
            default:
                return <ChatListView 
                    chatList={chatList} 
                    allUsers={props.users}
                    onSelectChat={(id, type) => { setActiveChatId(id); setActiveChatType(type); setView('chat'); }}
                    currentUser={props.currentUser}
                    closeModal={props.closeModal}
                />;
            case 'group-info':
                let data: Group | UserProfile | undefined;
                if (activeChatType === 'group') {
                    data = joinedGroups.find(g => g.id === activeChatId);
                } else {
                    data = props.users.find(u => u.username === activeChatId);
                }

                if (data) {
                    return <GroupInfoModal
                        data={data} 
                        currentUser={props.currentUser} 
                        onBack={() => setView('chat')}
                        onViewProfile={(u) => props.openModal(ModalType.Profile, u)} // Keep internal link
                        onViewMainProfile={(u) => props.openModal(ModalType.Profile, u)} // Link to full app profile
                    />
                }
                setView('list');
                return null;
        }
    };

    return (
        <div className="fixed inset-0 z-[500] flex bg-black/95 backdrop-blur-sm animate-fadeIn font-sans overflow-hidden">
            <div className="w-full h-full relative flex flex-col">
                <main className="flex-1 min-h-0 relative">
                    {renderContent()}
                </main>
                {(view === 'list' || view === 'calls' || view === 'discover' || view === 'profile') && (
                    <div className="flex-shrink-0 relative z-50">
                        <GroupNav 
                            activeTab={view === 'calls' ? 'calls' : view === 'discover' ? 'discover' : view === 'profile' ? 'profile' : 'chats'} 
                            onTabChange={handleTabChange} 
                            openModal={props.openModal} 
                        />
                    </div>
                )}
            </div>
        </div>
    );
};

export default GroupChatModal;
