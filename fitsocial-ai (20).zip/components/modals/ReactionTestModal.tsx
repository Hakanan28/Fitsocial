
import React, { useState, useRef, useEffect } from 'react';
import { generateText } from '../../services/geminiService';
import { useTranslation, supportedLanguages } from '../../hooks/i18n';

interface ReactionTestModalProps {
    closeModal: () => void;
}

type GameState = 'intro' | 'waiting' | 'ready' | 'early' | 'result' | 'analyzing' | 'analysis_done';

interface RichAiResult {
    racerTitle: string;
    engineDiagnostics: string;
    pitCrewAdvice: string;
    readinessScore: number;
    emoji: string;
}

const ReactionTestModal: React.FC<ReactionTestModalProps> = ({ closeModal }) => {
    const { t, language } = useTranslation();
    const [gameState, setGameState] = useState<GameState>('intro');
    const [reactionTime, setReactionTime] = useState<number | null>(null);
    const [aiResult, setAiResult] = useState<RichAiResult | null>(null);

    const startTimeRef = useRef<number | null>(null);
    const timeoutRef = useRef<number | null>(null);

    const handleStart = () => {
        setReactionTime(null);
        setAiResult(null);
        setGameState('waiting');
        const waitTime = Math.random() * 3000 + 2000; // 2-5 seconds
        timeoutRef.current = window.setTimeout(() => {
            startTimeRef.current = Date.now();
            setGameState('ready');
        }, waitTime);
    };

    const handleClick = () => {
        switch (gameState) {
            case 'waiting':
                if (timeoutRef.current) clearTimeout(timeoutRef.current);
                setGameState('early');
                break;
            case 'ready':
                if (startTimeRef.current) {
                    const rt = Date.now() - startTimeRef.current;
                    setReactionTime(rt);
                    setGameState('result');
                }
                break;
        }
    };

    const analyzeResult = async () => {
        if (reactionTime === null) return;
        setGameState('analyzing');
        try {
            const languageName = supportedLanguages[language]?.name || 'English';
            const prompt = `Analyze a reaction time of ${reactionTime}ms for a fitness app user. Provide a fun, cyberpunk-themed analysis in ${languageName}. Output ONLY JSON in this exact structure: { "racerTitle": "string", "engineDiagnostics": "string", "pitCrewAdvice": "string", "readinessScore": number (0-100), "emoji": "string" }`;
            const response = await generateText(prompt, false, false, false);
            const jsonString = response.text?.replace(/```json|```/g, '').trim() || '{}';
            setAiResult(JSON.parse(jsonString));
            setGameState('analysis_done');
        } catch (e) {
            console.error("AI Analysis failed:", e);
            setGameState('result'); // Fallback to result screen
        }
    };

    const resetGame = () => {
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        setGameState('intro');
    };

    const renderContent = () => {
        switch (gameState) {
            case 'intro':
                return (
                    <div className="text-center space-y-6 p-6">
                        <h3 className="text-2xl font-bold text-white">Neural Reaction Test</h3>
                        <p className="text-gray-400">When the screen turns <span className="text-green-400 font-bold">GREEN</span>, tap as fast as you can.</p>
                        <button onClick={handleStart} className="w-full bg-green-500 text-black font-bold py-4 rounded-xl text-lg">Start Test</button>
                    </div>
                );
            case 'waiting':
                return (
                    <div className="w-full h-full flex flex-col items-center justify-center text-center bg-red-900/50 cursor-pointer" onClick={handleClick}>
                        <h3 className="text-3xl font-bold text-white">Wait for Green...</h3>
                    </div>
                );
            case 'ready':
                return (
                    <div className="w-full h-full flex flex-col items-center justify-center text-center bg-green-500 cursor-pointer" onClick={handleClick}>
                        <h3 className="text-4xl font-black text-black">TAP NOW!</h3>
                    </div>
                );
            case 'early':
                return (
                    <div className="w-full h-full flex flex-col items-center justify-center text-center bg-blue-900/50 cursor-pointer" onClick={resetGame}>
                        <h3 className="text-3xl font-bold text-white">Too Soon!</h3>
                        <p className="text-blue-300 mt-2">Click to try again.</p>
                    </div>
                );
            case 'result':
            case 'analyzing':
            case 'analysis_done':
                 return (
                    <div className="w-full h-full flex flex-col items-center justify-center text-center space-y-4 p-6">
                        {reactionTime !== null && <h3 className="text-6xl font-black text-white">{reactionTime}<span className="text-2xl text-gray-400">ms</span></h3>}
                        
                        {gameState === 'analyzing' && <p className="text-purple-400 animate-pulse">AI analyzing your neural pathways...</p>}
                        
                        {aiResult && (
                             <div className="bg-gray-800/50 p-4 rounded-lg border border-purple-500/30 w-full max-w-sm animate-fadeIn space-y-3">
                                <p className="text-sm font-bold text-purple-400">{aiResult.racerTitle} {aiResult.emoji}</p>
                                <p className="text-xs text-gray-300">{aiResult.engineDiagnostics}</p>
                                <p className="text-xs text-yellow-400 font-semibold">{aiResult.pitCrewAdvice}</p>
                                <p className="text-lg font-bold">Readiness Score: <span className="text-purple-300">{aiResult.readinessScore}/100</span></p>
                            </div>
                        )}

                        <div className="flex gap-4 w-full pt-4">
                            <button onClick={resetGame} className="flex-1 bg-gray-600 text-white font-bold py-3 rounded-xl">Try Again</button>
                            {reactionTime !== null && gameState === 'result' && <button onClick={analyzeResult} className="flex-1 bg-purple-600 text-white font-bold py-3 rounded-xl">✨ AI Analysis</button>}
                             {gameState === 'analysis_done' && <button onClick={closeModal} className="flex-1 bg-green-600 text-white font-bold py-3 rounded-xl">Done</button>}
                        </div>
                    </div>
                );
        }
    };
    
    return (
        <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4 animate-fadeIn" onClick={closeModal}>
            <div 
                className="bg-[#121212] w-full max-w-md h-[70vh] max-h-[500px] rounded-2xl shadow-2xl flex flex-col border border-gray-700 overflow-hidden" 
                onClick={e => e.stopPropagation()}
            >
                {renderContent()}
            </div>
        </div>
    );
};

export default ReactionTestModal;
