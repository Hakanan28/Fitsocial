import React, { useState } from 'react';
import Modal from '../../ui/Modal';
import { Coin, Transaction } from '../../../types';
import { validateContract } from '../../../services/cryptoService';

interface AddTokenModalProps {
    closeModal: () => void;
    onAddToken: (newCoin: Coin) => void;
    showNotification: (message: string, type?: 'success' | 'error') => void;
}

const AddTokenModal: React.FC<AddTokenModalProps> = ({ closeModal, onAddToken, showNotification }) => {
    const [address, setAddress] = useState('');
    const [foundToken, setFoundToken] = useState<Omit<Coin, 'balance' | 'sparkline' | 'transactions'> | null>(null);
    const [error, setError] = useState('');

    const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newAddress = e.target.value;
        setAddress(newAddress);
        setError('');
        
        // Simulate contract validation
        const tokenInfo = validateContract(newAddress);
        setFoundToken(tokenInfo);
        if (!tokenInfo && newAddress.length > 10) { // Basic check
            setError("Token contract not found or invalid address.");
        }
    };

    const handleAdd = () => {
        if (foundToken) {
            const newCoin: Coin = {
                ...foundToken,
                balance: 0,
                sparkline: Array(30).fill(foundToken.price),
                transactions: []
            };
            onAddToken(newCoin);
            showNotification(`${foundToken.symbol} added to your wallet!`, 'success');
            closeModal();
        }
    };

    return (
        <Modal title="Add Custom Token" closeModal={closeModal} show={true}>
            <div className="space-y-4">
                <div>
                    <label className="text-sm font-bold text-gray-300 block mb-1">Token Contract Address</label>
                    <input 
                        type="text" 
                        value={address} 
                        onChange={handleAddressChange}
                        placeholder="0x..."
                        className={`w-full p-3 bg-gray-800 text-white rounded-xl border transition-all ${error ? 'border-red-500' : 'border-gray-700 focus:border-green-500'}`}
                    />
                    {error && <p className="text-xs text-red-400 mt-1">{error}</p>}
                </div>
                {foundToken && (
                    <div className="p-4 bg-gray-800 rounded-xl space-y-2 animate-fadeIn">
                        <div className="flex justify-between text-sm"><span className="text-gray-400">Token Symbol:</span> <span className="font-bold text-white">{foundToken.symbol}</span></div>
                        <div className="flex justify-between text-sm"><span className="text-gray-400">Name:</span> <span className="font-bold text-white">{foundToken.name}</span></div>
                    </div>
                )}
                <button 
                    onClick={handleAdd} 
                    disabled={!foundToken}
                    className="w-full bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition-all transform hover:scale-105 disabled:bg-gray-500 disabled:cursor-not-allowed"
                >
                    Add Token
                </button>
            </div>
        </Modal>
    );
};

export default AddTokenModal;