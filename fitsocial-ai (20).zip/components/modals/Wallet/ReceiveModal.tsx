import React from 'react';
import Modal from '../../ui/Modal';

interface ReceiveModalProps {
    closeModal: () => void;
}

const ReceiveModal: React.FC<ReceiveModalProps> = ({ closeModal }) => {
    const walletAddress = "0x1234...AbCdEfG";
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${walletAddress}&bgcolor=1f2937&color=ffffff`;

    const handleCopy = () => {
        navigator.clipboard.writeText(walletAddress);
        alert("Address copied to clipboard!");
    };

    return (
        <Modal title="Receive Funds" closeModal={closeModal} show={true}>
            <div className="text-center space-y-4">
                <p className="text-sm text-gray-400">Share your address to receive funds. Only send assets on compatible networks.</p>
                <div className="p-4 bg-gray-800 rounded-xl flex items-center justify-center">
                    <img src={qrCodeUrl} alt="Wallet QR Code" className="w-48 h-48 rounded-lg border-4 border-gray-700"/>
                </div>
                <div className="p-3 bg-gray-800 rounded-xl">
                    <p className="text-sm font-mono text-white break-all">{walletAddress}</p>
                </div>
                <button onClick={handleCopy} className="w-full bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition-all transform hover:scale-105">
                    Copy Address
                </button>
            </div>
        </Modal>
    );
};

export default ReceiveModal;