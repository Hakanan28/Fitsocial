import React, { useEffect, useRef } from 'react';
import { Coin, ModalType } from '../../../types';
import type { Chart } from 'chart.js';

interface CoinDetailModalProps {
    closeModal: () => void;
    openModal: (modal: ModalType, data?: any) => void;
    coin: Coin;
}

const CoinDetailModal: React.FC<CoinDetailModalProps> = ({ closeModal, openModal, coin }) => {
    const chartRef = useRef<HTMLCanvasElement>(null);
    const chartInstance = useRef<Chart | null>(null);

    useEffect(() => {
        if (!chartRef.current || !coin) return;
        if (chartInstance.current) {
            chartInstance.current.destroy();
        }

        const ctx = chartRef.current.getContext('2d');
        if (ctx) {
            const gradient = ctx.createLinearGradient(0, 0, 0, 150);
            const isPositive = coin.priceChange24h >= 0;
            gradient.addColorStop(0, isPositive ? 'rgba(16, 185, 129, 0.6)' : 'rgba(239, 68, 68, 0.6)');
            gradient.addColorStop(1, 'rgba(16, 185, 129, 0)');

            chartInstance.current = new (window as any).Chart(ctx, {
                type: 'line',
                data: {
                    labels: Array(coin.sparkline.length).fill(''),
                    datasets: [{
                        data: coin.sparkline,
                        borderColor: isPositive ? '#10B981' : '#EF4444',
                        backgroundColor: gradient,
                        borderWidth: 2,
                        pointRadius: 0,
                        tension: 0.4,
                        fill: true,
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    scales: { x: { display: false }, y: { display: false } },
                    plugins: { legend: { display: false }, tooltip: { enabled: false } }
                }
            });
        }
        return () => chartInstance.current?.destroy();
    }, [coin]);

    if (!coin) return null;

    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) closeModal();
    };

    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-0" onClick={handleOverlayClick}>
            <div className="bg-[#1E1E1E] w-full max-w-md h-full md:h-auto md:max-h-[90vh] md:rounded-2xl shadow-2xl flex flex-col animate-slideIn">
                <header className="flex items-center p-4 border-b border-gray-700">
                    <img src={coin.logoUrl} alt={coin.name} className="w-8 h-8 mr-3"/>
                    <h3 className="text-xl font-bold text-white flex-1">{coin.name} ({coin.symbol})</h3>
                    <button onClick={closeModal} className="text-gray-400 hover:text-white text-2xl">&times;</button>
                </header>

                <div className="flex-grow p-6 space-y-6 overflow-y-auto">
                    <section>
                        <p className="text-4xl font-extrabold text-white">${coin.price.toLocaleString('en-US')}</p>
                        <p className={`text-lg font-semibold ${coin.priceChange24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                           {coin.priceChange24h >= 0 ? '▲' : '▼'} {Math.abs(coin.priceChange24h).toFixed(2)}% (24h)
                        </p>
                    </section>
                    
                    <div className="h-40">
                        <canvas ref={chartRef}></canvas>
                    </div>

                    <div className="p-4 bg-gray-800 rounded-xl text-center">
                        <p className="text-sm text-gray-400 uppercase">Your Balance</p>
                        <p className="text-2xl font-bold text-white mt-1">{coin.balance.toFixed(4)} {coin.symbol}</p>
                        <p className="text-md text-gray-300">${(coin.balance * coin.price).toFixed(2)}</p>
                    </div>

                    <div className="flex justify-center space-x-4">
                        <button onClick={() => openModal(ModalType.SendCoin, coin)} className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition-all transform hover:scale-105">Send</button>
                        <button onClick={() => openModal(ModalType.ReceiveCoin)} className="flex-1 bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition-all transform hover:scale-105">Receive</button>
                    </div>

                    <div className="border-t border-gray-700 pt-4">
                        <h4 className="text-lg font-bold text-white mb-3">Transaction History</h4>
                        <div className="space-y-3 max-h-48 overflow-y-auto">
                            {coin.transactions.map(tx => (
                                <div key={tx.id} className="flex items-center justify-between text-sm">
                                    <div>
                                        <p className="font-semibold capitalize text-white">{tx.type}</p>
                                        <p className="text-xs text-gray-500">{tx.date}</p>
                                    </div>
                                    <p className={`font-bold ${tx.type === 'received' ? 'text-green-400' : 'text-red-400'}`}>
                                        {tx.type === 'received' ? '+' : '-'} {tx.amount.toFixed(4)} {coin.symbol}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CoinDetailModal;