
import React, { useState, useMemo } from 'react';
import { Group, UserProfile, ModalType } from '../../types';
import { initialGroupData } from '../../data/groups'; // Import groups to find mutual/user groups

interface GroupInfoModalProps {
    data: Group | UserProfile;
    currentUser: UserProfile;
    onBack: () => void;
    onViewProfile: (user: UserProfile) => void; // Internal chat profile view (circular ref maybe, but kept for lists)
    onViewMainProfile: (user: UserProfile) => void; // Navigate to main app profile
    isTab?: boolean; // New prop to indicate if this is rendered as a main tab
}

type TabType = 'members' | 'media' | 'files' | 'links' | 'common_groups';

const GroupInfoModal: React.FC<GroupInfoModalProps> = ({ data, currentUser, onBack, onViewProfile, onViewMainProfile, isTab = false }) => {
    const [activeTab, setActiveTab] = useState<TabType>(
        'members' in data ? 'members' : 'media'
    );

    // Determine type
    const isGroup = 'members' in data;
    const group = isGroup ? (data as Group) : null;
    const user = !isGroup ? (data as UserProfile) : null;
    const isMe = user?.username === currentUser.username;

    // Group Specific Data
    const onlineCount = useMemo(() => group ? group.members.filter(m => m.isOnline).length : 0, [group]);
    const groupMediaMessages = useMemo(() => 
        group ? group.messages.filter(m => m.type === 'image' || m.type === 'video') : [], 
        [group]
    );

    // User Specific Data: Find groups this user is in
    const userGroups = useMemo(() => {
        if (!user) return [];
        // Filter from all available groups where this user is a member
        return initialGroupData.filter(g => g.members.some(m => m.username === user.username));
    }, [user]);

    // Mock shared media
    const userSharedMedia = useMemo(() => [], []);

    const TabButton: React.FC<{ label: string; tabId: TabType; count: number; }> = ({ label, tabId, count }) => (
        <button 
            onClick={() => setActiveTab(tabId)}
            className={`flex-1 pb-3 text-sm font-semibold transition-colors border-b-2 whitespace-nowrap px-4 ${activeTab === tabId ? 'text-blue-400 border-blue-400' : 'text-gray-500 border-transparent hover:text-gray-300'}`}
        >
            {label} <span className="text-xs bg-gray-800 px-1.5 py-0.5 rounded-full ml-1 text-gray-400">{count}</span>
        </button>
    );

    const renderMembersTab = () => (
        <div className="space-y-2">
            <button className="flex items-center w-full p-3 gap-4 text-blue-400 hover:bg-blue-500/10 rounded-xl transition-colors">
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                     <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" x2="19" y1="8" y2="14"/><line x1="22" x2="16" y1="11" y2="11"/></svg>
                </div>
                <span className="font-semibold text-sm">Add Members</span>
            </button>
            {group?.members.map(member => (
                <div key={member.username} onClick={() => onViewProfile(member)} className="flex items-center p-3 gap-3 cursor-pointer hover:bg-gray-800/50 rounded-xl transition-colors">
                    <img src={member.avatarImage} className="w-10 h-10 rounded-full object-cover" alt={member.username} />
                    <div className="flex-1">
                        <h4 className="font-semibold text-white text-sm">{member.username}</h4>
                        <p className={`text-xs ${member.isOnline ? 'text-blue-400' : 'text-gray-500'}`}>{member.isOnline ? 'online' : `last seen recently`}</p>
                    </div>
                    {member.username === group.admin.username && (
                        <span className="text-[10px] font-bold text-black bg-yellow-500 px-2 py-0.5 rounded">ADMIN</span>
                    )}
                </div>
            ))}
        </div>
    );
    
    const renderMediaTab = () => (
        <div className="grid grid-cols-3 gap-1">
            {(isGroup ? groupMediaMessages : userSharedMedia).length > 0 ? (isGroup ? groupMediaMessages : userSharedMedia).map((msg: any) => (
                <div key={msg.id} className="aspect-square bg-gray-900 overflow-hidden relative group cursor-pointer">
                    {msg.type === 'image' && <img src={msg.mediaUrl} className="w-full h-full object-cover" alt="media" />}
                    {msg.type === 'video' && <video src={msg.mediaUrl} className="w-full h-full object-cover" muted />}
                    <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
            )) : (
                <div className="col-span-3 text-center py-16 flex flex-col items-center text-gray-500">
                    <span className="text-4xl mb-2 opacity-50">📷</span>
                    <p className="text-sm">No media shared yet.</p>
                </div>
            )}
        </div>
    );

    const renderGroupsTab = () => (
        <div className="space-y-2">
            {userGroups.length > 0 ? userGroups.map(g => (
                <div key={g.id} className="flex items-center gap-3 p-3 bg-slate-800/40 rounded-xl border border-white/5">
                    <img src={g.coverImage} className="w-10 h-10 rounded-lg object-cover" alt={g.name} />
                    <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-bold text-white">{g.name}</h4>
                        <p className="text-xs text-gray-400">{g.memberCount} members</p>
                    </div>
                </div>
            )) : (
                 <div className="text-center py-16 text-gray-500">
                    <p className="text-sm">No common tribes found.</p>
                </div>
            )}
        </div>
    );

    const renderPlaceholderTab = (title: string, icon: string) => (
        <div className="text-center py-20 text-gray-600 flex flex-col items-center">
            <span className="text-4xl mb-2 opacity-50">{icon}</span>
            <p className="text-sm">No {title} found.</p>
        </div>
    );

    const ActionButton: React.FC<{icon: React.ReactNode, label: string, color?: string, onClick?: () => void}> = ({icon, label, color = "text-blue-400", onClick}) => (
        <button onClick={onClick} className={`flex flex-col items-center gap-1 ${color} hover:opacity-80 transition-opacity`}>
            <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center border border-gray-700 shadow-md">
                {icon}
            </div>
            <span className="text-[10px] font-medium text-gray-400">{label}</span>
        </button>
    );

    return (
        <div className="absolute inset-0 bg-[#1E212B] z-30 flex flex-col animate-fadeIn overflow-hidden">
            {/* Header Section */}
            <div className="relative">
                <div className={`h-32 w-full bg-gradient-to-b ${isGroup ? 'from-blue-900/40' : 'from-emerald-900/40'} to-[#1E212B]`}></div>
                
                {!isTab && (
                    <button onClick={onBack} className="absolute top-4 left-4 text-white p-2 bg-black/20 backdrop-blur-sm rounded-full hover:bg-black/40 transition-colors z-10">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
                    </button>
                )}

                {/* Options Button */}
                <button className="absolute top-4 right-4 text-white p-2 bg-black/20 backdrop-blur-sm rounded-full hover:bg-black/40 transition-colors z-10">
                     <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
                </button>
                
                <div className="absolute -bottom-12 left-6">
                    <img 
                        src={isGroup ? group!.coverImage : user!.avatarImage} 
                        alt={isGroup ? group!.name : user!.username} 
                        className={`w-24 h-24 rounded-full object-cover shadow-2xl border-4 border-[#1E212B] ${!isGroup ? 'bg-black' : ''}`} 
                    />
                </div>
            </div>

            <div className="mt-14 px-6">
                <div className="flex justify-between items-start">
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                        {isGroup ? group!.name : user!.username}
                        {!isGroup && user!.isVerified && <span className="text-blue-400"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg></span>}
                    </h2>
                    
                    {!isGroup && (
                        <button 
                            onClick={() => onViewMainProfile(user!)} 
                            className="bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold px-4 py-2 rounded-full shadow-lg transition-all transform hover:scale-105 flex items-center gap-1"
                        >
                            <span>View FitSocial Profile</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                        </button>
                    )}
                </div>
                
                {isGroup ? (
                    <>
                        <p className="text-sm text-blue-400 font-medium">{group!.memberCount} members, {onlineCount} online</p>
                        <p className="text-sm text-gray-400 mt-3 leading-relaxed">{group!.description}</p>
                        {group!.motto && <p className="text-xs text-gray-500 italic mt-1">"{group!.motto}"</p>}
                        
                        {/* Invite Link */}
                        <div className="mt-4 bg-gray-800/50 p-3 rounded-xl flex items-center justify-between border border-white/5">
                            <div className="flex-1 min-w-0 mr-4">
                                <p className="text-[10px] text-gray-500 uppercase font-bold mb-0.5">Invite Link</p>
                                <p className="text-xs text-blue-300 truncate">t.me/fitsocial/{group!.name.toLowerCase().replace(/\s/g, '')}</p>
                            </div>
                            <button className="text-blue-400 hover:text-white"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>
                        </div>
                    </>
                ) : (
                    <>
                        <p className="text-sm text-emerald-400 font-medium">{user!.isOnline ? 'Online' : 'Last seen recently'}</p>
                        <p className="text-sm text-gray-400 mt-3 leading-relaxed">{user!.bio || "No bio available."}</p>
                        <div className="flex gap-4 mt-2 text-sm text-gray-300">
                             <span><b>{user!.followers}</b> Followers</span>
                             <span><b>{user!.cvsScore.toFixed(1)}</b> CVS</span>
                        </div>
                    </>
                )}
            </div>

            {/* Action Buttons */}
            <section className="flex justify-around p-4 border-b border-gray-800/50 mx-4 mt-2">
                {isGroup ? (
                    <>
                        <ActionButton icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>} label="Mute" />
                        <ActionButton icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>} label="Search" />
                        <ActionButton icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>} label="Leave" color="text-red-400" />
                    </>
                ) : (
                    <>
                        {!isMe && (
                            <>
                                <ActionButton icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>} label="Call" />
                                <ActionButton icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>} label="Mute" />
                                <ActionButton icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" x2="19.07" y1="4.93" y2="19.07"/></svg>} label="Block" color="text-red-400" />
                            </>
                        )}
                        {isMe && (
                             <div className="w-full text-center text-xs text-gray-500 italic py-2">This is how your profile looks in chats.</div>
                        )}
                    </>
                )}
            </section>
            
            {/* Media Tabs */}
            <section className={`flex-1 flex flex-col min-h-0 bg-[#15171e] mt-2 ${isTab ? 'pb-24' : ''}`}>
                <div className="flex px-4 pt-2 bg-[#1E212B] overflow-x-auto scrollbar-hide border-b border-white/5">
                    {isGroup ? (
                        <>
                            <TabButton label="Members" tabId="members" count={group!.members.length} />
                            <TabButton label="Media" tabId="media" count={groupMediaMessages.length} />
                            <TabButton label="Files" tabId="files" count={0} />
                            <TabButton label="Links" tabId="links" count={0} />
                        </>
                    ) : (
                        <>
                             <TabButton label="Media" tabId="media" count={userSharedMedia.length} />
                             <TabButton label="Groups" tabId="common_groups" count={userGroups.length} />
                             <TabButton label="Files" tabId="files" count={0} />
                        </>
                    )}
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                    {activeTab === 'members' && isGroup && renderMembersTab()}
                    {activeTab === 'media' && renderMediaTab()}
                    {activeTab === 'files' && renderPlaceholderTab("files", "📂")}
                    {activeTab === 'links' && renderPlaceholderTab("links", "🔗")}
                    {activeTab === 'common_groups' && renderGroupsTab()}
                </div>
            </section>
        </div>
    );
};

export default GroupInfoModal;
