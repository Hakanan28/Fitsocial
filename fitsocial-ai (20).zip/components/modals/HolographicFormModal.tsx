
import React from 'react';
import { ModalType } from '../../types';

interface HolographicFormModalProps {
    closeModal: () => void;
    openModal: (modal: ModalType) => void;
}

const HolographicFormModal: React.FC<HolographicFormModalProps> = ({ closeModal, openModal }) => {
    
    const handleCloseAndReturn = () => {
        closeModal();
        openModal(ModalType.WorkoutMode);
    }

    return (
        <div className="fixed inset-0 bg-black/90 z-[150] flex flex-col animate-fadeIn">
            <header className="flex justify-between items-center p-4 border-b border-green-700 bg-[#0A0A0A] shadow-lg shadow-green-900/50">
                <h2 className="text-xl font-bold text-green-400" style={{textShadow: '0 0 5px #10B981'}}>✨ Holographic Form Assistant</h2>
                <button onClick={closeModal} className="text-red-500 font-bold hover:text-red-400 transition-colors">Close</button>
            </header>
            <div className="flex-1 flex flex-col items-center justify-center p-4 text-center">
                <div className="w-full h-80 bg-gray-900 rounded-xl relative border-4 border-green-500/70 shadow-2xl shadow-green-900/50 flex items-center justify-center">
                    <span className="text-gray-500">Camera Feed (Simulation)</span>
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="text-center"><span className="text-8xl text-blue-400 opacity-70 animate-pulse">🧍</span><p className="text-xs font-mono text-blue-400 mt-2" style={{textShadow: '0 0 5px #3B82F6'}}>PERFECT FORM HOLOGRAM</p></div>
                    </div>
                </div>
                <div className="mt-6 w-full p-4 bg-gray-800 rounded-xl space-y-3 border border-green-700/50">
                    <h4 className="text-xl font-bold text-white">Bench Press Form Analysis</h4>
                    <div className="flex justify-between text-sm"><span className="text-gray-400">Back Position:</span><span className="text-green-400 font-semibold">Excellent (95%)</span></div>
                    <div className="flex justify-between text-sm"><span className="text-gray-400">Elbow Angle:</span><span className="text-yellow-400 font-semibold">Good (78%) - Narrow slightly</span></div>
                </div>
                <button onClick={handleCloseAndReturn} className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold mt-6 shadow-lg hover:bg-indigo-700 transition-colors transform hover:scale-105">Confirm Form & Close</button>
            </div>
        </div>
    );
};

export default HolographicFormModal;