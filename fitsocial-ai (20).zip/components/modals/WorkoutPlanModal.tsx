
import React from 'react';
import Modal from '../ui/Modal';

interface WorkoutPlanModalProps {
    closeModal: () => void;
    plan: {
        planName: string;
        description: string;
        weeks: {
            week: number;
            dailySchedule: {
                day: string;
                focus: string;
                exercises: {
                    name: string;
                    sets: string;
                    reps: string;
                    rest: string;
                    notes?: string;
                }[];
            }[];
        }[];
    };
}

const WorkoutPlanModal: React.FC<WorkoutPlanModalProps> = ({ closeModal, plan }) => {
    if (!plan) return null;

    return (
        <Modal title="Your AI Generated Plan" closeModal={closeModal} show={true}>
            <div className="space-y-6">
                <div className="text-center p-4 bg-gray-800 rounded-xl border border-teal-500/50">
                    <h2 className="text-2xl font-extrabold text-teal-400">{plan.planName}</h2>
                    <p className="text-md text-gray-300 mt-1">{plan.description}</p>
                </div>

                <div className="space-y-4">
                    {plan.weeks?.map((weekData) => (
                        <details key={weekData.week} className="bg-[#1E1E1E] p-4 rounded-xl shadow-lg" open={weekData.week === 1}>
                            <summary className="text-lg font-bold text-white cursor-pointer hover:text-green-400 transition-colors">Week {weekData.week}</summary>
                            <div className="mt-4 space-y-4">
                                {weekData.dailySchedule?.map((day, index) => (
                                    <div key={index} className="bg-gray-800/50 p-3 rounded-lg">
                                        <h4 className="font-bold text-green-400">{day.day}: <span className="text-gray-200">{day.focus}</span></h4>
                                        <div className="mt-2 space-y-2">
                                            {day.exercises?.map((ex, exIndex) => (
                                                <div key={exIndex} className="bg-gray-700/50 p-2 rounded-lg text-sm">
                                                    <div className="flex justify-between items-center">
                                                        <span className="font-semibold text-gray-200 flex-1">{ex.name}</span>
                                                        <div className="flex space-x-3 text-center text-xs">
                                                            <span><strong className="text-white block">{ex.sets}</strong> sets</span>
                                                            <span><strong className="text-white block">{ex.reps}</strong> reps</span>
                                                            <span><strong className="text-white block">{ex.rest}</strong> rest</span>
                                                        </div>
                                                    </div>
                                                     {ex.notes && <p className="text-xs text-yellow-400 italic mt-1 pl-1">Note: {ex.notes}</p>}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </details>
                    ))}
                </div>
                
                <button
                    onClick={() => {
                        alert('Workout plan saved to "My Routines"! (Simulated)');
                        closeModal();
                    }}
                    className="w-full bg-green-500 text-white py-3 rounded-xl font-bold mt-4 shadow-md hover:bg-green-600 transition-colors transform hover:scale-105"
                >
                    Save Plan & Close
                </button>
            </div>
        </Modal>
    );
};

export default WorkoutPlanModal;
