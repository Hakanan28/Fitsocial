import React, { useState, useEffect, useMemo, useRef } from 'react';
import { ModalType, NFT, UserProfile, ProofOfWorkoutPost, WorkoutRoutine, Post, Reel, BadgeNFT, Challenge, ExploreTab, AiRecipeResponse, DetailedUserProfileData, FoodLogEntry, Group } from '../../types';
import { useTranslation, supportedLanguages } from '../../hooks/i18n';
import { generateDailyChallenge, generateAiKitchenPlan } from '../../services/geminiService';
import { initialGearItems } from '../../data/marketplace';
import SuggestionCarousel from '../ui/SuggestionCarousel';

interface ExplorePageProps {
    openModal: (modal: ModalType, data?: any) => void;
    onViewReelsFeed: (feed: Reel[], initialReelId: number) => void;
    isProUser: boolean;
    fitTokenBalance: number;
    setFitTokenBalance: React.Dispatch<React.SetStateAction<number>>;
    setNfts: React.Dispatch<React.SetStateAction<NFT[]>>;
    nfts: NFT[];
    viewUserProfile: (user: UserProfile) => void;
    currentUser: UserProfile;
    handleToggleFollow: (username: string) => void;
    users: UserProfile[];
    posts: Post[];
    reels: Reel[];
    proofOfWorkouts: ProofOfWorkoutPost[];
    workoutRoutines: WorkoutRoutine[];
    handleLikeProofOfWorkout: (postId: string) => void;
    handleLikeWorkoutRoutine: (routineId: string) => void;
    earnedNfts: BadgeNFT[];
    challenges: Challenge[];
    handleJoinChallenge: (challengeId: string) => void;
    groups: Group[];
    handleOpenGroup: (group: Group) => void;
    // NEW PROPS
    onAddMeal: (macros: any, date: string, foodName?: string, mealType?: string) => void;
    userProfileData: DetailedUserProfileData;
    nutritionHistory: { date: string, macros: any }[];
    foodLog?: FoodLogEntry[];
    nutritionGoals: any;
}

type SearchTab = 'all' | 'users' | 'routines' | 'content' | 'groups';

// Helper hook to detect if an element is visible in the viewport
const useIsVisible = (ref: React.RefObject<HTMLElement>) => {
    const [isIntersecting, setIntersecting] = useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(([entry]) => {
            setIntersecting(entry.isIntersecting);
        });

        const currentRef = ref.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, [ref]);

    return isIntersecting;
};

// A dedicated component to handle video playback within cards
const VideoPlayer: React.FC<{ src: string }> = ({ src }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const isVisible = useIsVisible(videoRef);

    useEffect(() => {
        if (videoRef.current) {
            if (isVisible) {
                videoRef.current.play().catch(e => console.error("Video autoplay failed", e));
            } else {
                videoRef.current.pause();
            }
        }
    }, [isVisible]);

    // Use a container for the ref to ensure the observer works correctly
    const containerRef = useRef<HTMLDivElement>(null);
    useEffect(() => {
        if (containerRef.current && videoRef.current) {
             (containerRef.current as any).videoNode = videoRef.current;
        }
    }, []);


    return (
        <div ref={containerRef} className="absolute inset-0 w-full h-full">
            <video ref={videoRef} src={src} muted loop playsInline className="w-full h-full object-cover" />
        </div>
    );
};


const ProPlaceholder: React.FC<{ title: string; openModal: (modal: ModalType) => void; }> = ({ title, openModal }) => {
    const { t } = useTranslation();
    return (
        <div className="h-48 flex flex-col items-center justify-center bg-gray-800 rounded-xl shadow-inner">
            <span className="text-4xl">⭐️</span>
            <p className="text-md font-bold text-yellow-400 mt-3 text-center">{t('explore.proFeature', { title })}</p>
            <button onClick={() => openModal(ModalType.PremiumPitch)} className="bg-yellow-500 text-black text-sm font-bold py-2 px-4 rounded-xl mt-4 shadow-md hover:bg-yellow-400 transition-colors transform hover:scale-105">{t('explore.goPro')}</button>
        </div>
    );
};


const ExplorePage: React.FC<ExplorePageProps> = ({ 
    openModal, onViewReelsFeed, isProUser, fitTokenBalance, setFitTokenBalance, 
    setNfts, nfts, viewUserProfile, currentUser, handleToggleFollow, users, 
    posts, reels, proofOfWorkouts, workoutRoutines, handleLikeProofOfWorkout, 
    handleLikeWorkoutRoutine, earnedNfts, challenges, handleJoinChallenge, 
    groups, handleOpenGroup,
    onAddMeal, userProfileData, nutritionHistory, foodLog, nutritionGoals
}) => {
    const { t, language } = useTranslation();
    const [activeTab, setActiveTab] = useState<ExploreTab>('discoverMore');
    const [searchQuery, setSearchQuery] = useState('');
    const [isSearching, setIsSearching] = useState(false);
    const [activeMenu, setActiveMenu] = useState<string | null>(null);

     const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const query = e.target.value;
        setSearchQuery(query);
        setIsSearching(query.trim().length > 0);
    };

    const handleCopyLink = (type: string, id: string | number) => {
        navigator.clipboard.writeText(`https://fitsocial.app/${type}/${id}`);
        alert("Link copied to clipboard!");
        setActiveMenu(null);
    };

    const searchResults = useMemo(() => {
        if (!searchQuery.trim()) {
            return { users: [], content: [], routines: [], groups: [] };
        }

        const query = searchQuery.toLowerCase().trim();
        const isTagSearch = query.startsWith('#');
        const tagQuery = isTagSearch ? query.substring(1) : '';

        const filteredUsers = users.filter(u => 
            u.username.toLowerCase().includes(query)
        );

        const allContent: (Post | Reel)[] = [...posts, ...reels];
        const filteredContent = allContent.filter(c => 
            c.caption.toLowerCase().includes(query) ||
            (c.taggedUsers && c.taggedUsers.some(t => t.toLowerCase().includes(query)))
        );

        const filteredRoutines = workoutRoutines.filter(r => 
            r.routineName.toLowerCase().includes(query) ||
            (r.description && r.description.toLowerCase().includes(query)) ||
            (isTagSearch && r.tags && r.tags.some(tag => tag.toLowerCase().includes(tagQuery)))
        );

        // Search Groups
        const filteredGroups = groups.filter(g => 
            g.name.toLowerCase().includes(query) ||
            (g.tags && g.tags.some(t => t.toLowerCase().includes(query))) ||
            g.admin.username.toLowerCase().includes(query) ||
            g.members.some(m => m.username.toLowerCase().includes(query))
        );
        
        return { users: filteredUsers, content: filteredContent, routines: filteredRoutines, groups: filteredGroups };
    }, [searchQuery, users, posts, reels, workoutRoutines, groups]);

    const SearchResultsComponent = () => {
        const [searchTab, setSearchTab] = useState<SearchTab>('all');
        
        const SearchTabButton: React.FC<{tabId: SearchTab; label: string; count: number}> = ({tabId, label, count}) => (
            <button onClick={() => setSearchTab(tabId)} className={`px-4 py-2 text-sm font-semibold rounded-t-lg border-b-2 transition-colors ${searchTab === tabId ? 'text-green-400 border-green-400' : 'text-gray-400 border-transparent'}`}>
                {label} ({count})
            </button>
        );

        const renderAll = () => (
            <>
                {searchResults.users.length > 0 && renderUsers(3)}
                {searchResults.groups.length > 0 && renderGroups(2)}
                {searchResults.routines.length > 0 && renderRoutines(3)}
                {searchResults.content.length > 0 && renderContent(3)}
                {searchResults.users.length === 0 && searchResults.routines.length === 0 && searchResults.content.length === 0 && searchResults.groups.length === 0 && (
                     <p className="text-center text-gray-500 py-16">No results found for "{searchQuery}".</p>
                )}
            </>
        )
        const renderUsers = (limit?: number) => (
            <div className="space-y-2">
                {searchResults.users.slice(0, limit).map(user => (
                    <div key={user.username} onClick={() => viewUserProfile(user)} className="flex items-center p-3 hover:bg-gray-700 rounded-xl cursor-pointer transition-colors">
                        <img className="w-12 h-12 rounded-full object-cover" src={user.avatarImage} alt={user.username}/>
                        <div className="ml-3">
                            <h4 className="font-bold text-white text-lg">{user.username}</h4>
                            <p className="text-sm text-gray-400">{user.bio || 'FitSocial User'}</p>
                        </div>
                    </div>
                ))}
            </div>
        );
         const renderRoutines = (limit?: number) => (
             <div className="space-y-2">
                {searchResults.routines.slice(0, limit).map(routine => (
                     <div key={routine.id} onClick={() => openModal(ModalType.RoutineDetails, { title: routine.routineName, description: routine.description, exercises: routine.exercises.map(e => `${e.exercise.name}: ${e.sets}x${e.reps}`) })} className="bg-[#1E1E1E] p-4 rounded-xl shadow-lg cursor-pointer hover:bg-gray-700 transition-colors">
                        <h3 className="font-bold text-white text-lg truncate">{routine.routineName}</h3>
                        <p onClick={(e) => {e.stopPropagation(); viewUserProfile(routine.user);}} className="text-sm text-gray-400 mt-1 hover:text-white transition-colors">by @{routine.user.username}</p>
                    </div>
                ))}
            </div>
         );
        const renderContent = (limit?: number) => (
             <div className="grid grid-cols-2 gap-2">
                {searchResults.content.slice(0, limit).map(item => {
                    const isReel = 'videoSrc' in item;
                    const mediaUrl = isReel ? (item as Reel).videoSrc : (item as Post).mediaUrl;
                    const mediaType = isReel ? 'video' : (item as Post).mediaType;
                    return (
                        <div key={item.id} onClick={() => openModal(isReel ? ModalType.ReelPlayer : ModalType.PostDetail, item)} className="relative aspect-square bg-gray-800 rounded-md overflow-hidden cursor-pointer">
                            {mediaType === 'video' ? <video src={mediaUrl} muted loop className="w-full h-full object-cover"/> : <img src={mediaUrl} alt={item.caption} className="w-full h-full object-cover" />}
                        </div>
                    )
                })}
            </div>
        );

        const renderGroups = (limit?: number) => (
            <div className="grid grid-cols-2 gap-3 md:gap-5">
                {searchResults.groups.slice(0, limit).map(group => (
                    <div 
                        key={group.id} 
                        className="group relative flex flex-col aspect-[4/5] rounded-2xl overflow-hidden cursor-pointer shadow-lg hover:shadow-emerald-900/20 transition-all duration-300 hover:scale-[1.02] border border-white/5" 
                        onClick={() => handleOpenGroup(group)}
                    >
                        {/* Top Image Section (60%) */}
                        <div className="h-[60%] w-full relative bg-gray-900 overflow-hidden">
                            {group.coverImage ? (
                                <img 
                                    src={group.coverImage} 
                                    alt={group.name} 
                                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                                />
                            ) : (
                                <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                                    <span className="text-2xl opacity-20">🛡️</span>
                                </div>
                            )}
                            
                            {/* Gradient Overlay */}
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60"></div>
                        </div>

                        {/* Bottom Info Section (40%) - Using Theme */}
                        <div 
                            className="h-[40%] w-full p-3 relative flex flex-col justify-between"
                            style={{ background: group.theme.gradient }}
                        >
                            {/* Noise Texture */}
                            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay pointer-events-none"></div>
                            
                            <div className="relative z-10">
                                <div className="flex items-center gap-2 mb-1">
                                    <div className="w-6 h-6 rounded-full bg-white/20 backdrop-blur-md flex-shrink-0 flex items-center justify-center text-[10px] font-bold text-white border border-white/20 shadow-inner">
                                        {group.name.charAt(0).toUpperCase()}
                                    </div>
                                    <h3 className="font-bold text-white text-sm leading-tight shadow-black drop-shadow-md line-clamp-1">{group.name}</h3>
                                </div>
                                
                                <p className="text-[10px] text-white/80 font-medium italic line-clamp-2 leading-snug">"{group.motto}"</p>
                            </div>

                            <div className="relative z-10 flex items-center justify-between mt-2">
                                <div className="flex items-center gap-1">
                                    <span className="text-[8px] font-bold bg-black/20 px-1.5 py-0.5 rounded text-white/90 border border-white/5 backdrop-blur-sm">
                                        {group.memberCount} 👥
                                    </span>
                                </div>
                                {group.isPrivate && (
                                    <span className="text-[10px] opacity-70">🔒</span>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        );

        return (
            <div className="p-4 space-y-4 animate-fadeIn">
                 <div className="flex border-b border-gray-700 overflow-x-auto scrollbar-hide">
                    <SearchTabButton tabId="all" label="All" count={searchResults.users.length + searchResults.content.length + searchResults.routines.length + searchResults.groups.length} />
                    <SearchTabButton tabId="users" label="Users" count={searchResults.users.length} />
                    <SearchTabButton tabId="groups" label="Tribes" count={searchResults.groups.length} />
                    <SearchTabButton tabId="routines" label="Routines" count={searchResults.routines.length} />
                    <SearchTabButton tabId="content" label="Content" count={searchResults.content.length} />
                </div>
                {searchTab === 'all' && renderAll()}
                {searchTab === 'users' && renderUsers()}
                {searchTab === 'groups' && renderGroups()}
                {searchTab === 'routines' && renderRoutines()}
                {searchTab === 'content' && renderContent()}
            </div>
        );
    }

    const DiscoverMoreContent = () => {
        const exploreContent = useMemo(() => {
            const postItems = posts.map(p => ({ ...p, contentType: 'post' as const }));
            const reelItems = reels.map(r => ({ ...r, contentType: 'reel' as const }));
            
            const allContent = [...postItems, ...reelItems];

            return allContent.filter(item => {
                const interactionCheck = item.likes >= 500 || item.comments.length >= 200;
                return interactionCheck;
            });
        }, [posts, reels]);
        
        const exploreReels = useMemo(() => exploreContent.filter(item => item.contentType === 'reel') as (Reel & { contentType: 'reel' })[], [exploreContent]);

        const handlePoWAction = (e: React.MouseEvent, action: 'like' | 'comment' | 'share', post: ProofOfWorkoutPost) => {
            e.stopPropagation();
            if (action === 'like') {
                handleLikeProofOfWorkout(post.id);
            } else if (action === 'comment') {
                openModal(ModalType.Comments, { id: post.id, author: post.user.username, type: 'pow' });
            } else if (action === 'share') {
                openModal(ModalType.SharePost, { mediaUrl: post.mediaUrl, author: post.user.username });
            }
        };

        return (
            <div className="space-y-8 mt-4">
                 {/* Proof of Workout Section */}
                <section>
                    <div className="flex justify-between items-center mb-4 px-4">
                        <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                            <span>✅</span>
                            <span>{t('explore.proofOfWorkout')}</span>
                        </h2>
                        <button onClick={() => openModal(ModalType.ProofOfWorkout)} className="bg-green-500/20 text-green-300 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide shadow-md hover:bg-green-500/40 transition-colors transform hover:scale-105 flex items-center gap-1">
                             <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                            <span>{t('explore.shareYours')}</span>
                        </button>
                    </div>
                    {proofOfWorkouts.length > 0 ? (
                        <div className="flex space-x-3 overflow-x-auto pb-4 -mx-4 px-4 scrollbar-hide">
                            {proofOfWorkouts.map(post => (
                                <div key={post.id} className="group relative w-40 h-64 flex-shrink-0 rounded-xl overflow-hidden shadow-2xl transform transition-transform hover:-translate-y-1 border border-white/10 bg-black">
                                    {/* Full Card Video/Image */}
                                    <div className="absolute inset-0 cursor-pointer" onClick={() => openModal(ModalType.ProofOfWorkoutDetail, post)}>
                                         {post.mediaType === 'video' ? (
                                            <VideoPlayer src={post.mediaUrl} />
                                        ) : (
                                            <img src={post.mediaUrl} alt={post.activity} className="w-full h-full object-cover"/>
                                        )}
                                        
                                        {/* Full Gradient Overlay for readability */}
                                        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/90 pointer-events-none"></div>
                                        
                                        {/* Verified Badge - Top Right */}
                                        {post.isVerified && <span className="absolute top-2 right-2 text-[8px] font-black bg-emerald-500 text-black px-1.5 py-0.5 rounded uppercase tracking-widest shadow-lg">Verified</span>}

                                        {/* Bottom Text Overlay - Full Width */}
                                        <div className="absolute bottom-0 left-0 right-0 p-3 pointer-events-none flex flex-col justify-end h-full">
                                            {/* User Info */}
                                            <div className="flex items-center gap-1.5 mb-2 pointer-events-auto cursor-pointer" onClick={(e) => {e.stopPropagation(); viewUserProfile(post.user);}}>
                                                 <img src={post.user.avatarImage} className="w-6 h-6 rounded-full border border-white/80 shadow-md" alt="Avatar" />
                                                 <div className="flex flex-col">
                                                     <span className="text-white font-bold text-xs shadow-black drop-shadow-md leading-none">{post.user.username}</span>
                                                 </div>
                                            </div>
                                            
                                            {/* Activity Title */}
                                            <h3 className="text-white font-extrabold text-lg uppercase leading-tight drop-shadow-md mb-1 line-clamp-2">{post.activity}</h3>
                                            
                                            {/* Stats Row */}
                                            <div className="flex items-center gap-2 mb-2">
                                                <span className="text-[9px] font-bold text-gray-300">{post.duration.minutes}m • {post.effort}/5</span>
                                            </div>

                                            {/* Interaction Buttons on Overlay */}
                                            <div className="flex gap-3 pointer-events-auto mt-1">
                                                 <button onClick={(e) => handlePoWAction(e, 'like', post)} className="flex items-center gap-1 group">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill={post.isLiked ? "#ef4444" : "none"} stroke={post.isLiked ? "#ef4444" : "white"} strokeWidth="2" className="drop-shadow-lg group-hover:scale-110 transition-transform"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                                                    <span className="text-[10px] font-bold text-white drop-shadow-md">{post.likes}</span>
                                                </button>
                                                <button onClick={(e) => handlePoWAction(e, 'comment', post)} className="flex items-center gap-1 group">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="drop-shadow-lg group-hover:scale-110 transition-transform"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                                                    <span className="text-[10px] font-bold text-white drop-shadow-md">{post.comments.length}</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="px-4">
                            <div className="text-center py-12 px-4 bg-gray-800/50 rounded-2xl border border-white/5 dashed-border">
                                <span className="text-4xl block mb-3">🤸</span>
                                <p className="text-gray-200 font-bold">No workouts shared yet.</p>
                                <p className="text-xs text-gray-500 mt-1">Be the first to share your proof of workout!</p>
                            </div>
                        </div>
                    )}
                </section>

                {/* Popular Routines Section */}
                <section>
                     <div className="flex justify-between items-center mb-3 px-4">
                        <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                            <span>🔥</span>
                            <span>{t('explore.popularRoutines')}</span>
                        </h2>
                         <button onClick={() => openModal(ModalType.CreateRoutine)} className="bg-green-500/20 text-green-300 px-3 py-1.5 rounded-full text-sm font-semibold shadow-md hover:bg-green-500/40 transition-colors transform hover:scale-105 flex items-center gap-1">
                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                             <span>Create Routine</span>
                        </button>
                    </div>
                     {workoutRoutines.length > 0 ? (
                        <div className="flex space-x-4 overflow-x-auto pb-2 -mx-4 px-4">
                            {workoutRoutines.map(routine => (
                                <div key={routine.id} className="bg-gradient-to-br from-[#2d3436] to-[#1E1E1E] border border-gray-700 p-4 rounded-2xl shadow-lg cursor-pointer hover:border-green-500/50 transition-all w-80 flex-shrink-0 flex flex-col relative">
                                    <div onClick={() => openModal(ModalType.RoutineDetails, { title: routine.routineName, description: routine.description, exercises: routine.exercises.map(e => `${e.exercise.name}: ${e.sets}x${e.reps}`) })} className="flex-1">
                                        <div className="flex items-start justify-between">
                                            <h3 className="font-bold text-white text-lg pr-8">{routine.routineName}</h3>
                                            <div className="flex items-center text-xs bg-yellow-500/10 text-yellow-400 font-bold px-2 py-1 rounded-full">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor" className="mr-1"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                                                <span>{routine.rating?.toFixed(1) || 'N/A'}</span>
                                            </div>
                                        </div>
                                        <div onClick={(e) => { e.stopPropagation(); viewUserProfile(routine.user);}} className="flex items-center gap-2 mt-2 cursor-pointer w-fit group">
                                            <img src={routine.user.avatarImage} alt={routine.user.username} className="w-6 h-6 rounded-full object-cover border border-transparent group-hover:border-white/50 transition-colors" />
                                            <span className="text-sm text-gray-400 font-medium group-hover:text-white transition-colors">by @{routine.user.username}</span>
                                        </div>
                                        <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm text-gray-300 mt-4">
                                            <div className="flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-green-400"><path d="M12 3v18"/><path d="m19 9-7 7-7-7"/></svg> {routine.difficulty}</div>
                                            <div className="flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-green-400"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="M12 6v6l4 2"/></svg> {routine.duration || 'N/A'} min</div>
                                            <div className="flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-green-400"><path d="m6.5 6.5 11 11"/><path d="m21 21-1-1"/><path d="m3 3 1 1"/><path d="m18 22 4-4"/><path d="m6 2 4 4"/><path d="m3 10 7-7"/><path d="m14 21 7-7"/></svg> {routine.exercises.length} exercises</div>
                                            <div className="flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-green-400"><path d="M12 20.94c1.5 0 2.75 1.12 2.75 2.5s-1.25 2.5-2.75 2.5-2.75-1.12-2.75-2.5 1.25-2.5 2.75 2.5"/><path d="M12 2.06c-1.5 0-2.75-1.12-2.75-2.5S10.5.44 12 .44s2.75 1.12 2.75 2.5-1.25 2.5-2.75 2.5"/><path d="M12 10.12c2.75 0 5-1.12 5-2.5s-2.25-2.5-5-2.5-5 1.12-5 2.5 2.25 2.5 5 2.5"/><path d="M12 14.88c-2.75 0-5 1.12-5 2.5s2.25 2.5 5 2.5 5-1.12 5-2.5-2.25-2.5-5-2.5"/></svg> {routine.savesCount.toLocaleString()} saves</div>
                                        </div>
                                    </div>
                                    <div className="border-t border-gray-700 mt-4 pt-3 flex justify-between items-center text-sm text-gray-400">
                                        <div className="flex items-center space-x-4">
                                            <button onClick={(e) => { e.stopPropagation(); handleLikeWorkoutRoutine(routine.id); }} className={`flex items-center space-x-1 ${routine.isLiked ? 'text-red-400' : 'text-gray-400'}`}><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill={routine.isLiked ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg> <span>{routine.likes}</span></button>
                                            <button onClick={(e) => { e.stopPropagation(); openModal(ModalType.Comments, { id: routine.id, author: routine.user.username, type: 'routine' }); }} className="flex items-center space-x-1 text-gray-400"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg> <span>{routine.comments.length}</span></button>
                                        </div>
                                        <button onClick={(e) => { e.stopPropagation(); setActiveMenu(activeMenu === routine.id ? null : routine.id); }} className="p-1.5 rounded-full hover:bg-gray-700"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg></button>
                                        {activeMenu === routine.id && (
                                            <div className="absolute top-12 right-4 w-48 bg-gray-800 rounded-lg shadow-xl border border-gray-700 z-10 text-sm">
                                                <button onClick={() => openModal(ModalType.SharePost, { mediaUrl: 'routine', author: routine.user.username })} className="w-full text-left px-3 py-2 text-gray-200 hover:bg-gray-700 rounded-t-lg">Share</button>
                                                <button onClick={() => handleCopyLink('routine', routine.id)} className="w-full text-left px-3 py-2 text-gray-200 hover:bg-gray-700 rounded-b-lg">Copy Link</button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                     ) : (
                         <div className="px-4">
                            <div className="text-center py-8 px-4 bg-gray-800/50 rounded-xl border border-white/5">
                                <span className="text-3xl block mb-2">📚</span>
                                <p className="text-gray-300 font-semibold">No routines shared yet.</p>
                                <p className="text-sm text-gray-400 mt-1">Be the first to share a workout routine!</p>
                            </div>
                        </div>
                     )}
                </section>
                
                <section className="px-4">
                    <h2 className="text-xl font-bold text-white mb-3">{t('explore.exploreMore')}</h2>
                    {exploreContent.length > 0 ? (
                        <div className="masonry-grid">
                            {exploreContent.map(item => {
                                const isReel = item.contentType === 'reel';
                                const mediaUrl = isReel ? (item as Reel).videoSrc : (item as Post).mediaUrl;
                                const mediaType = isReel ? 'video' : (item as Post).mediaType;

                                return (
                                    <div 
                                        key={`${item.contentType}-${item.id}`} 
                                        onClick={() => isReel ? onViewReelsFeed(exploreReels, item.id) : openModal(ModalType.PostDetail, item)}
                                        className="masonry-item group"
                                    >
                                        {mediaType === 'video' ? (
                                            <video src={mediaUrl} muted loop playsInline className="w-full h-full object-cover"/>
                                        ) : (
                                            <img src={mediaUrl} alt={item.caption} className="w-full h-full object-cover"/>
                                        )}
                                        <div className="masonry-item-overlay">
                                            <div className="flex items-center space-x-4 text-sm">
                                                <div className="flex items-center space-x-1.5">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="white" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                                                    <span>{item.likes.toLocaleString()}</span>
                                                </div>
                                                <div className="flex items-center space-x-1.5">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="white" stroke="none"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
                                                    <span>{item.comments.length.toLocaleString()}</span>
                                                </div>
                                            </div>
                                        </div>
                                        {isReel && (
                                            <div className="reel-icon-overlay">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.59a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                         <div className="text-center py-16 px-4 bg-gray-800/50 rounded-xl border border-white/5">
                            <span className="text-3xl block mb-2">🔭</span>
                            <p className="text-gray-300 font-semibold">{t('explore.empty.title')}</p>
                            <p className="text-sm text-gray-400 mt-1">{t('explore.empty.subtitle')}</p>
                        </div>
                    )}
                </section>
                
            </div>
        )
    }

    const ChallengesContent = () => {
        const [aiChallenge, setAiChallenge] = useState<Challenge | null>(null);
        const [isLoadingAi, setIsLoadingAi] = useState(false);
        const [errorAi, setErrorAi] = useState('');

        const aiUser: UserProfile = {
            username: 'AI Coach', email: '', avatarText: 'AI', avatarColor: '#10B981',
            avatarImage: 'https://placehold.co/100x100/10B981/FFFFFF?text=AI', posts: [],
            followers: 999, following: [], cvsScore: 9.9, somatotype: 'mesomorph'
        };

        const handleGenerateAiChallenge = async () => {
            setIsLoadingAi(true);
            setAiChallenge(null);
            setErrorAi('');
            try {
                const languageName = supportedLanguages[language]?.name || 'English';
                const result = await generateDailyChallenge(languageName);
                const newAiChallenge: Challenge = {
                    id: `ai-${new Date().toISOString().split('T')[0]}`,
                    title: result.title,
                    description: result.description,
                    goal: result.goal,
                    duration: 1,
                    creator: aiUser,
                    participants: [],
                    prizePool: 1000,
                    isAiChallenge: true,
                };
                setAiChallenge(newAiChallenge);
            } catch (e: any) {
                console.error(e);
                setErrorAi(e.message || 'Failed to generate AI challenge.');
            } finally {
                setIsLoadingAi(false);
            }
        };

        return (
            <div className="p-4 space-y-4">
                 <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold text-white">{t('explore.activeChallenges')}</h2>
                    <button onClick={() => openModal(ModalType.CreateChallenge)} className="bg-green-500/20 text-green-300 px-3 py-1.5 rounded-full text-sm font-semibold shadow-md hover:bg-green-500/40 transition-colors transform hover:scale-105">
                        Create
                    </button>
                </div>

                <div className="bg-gradient-to-br from-indigo-900 to-purple-900 border border-indigo-500 p-4 rounded-xl text-center">
                    <h3 className="text-lg font-bold text-white">Daily AI Challenge</h3>
                    <p className="text-xs text-indigo-300 mb-3">A new challenge every day, powered by Gemini.</p>
                    <button onClick={handleGenerateAiChallenge} disabled={isLoadingAi} className="w-full bg-white text-black font-bold py-2 rounded-lg hover:bg-gray-200 transition-colors disabled:bg-gray-400 flex items-center justify-center">
                        {isLoadingAi ? <div className="w-5 h-5 border-2 border-t-transparent border-black rounded-full animate-spin"></div> : "✨ Generate Today's Challenge"}
                    </button>
                </div>
                
                {errorAi && <p className="text-red-400 text-sm text-center">{errorAi}</p>}

                {(aiChallenge || challenges.length > 0) ? (
                    [...(aiChallenge ? [aiChallenge] : []), ...challenges].map(challenge => (
                        <div key={challenge.id} onClick={() => openModal(ModalType.ChallengeDetails, challenge)} className="bg-[#1E1E1E] p-4 rounded-xl shadow-lg cursor-pointer hover:bg-gray-700 transition-colors">
                            <h3 className="font-semibold text-green-400">{challenge.title}</h3>
                            <p className="text-xs text-gray-400 mt-1">{challenge.description}</p>
                            <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
                                <span onClick={(e) => {e.stopPropagation(); viewUserProfile(challenge.creator);}} className="cursor-pointer hover:text-white transition-colors">by @{challenge.creator.username}</span>
                                <span>{challenge.participants.length} participants</span>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="text-center text-gray-500 py-8">No challenges live right now. Create one!</p>
                )}
            </div>
        );
    };

    const LeaderboardContent = () => (
        <div className="p-4"><ProPlaceholder title={t('explore.leaderboard') as string} openModal={openModal} /></div>
    );
    
    const MarketplaceContent = () => {
        const [marketTab, setMarketTab] = useState<'nft' | 'gear'>('nft');

        const NftHero = () => (
            <div className="relative h-80 rounded-3xl overflow-hidden flex items-center justify-center p-8 mb-8 animate-fadeIn">
                <img src="https://i.imgur.com/uSti6SA.jpeg" alt="Digital Frontier" className="absolute inset-0 w-full h-full object-cover animate-float" />
                <div className="absolute inset-0 bg-black/70 backdrop-blur-sm"></div>
                <div className="relative z-10 text-center">
                    <h2 className="text-5xl font-black text-white leading-tight tracking-tighter" style={{ textShadow: '0 0 30px rgba(0, 255, 200, 0.5)' }}>Forge Your <br/>Digital Frontier</h2>
                    <p className="text-sm text-slate-300 mt-2 mb-6">Unleash exclusive assets.</p>
                    <button className="bg-white/10 backdrop-blur-md border border-white/20 text-white font-bold py-3 px-8 rounded-full hover:bg-white/20 transition-all">Browse Marketplace</button>
                </div>
            </div>
        );

        const TrendingCollectionCard: React.FC<{ nft: NFT }> = ({ nft }) => (
            <div className="snap-center w-40 flex-shrink-0 bg-[#151A23] rounded-2xl overflow-hidden shadow-lg border border-white/10 group cursor-pointer" onClick={() => openModal(ModalType.ProductDetail, nft)}>
                <img src={nft.imageUrl} className="w-full h-32 object-cover" />
                <div className="p-3">
                    <h4 className="text-sm font-bold text-white truncate">{nft.name}</h4>
                    <p className="text-xs text-slate-400 truncate mt-1">{nft.collection}</p>
                    <div className="flex justify-between items-center mt-3">
                        <span className="text-xs font-bold text-cyan-400">{nft.price} ETH</span>
                         <span className="text-[10px] bg-slate-700 px-2 py-0.5 rounded text-white/70">SCORE</span>
                    </div>
                </div>
            </div>
        );

        const LiveNftCard: React.FC<{ nft: NFT }> = ({ nft }) => (
            <div className="bg-[#151A23] rounded-2xl overflow-hidden shadow-lg border border-white/10 group cursor-pointer" onClick={() => openModal(ModalType.ProductDetail, nft)}>
                <img src={nft.imageUrl} className="w-full h-40 object-cover" />
                <div className="p-3">
                    <h4 className="text-sm font-bold text-white truncate">{nft.name}</h4>
                    <p className="text-xs text-slate-400 truncate mt-1">by @{nft.owner.username}</p>
                    <div className="flex justify-between items-center mt-3">
                        <span className="text-sm font-bold text-white">{nft.price} ETH</span>
                        <span className="text-xs bg-cyan-900/50 text-cyan-400 px-2 py-1 rounded-md border border-cyan-500/30">SCORE</span>
                    </div>
                </div>
            </div>
        );

        const GearCard: React.FC<{ item: typeof initialGearItems[0] }> = ({ item }) => (
             <div onClick={() => openModal(ModalType.ProductDetail, item)} className="bg-[#1E1E1E] rounded-xl overflow-hidden shadow-lg border border-white/10 group cursor-pointer hover:border-orange-500/50 transition-all">
                <div className="relative aspect-square">
                    <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <span className={`absolute top-2 right-2 text-[9px] font-bold px-2 py-1 rounded text-black ${item.condition === 'New' ? 'bg-green-400' : 'bg-yellow-400'}`}>
                        {item.condition}
                    </span>
                </div>
                <div className="p-3">
                    <p className="text-[9px] text-orange-400 font-bold uppercase tracking-wider mb-1">{item.category}</p>
                    <h4 className="font-bold text-white text-sm truncate mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-400 truncate mb-2">by {item.seller.username}</p>
                    <div className="flex justify-between items-center border-t border-white/10 pt-2">
                        <span className="font-black text-white">{item.currency}{item.price}</span>
                        <span className="bg-white text-black text-[10px] font-bold px-3 py-1.5 rounded-lg hover:bg-gray-200 transition-colors">
                            Buy
                        </span>
                    </div>
                </div>
            </div>
        );

        return (
            <div className="p-4 space-y-4 min-h-[60vh]">
                <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold text-white">{t('explore.marketplace')}</h2>
                    <button onClick={() => openModal(ModalType.CreateListing)} className="bg-blue-600 text-white text-xs font-bold px-4 py-2 rounded-lg shadow-lg hover:bg-blue-500 transition-all transform hover:scale-105 flex items-center gap-2">
                        <span>+ List Item</span>
                    </button>
                </div>
                
                <div className="flex p-1 bg-[#151A23] rounded-xl border border-white/10">
                    <button 
                        onClick={() => setMarketTab('nft')} 
                        className={`flex-1 py-2 rounded-lg text-sm font-bold transition-colors ${marketTab === 'nft' ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                        NFTs (Digital)
                    </button>
                    <button 
                        onClick={() => setMarketTab('gear')} 
                        className={`flex-1 py-2 rounded-lg text-sm font-bold transition-colors ${marketTab === 'gear' ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                        Gear & Supps (Physical)
                    </button>
                </div>

                {marketTab === 'nft' ? (
                    <div className="space-y-8 animate-fadeIn">
                        <NftHero />
                        
                        <section>
                            <h3 className="text-2xl font-bold text-white mb-4">Trending Collections</h3>
                            <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide snap-x">
                                {nfts.slice(0, 6).map(nft => <TrendingCollectionCard key={nft.id} nft={nft} />)}
                            </div>
                        </section>

                        <section>
                             <h3 className="text-2xl font-bold text-white mb-4">Live Listings</h3>
                             <div className="grid grid-cols-2 gap-4">
                                {nfts.slice(6).map(nft => <LiveNftCard key={nft.id} nft={nft} />)}
                             </div>
                        </section>
                    </div>
                ) : (
                    <div className="grid grid-cols-2 gap-4 animate-fadeIn">
                        {initialGearItems.map((item) => <GearCard key={item.id} item={item} /> )}
                    </div>
                )}
            </div>
        );
    };

    const GroupsContent = () => (
         <div className="p-4 space-y-6 pb-24">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <span className="text-2xl">🛡️</span> {t('explore.groups')}
                </h2>
                <button onClick={() => openModal(ModalType.CreateGroup)} className="bg-gradient-to-r from-green-600 to-emerald-600 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-lg shadow-green-900/20 hover:shadow-green-900/40 hover:scale-105 transition-all flex items-center gap-2">
                    <span>+</span> {t('groups.create')}
                </button>
            </div>

            {groups.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center opacity-80 bg-gray-900/30 rounded-3xl border-2 border-dashed border-gray-800">
                    <div className="w-24 h-24 bg-gradient-to-br from-gray-800 to-black rounded-full flex items-center justify-center mb-4 border border-gray-700 shadow-2xl">
                        <span className="text-5xl">👑</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">No Tribes Yet</h3>
                    <p className="text-sm text-gray-400 max-w-xs mb-6 leading-relaxed">
                        You haven't joined any tribes. Create your own community or wait for recommendations to appear here.
                    </p>
                    <button 
                        onClick={() => openModal(ModalType.CreateGroup)}
                        className="bg-white text-black font-black py-3 px-8 rounded-xl shadow-xl hover:bg-gray-200 transition-all transform hover:scale-105"
                    >
                        Start Your Legacy
                    </button>
                </div>
            ) : (
                <div className="grid grid-cols-2 gap-3 md:gap-5">
                    {groups.map(group => {
                        const isMember = group.members.some(m => m.username === currentUser.username);
                        return (
                            <div 
                                key={group.id} 
                                className="group relative flex flex-col aspect-[4/5] rounded-2xl overflow-hidden cursor-pointer shadow-lg hover:shadow-emerald-900/20 transition-all duration-300 hover:scale-[1.02] border border-white/5" 
                                onClick={() => handleOpenGroup(group)}
                            >
                                {/* Top Image Section (60%) */}
                                <div className="h-[60%] w-full relative bg-gray-900 overflow-hidden">
                                    {group.coverImage ? (
                                        <img 
                                            src={group.coverImage} 
                                            alt={group.name} 
                                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                                        />
                                    ) : (
                                        <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                                            <span className="text-2xl opacity-20">🛡️</span>
                                        </div>
                                    )}
                                    
                                    {/* Gradient Overlay */}
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60"></div>
                                    
                                    {/* Status Badge (Compact) */}
                                    <div className="absolute top-2 right-2 flex gap-1">
                                        {isMember && (
                                            <span className="bg-emerald-500/90 backdrop-blur-md text-white text-[8px] font-bold px-1.5 py-0.5 rounded flex items-center">
                                                ✓
                                            </span>
                                        )}
                                    </div>
                                </div>

                                {/* Bottom Info Section (40%) - Using Theme */}
                                <div 
                                    className="h-[40%] w-full p-3 relative flex flex-col justify-between"
                                    style={{ background: group.theme.gradient }}
                                >
                                    {/* Noise Texture */}
                                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay pointer-events-none"></div>
                                    
                                    <div className="relative z-10">
                                        <div className="flex items-center gap-2 mb-1">
                                            <div className="w-6 h-6 rounded-full bg-white/20 backdrop-blur-md flex-shrink-0 flex items-center justify-center text-[10px] font-bold text-white border border-white/20 shadow-inner">
                                                {group.name.charAt(0).toUpperCase()}
                                            </div>
                                            <h3 className="font-bold text-white text-sm leading-tight shadow-black drop-shadow-md line-clamp-1">{group.name}</h3>
                                        </div>
                                        
                                        <p className="text-[10px] text-white/80 font-medium italic line-clamp-2 leading-snug">"{group.motto}"</p>
                                    </div>

                                    <div className="relative z-10 flex items-center justify-between mt-2">
                                        <div className="flex items-center gap-1">
                                            <span className="text-[8px] font-bold bg-black/20 px-1.5 py-0.5 rounded text-white/90 border border-white/5 backdrop-blur-sm">
                                                {group.memberCount} 👥
                                            </span>
                                        </div>
                                        {group.isPrivate && (
                                            <span className="text-[10px] opacity-70">🔒</span>
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );

    const SignalContent = () => (
        <div className="p-4 grid grid-cols-2 gap-4">
            <div onClick={() => openModal(ModalType.NeuralLink)} className="bg-gradient-to-br from-gray-800 to-gray-900 border border-green-500/30 p-4 rounded-xl text-center shadow-lg hover:border-green-500 cursor-pointer"><span className="text-3xl">🧠</span><p className="text-sm font-bold text-green-400 mt-2">Neural Link</p></div>
            <div onClick={() => openModal(ModalType.QuantumHrv)} className="bg-gradient-to-br from-gray-800 to-gray-900 border border-blue-500/30 p-4 rounded-xl text-center shadow-lg hover:border-blue-500 cursor-pointer"><span className="text-3xl">💙</span><p className="text-sm font-bold text-blue-400 mt-2">Quantum HRV</p></div>
            <div onClick={() => openModal(ModalType.BodyMap)} className="bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-500/30 p-4 rounded-xl text-center shadow-lg hover:border-yellow-500 cursor-pointer col-span-2"><span className="text-3xl">🔥</span><p className="text-sm font-bold text-yellow-400 mt-2">3D Body Map</p></div>
        </div>
    );

    // NEW AI Kitchen Content Component
    const AiKitchenContent = () => {
        const [activeKitchenTab, setActiveKitchenTab] = useState<'pantry' | 'meal_plan'>('pantry');
        const [ingredients, setIngredients] = useState('');
        const [isLoading, setIsLoading] = useState(false);
        const [result, setResult] = useState<AiRecipeResponse | null>(null);
        const [error, setError] = useState<string | null>(null);
        const [shoppingList, setShoppingList] = useState<string[]>([]);
        const [loggedMealIndices, setLoggedMealIndices] = useState<Set<number>>(new Set());
        
        // Date Navigation State
        const [viewDate, setViewDate] = useState(new Date().toISOString().split('T')[0]);

        const handleDateChange = (direction: 'prev' | 'next') => {
            const date = new Date(viewDate);
            date.setDate(date.getDate() + (direction === 'prev' ? -1 : 1));
            setViewDate(date.toISOString().split('T')[0]);
        };

        // Derived State for specific date
        const dateMacros = useMemo(() => {
            const record = nutritionHistory.find(h => h.date === viewDate);
            return record?.macros || { cal: 0, pro: 0, carb: 0, fat: 0 };
        }, [nutritionHistory, viewDate]);

        const dateMeals = useMemo(() => {
             return foodLog ? foodLog.filter(log => log.date === viewDate).reverse() : [];
        }, [foodLog, viewDate]);

        const handleGenerate = async () => {
            if (activeKitchenTab === 'pantry' && !ingredients.trim()) {
                setError("Please enter some ingredients.");
                return;
            }
    
            setIsLoading(true);
            setError(null);
            setResult(null);
            setShoppingList([]);
            setLoggedMealIndices(new Set());
    
            try {
                const languageName = supportedLanguages[language]?.name || 'English';
                const ingredientList = ingredients.split(',').map(i => i.trim()).filter(Boolean);
                
                // Filter food log for TODAY
                const todayLogs = foodLog ? foodLog.filter(l => l.date === new Date().toISOString().split('T')[0]) : [];
                
                // Filter food log for YESTERDAY (for variety logic)
                const d = new Date();
                d.setDate(d.getDate() - 1);
                const yesterdayDate = d.toISOString().split('T')[0];
                const yesterdayLogs = foodLog ? foodLog.filter(l => l.date === yesterdayDate) : [];

                const response = await generateAiKitchenPlan(
                    activeKitchenTab, 
                    userProfileData, 
                    ingredientList, 
                    languageName,
                    todayLogs,
                    yesterdayLogs
                );
                setResult(response);
    
                // Generate Shopping List
                let list: string[] = [];
                if (activeKitchenTab === 'pantry' && response.meals?.[0]?.missingIngredients) {
                    list = response.meals[0].missingIngredients;
                } else if (activeKitchenTab === 'meal_plan' && response.meals) {
                    // Safe access with optional chaining and default empty array
                    list = [...new Set(response.meals.flatMap(m => m.ingredients || []))];
                }
                setShoppingList(list);

            } catch (err: any) {
                setError(err.message || "Failed to generate plan.");
            } finally {
                setIsLoading(false);
            }
        };

        const handleLogMeal = (meal: any, index: number) => {
            if (loggedMealIndices.has(index)) return; // Prevent double logging
            onAddMeal(meal.macros, viewDate, `${meal.name}`, meal.type);
            setLoggedMealIndices(prev => new Set(prev).add(index));
        };

        const safeMacros = dateMacros || { cal: 0, pro: 0, carb: 0, fat: 0 };
        const safeGoals = nutritionGoals || { cal: 2000, pro: 150, carb: 200, fat: 70 };
        const isToday = viewDate === new Date().toISOString().split('T')[0];

        return (
            <div className="p-4 pb-20">
                {/* Tracker Dashboard Header */}
                <div 
                    onClick={() => openModal(ModalType.DailyNutritionDetail, { date: viewDate })} 
                    className="mb-6 bg-gradient-to-r from-gray-900 to-gray-800 p-4 rounded-2xl border border-green-500/20 shadow-lg cursor-pointer hover:border-green-500/50 transition-colors group"
                >
                    <div className="flex justify-between items-center mb-2">
                         <div className="flex items-center gap-2 pointer-events-auto" onClick={(e) => e.stopPropagation()}>
                             <button onClick={() => handleDateChange('prev')} className="text-gray-400 hover:text-white"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button>
                             <h3 className="text-sm font-bold text-gray-300 uppercase group-hover:text-white transition-colors">{isToday ? "Today's Nutrition" : `Nutrition: ${viewDate}`}</h3>
                             <button onClick={() => handleDateChange('next')} disabled={isToday} className={`text-gray-400 hover:text-white ${isToday ? 'opacity-30 cursor-not-allowed' : ''}`}><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg></button>
                         </div>
                         <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500 group-hover:text-green-400"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
                    </div>
                    <div className="flex items-end justify-between mb-2">
                        <div>
                            <span className="text-3xl font-extrabold text-white">{(safeMacros.cal || 0).toFixed(0)}</span>
                            <span className="text-xs text-gray-500 ml-1">/ {safeGoals.cal} kcal</span>
                        </div>
                         <div className="text-right">
                             <span className="text-xs text-gray-400 block">Protein: <b className="text-blue-400">{(safeMacros.pro || 0).toFixed(0)}g</b></span>
                             <span className="text-xs text-gray-400 block">Carbs: <b className="text-orange-400">{(safeMacros.carb || 0).toFixed(0)}g</b></span>
                             <span className="text-xs text-gray-400 block">Fat: <b className="text-yellow-400">{(safeMacros.fat || 0).toFixed(0)}g</b></span>
                         </div>
                    </div>
                     <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full transition-all duration-500" style={{ width: `${Math.min(((safeMacros.cal || 0) / safeGoals.cal) * 100, 100)}%` }}></div>
                    </div>
                </div>
                
                {/* Nutrition History List */}
                <div className="mb-6 bg-gray-800/50 p-4 rounded-xl border border-gray-700">
                     <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                        <span>🍽️</span> {isToday ? "Today's Meals" : `Meals: ${viewDate}`}
                     </h3>
                     {dateMeals.length > 0 ? (
                         <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                            {dateMeals.map((log) => (
                                <div key={log.id} className="flex justify-between items-center text-xs bg-gray-900 p-3 rounded-lg">
                                    <span className="text-gray-300 font-medium">{log.name}</span>
                                    <span className="font-bold text-green-400">{log.calories.toFixed(0)} kcal</span>
                                </div>
                            ))}
                         </div>
                     ) : (
                        <p className="text-xs text-gray-500 text-center py-4">No meals logged for this day.</p>
                     )}
                </div>

                <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                    <span>🍳</span> AI Smart Kitchen
                </h2>

                <div className="flex p-1 bg-gray-800 rounded-xl font-semibold mb-6">
                    <button onClick={() => { setActiveKitchenTab('pantry'); setResult(null); }} className={`w-1/2 py-3 rounded-lg transition-colors text-sm ${activeKitchenTab === 'pantry' ? 'bg-orange-500 text-white' : 'text-gray-400'}`}>
                        Pantry Chef
                    </button>
                    <button onClick={() => { setActiveKitchenTab('meal_plan'); setResult(null); }} className={`w-1/2 py-3 rounded-lg transition-colors text-sm ${activeKitchenTab === 'meal_plan' ? 'bg-green-500 text-white' : 'text-gray-400'}`}>
                        Daily Meal Plan
                    </button>
                </div>

                {!result && (
                    <div className="space-y-6 animate-fadeIn">
                        {activeKitchenTab === 'pantry' ? (
                            <>
                                <div>
                                    <label className="text-sm text-gray-300 block mb-2 font-bold">What's in your kitchen?</label>
                                    <textarea 
                                        value={ingredients}
                                        onChange={e => setIngredients(e.target.value)}
                                        rows={4}
                                        placeholder="e.g., eggs, spinach, chicken breast, rice, avocado"
                                        className="w-full p-4 bg-gray-800 text-white rounded-xl border border-gray-700 focus:border-orange-500 transition-all"
                                    />
                                </div>
                            </>
                        ) : (
                            <div className="bg-gray-800 p-6 rounded-xl border border-green-500/30 text-center">
                                <p className="text-gray-200 text-base mb-4">Generating a complete daily meal plan tailored to your body type and goals:</p>
                                <div className="flex flex-wrap justify-center gap-3">
                                    <span className="bg-gray-700 text-green-400 px-3 py-1 rounded-full text-xs font-bold uppercase">{userProfileData.somatotype}</span>
                                    <span className="bg-gray-700 text-green-400 px-3 py-1 rounded-full text-xs font-bold uppercase">{userProfileData.fatDistribution} Shape</span>
                                    <span className="bg-gray-700 text-green-400 px-3 py-1 rounded-full text-xs font-bold uppercase">{userProfileData.targetWeight < userProfileData.weight ? 'Weight Loss' : 'Muscle Gain'}</span>
                                </div>
                            </div>
                        )}
                        
                        <button 
                            onClick={handleGenerate} 
                            disabled={isLoading}
                            className={`w-full py-4 rounded-xl font-bold shadow-lg transition-transform hover:scale-105 disabled:opacity-50 disabled:transform-none text-white text-lg ${activeKitchenTab === 'pantry' ? 'bg-orange-500 hover:bg-orange-600' : 'bg-green-500 hover:bg-green-600'}`}
                        >
                            {isLoading ? "Cooking up magic..." : (activeKitchenTab === 'pantry' ? "Create Recipe" : "Generate Meal Plan")}
                        </button>
                        {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                    </div>
                )}

                {result && (
                    <div className="space-y-6 animate-fadeIn">
                        <div className="text-center mb-6">
                            <h3 className="text-2xl font-bold text-white mb-2">{result.planName}</h3>
                            <p className="text-sm text-gray-400 italic px-2 bg-gray-800/50 p-2 rounded-lg inline-block">{result.aiAnalysis}</p>
                        </div>
                        
                        {/* Shopping List (Market Listesi) */}
                        {shoppingList.length > 0 && (
                            <div className="bg-yellow-100 text-gray-800 p-6 rounded-xl shadow-lg transform rotate-1 border-t-8 border-yellow-300 relative mb-6">
                                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-20 h-6 bg-yellow-300/50 blur-sm rounded-full"></div>
                                <h4 className="font-extrabold text-xl mb-4 flex items-center gap-2 border-b border-gray-300 pb-2">
                                    🛒 Shopping List <span className="text-xs font-normal bg-yellow-300 px-2 py-1 rounded-md">({shoppingList.length})</span>
                                </h4>
                                <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto pr-2">
                                    {shoppingList.map((item, i) => (
                                        <label key={`${item}-${i}`} className="flex items-center text-sm font-medium cursor-pointer hover:bg-yellow-200/50 p-2 rounded transition-colors">
                                            <input type="checkbox" className="mr-3 accent-black w-5 h-5 rounded border-gray-400" />
                                            <span className="decoration-gray-400 peer-checked:line-through peer-checked:opacity-50">{item}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        )}

                        {result.meals?.map((meal, idx) => (
                            <div key={idx} className="bg-[#1E1E1E] rounded-xl overflow-hidden border border-gray-700 shadow-lg">
                                <div className="bg-gray-800 p-4 flex justify-between items-center">
                                    <span className="font-bold text-white text-lg">{meal.type}: {meal.name}</span>
                                    <button 
                                        onClick={() => handleLogMeal(meal, idx)} 
                                        disabled={loggedMealIndices.has(idx)}
                                        className={`text-xs font-bold px-3 py-1.5 rounded-full transition-colors flex items-center gap-1 shadow-md transform ${loggedMealIndices.has(idx) ? 'bg-gray-600 text-gray-300 cursor-default' : 'bg-green-600 hover:bg-green-500 text-white hover:scale-105'}`}
                                    >
                                        {loggedMealIndices.has(idx) ? (
                                            <>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                                                Logged ✓
                                            </>
                                        ) : (
                                            <>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" x2="12" y1="5" y2="19"/><line x1="5" x2="19" y1="12" y2="12"/></svg>
                                                Log Meal
                                            </>
                                        )}
                                    </button>
                                </div>
                                <div className="p-4 space-y-4">
                                    <div className="grid grid-cols-4 gap-2 text-center text-xs bg-black/30 p-3 rounded-lg">
                                        <div><span className="block text-gray-400 mb-1">Cal</span><span className="font-bold text-white text-sm">{meal.macros.calories}</span></div>
                                        <div><span className="block text-gray-400 mb-1">Pro</span><span className="font-bold text-blue-400 text-sm">{meal.macros.protein}g</span></div>
                                        <div><span className="block text-gray-400 mb-1">Carb</span><span className="font-bold text-orange-400 text-sm">{meal.macros.carbs}g</span></div>
                                        <div><span className="block text-gray-400 mb-1">Fat</span><span className="font-bold text-yellow-400 text-sm">{meal.macros.fat}g</span></div>
                                    </div>
                                    
                                    {/* Extended Macros Section */}
                                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-[10px] bg-black/20 p-2 rounded-lg border border-white/5">
                                        <div><span className="block text-gray-500">Sodium</span><span className="font-bold text-gray-300">{meal.macros.sodium || 0}mg</span></div>
                                        <div><span className="block text-gray-500">Sugar</span><span className="font-bold text-gray-300">{meal.macros.sugar || 0}g</span></div>
                                        <div><span className="block text-gray-500">Fiber</span><span className="font-bold text-gray-300">{meal.macros.fiber || 0}g</span></div>
                                        <div><span className="block text-gray-500">Sat. Fat</span><span className="font-bold text-gray-300">{meal.macros.saturatedFat || 0}g</span></div>
                                    </div>

                                    <div className="text-xs text-gray-400 text-center">Micro-boost: <span className="text-green-400 font-semibold">{meal.macros.vitamins}</span></div>
                                    
                                    <div>
                                        <h4 className="text-xs font-bold text-gray-300 uppercase mb-2">Ingredients</h4>
                                        <ul className="space-y-2">
                                            {meal.ingredients?.map((ing, i) => (
                                                <li key={i} className="flex items-center text-sm text-gray-300 bg-gray-800/50 p-2 rounded-md">
                                                    <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-3"></div>
                                                    {ing}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    
                                    {meal.instructions && (
                                        <div>
                                            <h4 className="text-xs font-bold text-gray-300 uppercase mb-2">Instructions</h4>
                                            <ol className="list-decimal list-inside text-sm text-gray-400 space-y-2">
                                                {meal.instructions.map((step, i) => <li key={i} className="leading-relaxed">{step}</li>)}
                                            </ol>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}

                        <button onClick={() => setResult(null)} className="w-full bg-gray-700 text-white font-bold py-4 rounded-xl hover:bg-gray-600 transition-colors mt-8">
                            Start Over
                        </button>
                    </div>
                )}
            </div>
        );
    };

    const TabButton: React.FC<{ tabId: ExploreTab; label: string }> = ({ tabId, label }) => (
        <button
            onClick={() => setActiveTab(tabId)}
            className={`px-5 py-2 rounded-full text-sm font-bold transition-all duration-300 whitespace-nowrap shadow-md transform hover:scale-105 ${
                activeTab === tabId 
                ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white ring-2 ring-green-300/30' 
                : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
            }`}
        >
            {label}
        </button>
    );

    const renderTabContent = () => {
        switch (activeTab) {
            case 'discoverMore': return <DiscoverMoreContent />;
            case 'challenges': return <ChallengesContent />;
            case 'leaderboard': return <LeaderboardContent />;
            case 'marketplace': return <MarketplaceContent />;
            case 'groups': return <GroupsContent />;
            case 'signal': return <SignalContent />;
            case 'aiKitchen': return <AiKitchenContent />;
            default: return null;
        }
    };

    return (
        <div className="flex flex-col h-full w-full">
            {/* Header / Search */}
            <header className="sticky top-0 z-20 bg-gray-900/80 backdrop-blur-sm p-4">
                <div className="relative">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                    <input 
                        type="search"
                        value={searchQuery}
                        onChange={handleSearchChange}
                        placeholder={t('explore.searchPlaceholder') as string}
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#1E1E1E] border-transparent text-white focus:bg-[#333] focus:ring-2 focus:ring-green-500 placeholder-gray-500 transition-colors" 
                    />
                </div>
            </header>

            {isSearching ? (
                <SearchResultsComponent />
            ) : (
                <div className="flex-1 overflow-y-auto">
                    {/* Tabs */}
                    <div className="sticky top-0 z-10 bg-gray-900/95 backdrop-blur-md py-3 shadow-lg">
                        <div className="flex space-x-3 overflow-x-auto px-4 pb-1 scrollbar-hide">
                             <TabButton tabId="discoverMore" label={t('explore.tabs.discoverMore') as string} />
                             <TabButton tabId="challenges" label={t('explore.tabs.challenges') as string} />
                             <TabButton tabId="leaderboard" label={t('explore.tabs.leaderboard') as string} />
                             <TabButton tabId="marketplace" label={t('explore.tabs.marketplace') as string} />
                             <TabButton tabId="groups" label={t('explore.tabs.groups') as string} />
                             <TabButton tabId="signal" label={t('explore.tabs.signal') as string} />
                             <TabButton tabId="aiKitchen" label={t('explore.tabs.aiKitchen') as string} />
                        </div>
                    </div>
                    <div key={activeTab} className="animate-fadeIn">
                        {renderTabContent()}
                    </div>
                </div>
            )}
        </div>
    );
};

export default ExplorePage;