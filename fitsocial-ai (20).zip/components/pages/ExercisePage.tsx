import React, { useState } from 'react';
import { ModalType } from '../../types';
import { useTranslation } from '../../hooks/i18n';

interface ExercisePageProps {
    openModal: (modal: ModalType, data?: any) => void;
    isProUser: boolean;
}

type ExerciseTab = 'programs' | 'routines' | 'live';

const ProPlaceholder: React.FC<{ title: string; openModal: (modal: ModalType) => void; }> = ({ title, openModal }) => {
    const { t } = useTranslation();
    return (
        <div className="h-48 flex flex-col items-center justify-center bg-[#121212]/80 rounded-xl shadow-inner border border-gray-800 backdrop-blur-sm">
            <span className="text-4xl animate-pulse">⭐️</span>
            <p className="text-md font-bold text-yellow-400 mt-3 text-center">{t('explore.proFeature', { title })}</p>
            <button onClick={() => openModal(ModalType.PremiumPitch)} className="bg-yellow-500 text-black text-sm font-bold py-2 px-4 rounded-xl mt-4 shadow-md hover:bg-yellow-400 transition-colors transform hover:scale-105">{t('explore.goPro')}</button>
        </div>
    );
};

const ExercisePage: React.FC<ExercisePageProps> = ({ openModal, isProUser }) => {
    const { t } = useTranslation();
    const [activeTab, setActiveTab] = useState<ExerciseTab>('routines');

    const renderTabContent = () => {
        switch (activeTab) {
            case 'programs':
                const programs = [
                    { title: "Beginner At-Home Program (4 Weeks)", description: "A 4-week program designed for beginners with no equipment needed." },
                    { title: "Gym Strength Program (5x5)", description: "Classic 5x5 strength building program for intermediate lifters." }
                ];
                return (
                    <div className="p-4 space-y-4">
                        <h2 className="text-xl font-bold text-white">{t('exercise.readyPrograms')} <span className="text-xs bg-yellow-500 text-black font-bold px-2 py-0.5 rounded-md align-middle">{t('common.pro')}</span></h2>
                        {isProUser ? (
                             <div className="space-y-4">
                                {programs.map(p => (
                                    <div key={p.title} onClick={() => openModal(ModalType.ProgramDetails, p)} className="bg-[#1E1E1E] p-4 rounded-xl shadow-lg cursor-pointer hover:bg-gray-700 transition-colors transform hover:-translate-y-1 border border-gray-800"><h3 className="font-semibold text-green-400">{p.title}</h3></div>
                                ))}
                             </div>
                        ) : <ProPlaceholder title={t('exercise.readyPrograms') as string} openModal={openModal} />}
                    </div>
                );
            case 'routines':
                const routine = { title: "Monday: Chest & Triceps", description: "Bench Press, Dumbbell Fly, Dips... (45 mins)", exercises: ["Bench Press: 3x5", "Dumbbell Fly: 3x10", "Triceps Dips: 3x12"] };
                return (
                    <div className="p-4 space-y-4 pb-24">
                        <div className="flex justify-between items-center">
                            <h2 className="text-xl font-bold text-white">{t('exercise.myRoutines')}</h2>
                            <button onClick={() => openModal(ModalType.CreateRoutine)} className="bg-green-500/20 text-green-400 border border-green-500 px-4 py-1.5 rounded-xl text-sm font-semibold shadow hover:bg-green-500/30 transition-colors transform hover:scale-105">{t('exercise.newRoutine')}</button>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <button onClick={() => openModal(ModalType.ReactionTest)} className="bg-gradient-to-br from-indigo-900 to-blue-900 text-white py-6 rounded-2xl font-bold text-sm flex flex-col items-center justify-center gap-2 shadow-lg border border-indigo-500/30 hover:border-indigo-500 transition-all">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                                <span>{t('exercise.reactionTest')}</span>
                            </button>
                             <button onClick={() => openModal(ModalType.AiWorkoutGenerator)} className="bg-gradient-to-br from-teal-900 to-emerald-900 text-white py-6 rounded-2xl font-bold text-sm flex flex-col items-center justify-center gap-2 shadow-lg border border-teal-500/30 hover:border-teal-500 transition-all">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>
                                <span>{t('exercise.aiWorkout')}</span>
                            </button>
                            <button onClick={() => openModal(ModalType.AdaptiveWorkout)} className="bg-gradient-to-br from-purple-900 to-fuchsia-900 text-white py-6 rounded-2xl font-bold text-sm flex flex-col items-center justify-center gap-2 shadow-lg border border-purple-500/30 hover:border-purple-500 transition-all">
                                 <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M7 7h3v3H7z"/><path d="M14 7h3v3h-3z"/><path d="M7 14h3v3H7z"/><path d="M14 14h3v3h-3z"/><path d="M10 21v-3"/><path d="M14 21v-3"/><path d="M10 3v3"/><path d="M14 3v3"/><path d="M3 10h3"/><path d="M3 14h3"/><path d="M21 10h-3"/><path d="M21 14h-3"/></svg>
                                <span>{t('exercise.adaptiveWorkout')}</span>
                            </button>
                             <button onClick={() => openModal(ModalType.WorkoutVideoGeneration)} className="bg-gradient-to-br from-red-900 to-orange-900 text-white py-6 rounded-2xl font-bold text-sm flex flex-col items-center justify-center gap-2 shadow-lg border border-red-500/30 hover:border-red-500 transition-all">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.2 6 3 11l-.9-2.4c-.3-1.1.4-2.2 1.5-2.5l13-3.2c-1.1-.3-2.2.4-2.5 1.5L20.2 6Z"/><path d="m7 11 13 4.8.9 2.4c.3 1.1-.4 2.2-1.5 2.5l-13 3.2c-1.1.3-2.2-.4-2.5-1.5L3 11Z"/><path d="m11 7-5.4 1.3"/><path d="m11.6 15.8-1.3-5.4"/><path d="m5.4 12.7 1.3 5.4"/></svg>
                                <span>{t('exercise.videoGeneration')}</span>
                            </button>
                        </div>
                        
                        <div onClick={() => openModal(ModalType.RoutineDetails, routine)} className="bg-[#18181b] p-5 rounded-2xl shadow-xl border border-gray-800 hover:border-gray-700 transition-all duration-300 cursor-pointer transform hover:-translate-y-1 mt-6">
                            <div className="flex justify-between items-start mb-2">
                                <div>
                                    <h3 className="font-bold text-white text-lg">{routine.title}</h3>
                                    <p className="text-sm text-gray-400 mt-1">{routine.description}</p>
                                </div>
                                <div className="bg-gray-800 p-2 rounded-lg">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400"><path d="M9 18l6-6-6-6"/></svg>
                                </div>
                            </div>
                            <button onClick={(e) => { e.stopPropagation(); openModal(ModalType.WorkoutMode); }} className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold mt-4 shadow-lg shadow-blue-900/30 hover:bg-blue-500 transition-colors transform active:scale-95">{t('exercise.startWorkout')}</button>
                        </div>
                    </div>
                );
            case 'live':
                return (
                     <div className="p-4 space-y-4">
                        <h2 className="text-xl font-bold text-white">{t('exercise.liveClasses')} <span className="text-xs bg-yellow-500 text-black font-bold px-2 py-0.5 rounded-md align-middle">{t('common.pro')}</span></h2>
                        {isProUser ? (
                             <div className="space-y-4">
                                <div className="bg-[#1E1E1E] p-4 rounded-xl shadow-lg flex justify-between items-center hover:bg-gray-700 transition-colors transform hover:-translate-y-1 cursor-pointer border border-gray-800">
                                    <div>
                                        <span className="text-sm font-semibold text-green-400">18:00 - 18:45</span>
                                        <h3 className="font-bold text-white mt-1 text-lg">Live Yoga Flow</h3>
                                    </div>
                                    <button onClick={() => openModal(ModalType.MetaGym)} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg shadow-indigo-900/30 hover:bg-indigo-500 transition-colors transform hover:scale-105 flex items-center space-x-1">
                                      <span>🥽</span><span>Join Meta-Gym</span>
                                    </button>
                                </div>
                             </div>
                        ) : <ProPlaceholder title={t('exercise.liveClasses') as string} openModal={openModal} />}
                    </div>
                );
        }
    };

    const TabButton: React.FC<{ tabId: ExerciseTab; label: string; pro?: boolean }> = ({ tabId, label, pro }) => (
        <button
            className={`flex-1 py-2.5 rounded-xl transition-all text-sm font-bold relative overflow-hidden ${activeTab === tabId ? 'bg-[#27272a] text-white shadow-inner ring-1 ring-white/10' : 'text-gray-400 hover:text-gray-200'}`}
            onClick={() => setActiveTab(tabId)}
        >
            {label} {pro && <span className="text-yellow-500 text-[10px] align-top ml-0.5">PRO</span>}
        </button>
    );

    return (
        <div className="flex flex-col">
            <div className="sticky top-0 z-30 bg-[#0a0a0a]/90 backdrop-blur-md py-3 border-b border-white/5">
                <div className="flex p-1 bg-[#18181b] rounded-xl mx-4 shadow-inner border border-white/5">
                    <TabButton tabId="programs" label={t('exercise.tabs.programs') as string} pro />
                    <TabButton tabId="routines" label={t('exercise.tabs.routines') as string} />
                    <TabButton tabId="live" label={t('exercise.tabs.live') as string} pro />
                </div>
            </div>
            <div key={activeTab} className="animate-fadeIn">
                {renderTabContent()}
            </div>
        </div>
    );
};

export default ExercisePage;