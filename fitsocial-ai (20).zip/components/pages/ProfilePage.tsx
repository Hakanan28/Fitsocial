import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { ModalType, UserProfile, Coin, NFT, ProfileTab, ActivityRecord, StoryHighlight, Post, Reel, ProofOfWorkoutPost, WorkoutRoutine, BadgeNFT, BadgeCategory, BadgeRarity, DetailedUserProfileData } from '../../types';
import type { Chart, ChartConfiguration } from 'chart.js';
import { analyzeUserPosts, generateActivitySummary, generateNutritionSummary } from '../../services/geminiService';
import WalletPage from './WalletPage';
import { useTranslation, supportedLanguages } from '../../hooks/i18n';

interface ProfilePageProps {
    openModal: (modal: ModalType, data?: any) => void;
    isProUser?: boolean;
    fitTokenBalance: number;
    userProfileData: DetailedUserProfileData;
    nutritionHistory: { date: string, macros: any }[];
    nutritionGoals: any;
    setFitTokenBalance: React.Dispatch<React.SetStateAction<number>>;
    showNotification: (message: string, type?: 'success' | 'error') => void;
    currentUser: UserProfile;
    handleToggleFollow: (username: string) => void;
    handleBlockUser: (username: string) => void;
    profile: UserProfile;
    coins: Coin[];
    nfts: NFT[];
    posts: Post[];
    reels: Reel[];
    proofOfWorkouts: ProofOfWorkoutPost[];
    workoutRoutines: WorkoutRoutine[];
    goBack?: () => void;
    stepStats: { steps: number; distance: number; calories: number };
    isStepCounterActive: boolean;
    stepCounterPermissionState: 'prompt' | 'granted' | 'denied' | 'unsupported';
    onToggleStepCounter: () => void;
    activityHistory: ActivityRecord[];
    waterCount: number;
    setWaterCount: React.Dispatch<React.SetStateAction<number>>;
    theme: 'light' | 'dark';
    onUpdateProfile: (updatedUser: UserProfile) => void;
    onCreateHighlight: (newHighlight: StoryHighlight) => void;
    badgeData: BadgeNFT[];
    earnedBadgeIds: Set<string>;
    getBadgeProgress: (badge: BadgeNFT) => { current: number, goal: number } | null;
    onUpdateUserProfileData: (newData: DetailedUserProfileData) => void;
    isModal?: boolean;
    closeModal?: () => void;
}

const getLocalDateString = (offset = 0): string => {
    const d = new Date();
    d.setDate(d.getDate() - offset);
    const year = d.getFullYear();
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    const day = d.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const NutrientProgress: React.FC<{ label: string; value: number; goal: number; unit: string; color: string; }> = ({ label, value, goal, unit, color }) => {
    const percentage = goal > 0 ? Math.min((value / goal) * 100, 100) : 0;
    return (
        <div>
            <div className="flex justify-between items-baseline mb-1">
                <span className="text-xs font-bold text-gray-300 uppercase tracking-wide">{label}</span>
                <span className="text-xs font-mono text-gray-400">
                    <span className="text-white font-bold">{value.toFixed(0)}</span> / {goal}{unit}
                </span>
            </div>
            <div className="w-full bg-gray-800/50 rounded-full h-2 overflow-hidden border border-white/5">
                <div className={`${color} h-full rounded-full transition-all duration-1000 ease-out shadow-[0_0_10px_currentColor]`} style={{ width: `${percentage}%` }}></div>
            </div>
        </div>
    );
};

const ActivityCard: React.FC<{ record: ActivityRecord; t: (key: string, options?: any) => string | string[]; }> = ({ record, t }) => {
    const recordDate = new Date(record.date + 'T00:00:00');
    const today = new Date();
    const isToday = recordDate.getFullYear() === today.getFullYear() &&
                  recordDate.getMonth() === today.getMonth() &&
                  recordDate.getDate() === today.getDate();
    const dateLabel = isToday ? "Today" : recordDate.toLocaleDateString('en-US', { weekday: 'short', month: 'long', day: 'numeric' });
    
    return (
        <div className="bg-[#1E1E1E] p-4 rounded-xl shadow-lg border border-white/5">
            <div className="flex justify-between items-center mb-3">
                <h4 className="font-bold text-white">{dateLabel}</h4>
            </div>
            <div className="grid grid-cols-4 gap-2 text-sm">
                <div className="bg-black/30 p-2 rounded-lg text-center">
                    <span className="text-lg block mb-1">👟</span>
                    <p className="font-bold text-white text-xs">{record.steps.toLocaleString()}</p>
                </div>
                <div className="bg-black/30 p-2 rounded-lg text-center">
                    <span className="text-lg block mb-1">📏</span>
                    <p className="font-bold text-white text-xs">{record.distance.toFixed(2)}</p>
                </div>
                <div className="bg-black/30 p-2 rounded-lg text-center">
                    <span className="text-lg block mb-1">🔥</span>
                    <p className="font-bold text-white text-xs">{record.calories.toFixed(0)}</p>
                </div>
                <div className="bg-black/30 p-2 rounded-lg text-center">
                    <span className="text-lg block mb-1">💧</span>
                    <p className="font-bold text-white text-xs">{record.water}</p>
                </div>
            </div>
        </div>
    );
};

// FIX: Changed to a named export to resolve the "no default export" error in App.tsx.
export const ProfilePage: React.FC<ProfilePageProps> = ({ 
    openModal, isProUser, fitTokenBalance, userProfileData, nutritionHistory, nutritionGoals, setFitTokenBalance, showNotification, 
    currentUser, handleToggleFollow, handleBlockUser, profile, coins, nfts, posts, reels, proofOfWorkouts, workoutRoutines, goBack,
    stepStats, isStepCounterActive, stepCounterPermissionState, onToggleStepCounter,
    activityHistory, waterCount, setWaterCount, theme, onUpdateProfile, onCreateHighlight,
    badgeData, earnedBadgeIds, getBadgeProgress, onUpdateUserProfileData, isModal, closeModal
}) => {
    const { t, language } = useTranslation();
    const isCurrentUser = currentUser.username === profile.username;
    const [activeTab, setActiveTab] = useState<ProfileTab>('content');
    // Updated contentTab to include 'pow' (Proof of Workout)
    const [contentTab, setContentTab] = useState<'posts' | 'reels' | 'pow' | 'tagged'>('posts');
    
    // Quest Tab State
    const [activeQuestCategory, setActiveQuestCategory] = useState<BadgeCategory>('Milestones');
    
    const activityChartRef = useRef<HTMLCanvasElement>(null);
    const activityChartInstance = useRef<Chart | null>(null);
    const [chartMetric, setChartMetric] = useState<'steps' | 'distance' | 'calories'>('steps');
    
    // Summaries
    const [weeklySummary, setWeeklySummary] = useState('');
    const [isWeeklySummaryLoading, setIsWeeklySummaryLoading] = useState(false);

    // Badge Details State
    const [viewingBadge, setViewingBadge] = useState<BadgeNFT | null>(null);

    // --- Derived Data for Profile ---
    const isFollowing = currentUser.following.includes(profile.username);
    const isBlocked = currentUser.blockedUsers?.includes(profile.username);
    const followingCount = profile.following.length;

    // Filter posts: Exclude Proof of Workouts for the main 'posts' tab grid to keep it clean
    const myPosts = useMemo(() => posts.filter(p => p.author === profile.username && p.type !== 'proofOfWorkout'), [posts, profile.username]);
    const myReels = useMemo(() => reels.filter(r => r.user === profile.username), [reels, profile.username]);
    // Filter Proof of Workouts for the new tab
    const myPowPosts = useMemo(() => proofOfWorkouts.filter(p => p.user.username === profile.username), [proofOfWorkouts, profile.username]);

    const allMyMediaItems = useMemo(() => {
        return myPosts.map(p => ({ ...p, originalType: 'post' as const }));
    }, [myPosts]);

    const myReelItems = useMemo(() => {
        return myReels.map(r => ({ ...r, originalType: 'reel', mediaType: 'video', mediaUrl: r.videoSrc }));
    }, [myReels]);

    // Pass the full object, not just media type props
    const myPowItems = useMemo(() => {
        return myPowPosts.map(p => ({ ...p, originalType: 'post' as const }));
    }, [myPowPosts]);
    
    const taggedInContent = useMemo(() => {
        const taggedPosts = posts.filter(p => p.taggedUsers?.includes(profile.username)).map(p => ({ ...p, originalType: 'post' }));
        const taggedReels = reels.filter(r => r.taggedUsers?.includes(profile.username)).map(r => ({ ...r, originalType: 'reel', mediaType: 'video', mediaUrl: r.videoSrc }));
        return [...taggedPosts, ...taggedReels];
    }, [posts, reels, profile.username]);

    // --- Effects ---

    useEffect(() => {
        setActiveTab('content');
    }, [profile.username, isCurrentUser]);

    // Chart Effect
    useEffect(() => {
        if (activeTab === 'history' && isCurrentUser && activityChartRef.current && activityHistory.length > 0) {
            if (activityChartInstance.current) activityChartInstance.current.destroy();
            const ctx = activityChartRef.current.getContext('2d');
            if(ctx) {
                const last7Days = [...activityHistory].slice(0, 7).reverse();
                const metricColors = {
                    steps: { base: 'rgba(16, 185, 129, 0.6)', border: '#10B981' },
                    distance: { base: 'rgba(59, 130, 246, 0.6)', border: '#3B82F6' },
                    calories: { base: 'rgba(245, 158, 11, 0.6)', border: '#F59E0B' },
                };
                const gradient = ctx.createLinearGradient(0, 0, 0, 150);
                gradient.addColorStop(0, metricColors[chartMetric].base);
                gradient.addColorStop(1, 'rgba(30, 30, 30, 0.1)');

                const chartConfig: ChartConfiguration = {
                    type: 'bar',
                    data: {
                        labels: last7Days.map(d => new Date(d.date + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'short' })),
                        datasets: [{
                            label: t(`profile.${chartMetric}`) as string,
                            data: last7Days.map(d => d[chartMetric]),
                            backgroundColor: gradient,
                            borderColor: metricColors[chartMetric].border,
                            borderWidth: 2,
                            borderRadius: 6,
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { 
                            legend: { display: false },
                            tooltip: {
                                backgroundColor: '#121212',
                                titleColor: '#FFFFFF',
                                bodyColor: '#FFFFFF',
                                titleFont: { weight: 'bold' },
                                displayColors: false,
                                callbacks: {
                                    label: (context) => `${context.formattedValue} ${chartMetric === 'distance' ? 'km' : chartMetric === 'calories' ? 'kcal' : ''}`
                                }
                            }
                        },
                        scales: {
                            y: { beginAtZero: true, grid: { color: '#374151' }, ticks: { color: '#9CA3AF', font: { size: 10 } } },
                            x: { grid: { display: false }, ticks: { color: '#9CA3AF', font: { weight: 'bold', size: 10 } } }
                        }
                    }
                };
                activityChartInstance.current = new (window as any).Chart(ctx, chartConfig);
            }
        }
    }, [activeTab, isCurrentUser, activityHistory, chartMetric, theme, t]);

    // --- Handlers ---

    const handleGenerateWeeklySummary = async () => {
        if (isWeeklySummaryLoading || !isCurrentUser || activityHistory.length < 1) return;
        setIsWeeklySummaryLoading(true);
        setWeeklySummary('');
        try {
            const last7Days = activityHistory.slice(0, 7);
            const languageName = supportedLanguages[language]?.name || 'English';
            const summary = await generateActivitySummary(last7Days, languageName);
            setWeeklySummary(summary);
        } catch (error: any) {
            setWeeklySummary("Could not generate summary.");
        } finally {
            setIsWeeklySummaryLoading(false);
        }
    };

    const handleGridItemClick = useCallback((item: any) => {
        if (item.originalType === 'post') {
             if (contentTab === 'pow') { // Check if it is a Proof of Workout from the specific tab
                 // Pass just the ID, let the modal sync with main state
                 openModal(ModalType.ProofOfWorkoutDetail, { id: item.id.toString() });
             } else {
                 openModal(ModalType.PostDetail, item);
             }
        } else if (item.originalType === 'reel') {
            openModal(ModalType.ReelPlayer, item);
        }
    }, [openModal, contentTab]);

    const calculateAge = (dob: string): number => {
        if (!dob) return userProfileData.age;
        const birthDate = new Date(dob);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) age--;
        return age;
    };

    const getActivityLabel = (val: number) => {
        if (val <= 1.2) return "Sedentary";
        if (val <= 1.375) return "Light Active";
        if (val <= 1.55) return "Moderate";
        if (val <= 1.725) return "Very Active";
        return "Extra Active";
    };

    const getGenderIcon = (gender: string) => {
        return gender === 'male' ? '♂️' : gender === 'female' ? '♀️' : '⚧️';
    }

    // Helper to map badge types to actions
    const getQuestAction = (conditionType: string) => {
        switch (conditionType) {
            case 'stepsInDay':
            case 'totalSteps':
            case 'distanceInDay':
            case 'totalDistance':
                return { label: "Go Move", action: () => { setActiveTab('tracker'); onToggleStepCounter(); } };
            case 'powCount':
            case 'verifiedPowCount':
                return { label: "Log Workout", action: () => openModal(ModalType.ProofOfWorkout) };
            case 'waterInDay':
                return { label: "Log Water", action: () => { setActiveTab('tracker'); } };
            case 'sleepInDay':
            case 'mealLogs':
            case 'mealLogStreak':
                return { label: "Log Data", action: () => openModal(ModalType.DataEntry) }; // Or AddMealModal
            case 'followerCount':
                return { label: "Invite Friends", action: () => showNotification("Invite link copied!", "success") };
            case 'postCount':
                return { label: "Create Post", action: () => openModal(ModalType.CreatePost) };
            case 'reelCount':
                return { label: "Create Reel", action: () => openModal(ModalType.CreatePost) };
            case 'storyCount':
                return { label: "Add Story", action: () => openModal(ModalType.CreatePost) };
            case 'routineCount':
                return { label: "Build Routine", action: () => openModal(ModalType.CreateRoutine) };
            case 'usedAiCoach':
                return { label: "Chat AI", action: () => openModal(ModalType.AiCoach) };
            case 'aiImageGenerated':
                return { label: "Generate Art", action: () => openModal(ModalType.ImageGeneration) };
            case 'fitTokenEarned':
            case 'fitTokenBalance':
                return { label: "View Wallet", action: () => setActiveTab('wallet') };
            default:
                return { label: "Go", action: () => {} };
        }
    };

    // --- RENDER HELPERS ---

    const renderContentGrid = () => {
        let itemsToRender: any[] = [];
        switch(contentTab) {
            case 'posts': itemsToRender = allMyMediaItems; break;
            case 'reels': itemsToRender = myReelItems; break;
            case 'pow': itemsToRender = myPowItems; break;
            case 'tagged': itemsToRender = taggedInContent; break;
        }

        return (
            <div className="p-1 pt-2 animate-fadeIn">
                <div className={`grid ${contentTab === 'pow' ? 'grid-cols-2 gap-2' : 'grid-cols-3 gap-1'}`}>
                    {itemsToRender.map((item) => {
                        const isVideo = item.mediaType === 'video';
                        const isPoW = contentTab === 'pow';
                        
                        return (
                            <div 
                                key={item.id} 
                                className={`relative group bg-gray-900 rounded-md overflow-hidden cursor-pointer border border-white/5 ${isPoW ? 'aspect-[4/5] rounded-xl' : 'aspect-square'}`} 
                                onClick={() => handleGridItemClick(item)}
                            >
                                {isVideo ? (
                                    <video className="w-full h-full object-cover" src={item.mediaUrl} muted loop />
                                ) : (
                                    <img className="w-full h-full object-cover" src={item.mediaUrl} alt="" />
                                )}
                                
                                {/* Icon Overlays */}
                                {isVideo && !isPoW && (
                                    <svg xmlns="http://www.w3.org/2000/svg" className="absolute top-1 right-1 w-4 h-4 text-white drop-shadow-md" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                                )}
                                
                                {isPoW && (
                                    <>
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/20"></div>
                                        {/* Verified Badge */}
                                        <div className="absolute top-2 right-2 bg-emerald-500 text-white text-[8px] font-bold px-2 py-0.5 rounded shadow-md flex items-center gap-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="8" height="8" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                                            VERIFIED
                                        </div>
                                        
                                        {/* Bottom Overlay Stats */}
                                        <div className="absolute bottom-0 left-0 right-0 p-3 z-20 flex flex-col justify-end h-full">
                                            <h4 className="text-white font-bold text-sm uppercase truncate shadow-black drop-shadow-lg leading-tight mb-1">{item.activity}</h4>
                                            <div className="flex items-center justify-between mt-1">
                                                 <div className="flex items-center gap-2">
                                                     <div className="bg-white/10 backdrop-blur-sm px-1.5 py-0.5 rounded border border-white/10">
                                                         <span className="text-[9px] font-bold text-white">{item.duration?.minutes}m</span>
                                                     </div>
                                                     <div className="bg-white/10 backdrop-blur-sm px-1.5 py-0.5 rounded border border-white/10">
                                                         <span className={`text-[9px] font-bold ${item.effort >= 4 ? 'text-red-400' : 'text-emerald-400'}`}>E: {item.effort}</span>
                                                     </div>
                                                 </div>
                                                 
                                                 {item.likes > 0 && (
                                                     <div className="flex items-center gap-1">
                                                         <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill={item.isLiked ? "#ef4444" : "white"} stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                                                         <span className="text-[10px] text-white font-bold">{item.likes}</span>
                                                     </div>
                                                 )}
                                            </div>
                                        </div>
                                    </>
                                )}
                            </div>
                        );
                    })}
                </div>
                {itemsToRender.length === 0 && (
                    <div className="text-center py-16 text-gray-500">
                        <p className="font-medium text-sm">No content yet.</p>
                    </div>
                )}
            </div>
        );
    };

    const InfoTile = ({ label, value, icon, color = "text-white", subValue }: { label: string, value: string | number, icon: string, color?: string, subValue?: string }) => (
        <div className="bg-[#1a1a1a]/80 backdrop-blur-sm p-3 rounded-xl border border-white/5 flex items-center gap-3 shadow-sm hover:bg-[#222] transition-all relative overflow-hidden group">
            <div className="w-10 h-10 rounded-full bg-black/40 flex items-center justify-center text-xl shadow-inner group-hover:scale-110 transition-transform">
                {icon}
            </div>
            <div>
                <p className="text-[9px] text-gray-500 font-bold uppercase tracking-wider">{label}</p>
                <p className={`text-sm font-bold ${color} leading-tight`}>{value}</p>
                {subValue && <p className="text-[9px] text-gray-600 font-mono mt-0.5">{subValue}</p>}
            </div>
        </div>
    );

    const RarityColorMap: Record<BadgeRarity, string> = {
        Common: 'border-gray-600',
        Uncommon: 'border-green-500',
        Rare: 'border-blue-500',
        Epic: 'border-purple-500',
        Legendary: 'border-yellow-500'
    };

    const RarityTextMap: Record<BadgeRarity, string> = {
        Common: 'text-gray-400',
        Uncommon: 'text-green-400',
        Rare: 'text-blue-400',
        Epic: 'text-purple-400',
        Legendary: 'text-yellow-400'
    };

    const CategoryIconMap: Record<BadgeCategory, string> = {
        Milestones: '🏆',
        Consistency: '🔥',
        Social: '🤝',
        Content: '🎬',
        PRO: '⚡',
        Economy: '💰'
    };

    // --- MAIN RENDER SWITCH ---

    const renderTabContent = () => {
        switch (activeTab) {
            case 'content':
                return (
                    <div>
                        <div className="flex border-b border-white/5 bg-[#121212] sticky top-12 z-10 h-12">
                            {[
                                { id: 'posts', icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg> },
                                { id: 'reels', icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>, activeIcon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg> }, // Using simple video icon logic for now or custom SVG
                                { id: 'pow', icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/></svg> },
                                { id: 'tagged', icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>, activeIcon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> }
                            ].map(item => {
                                 // Correcting icons for clarity
                                 let DisplayIcon;
                                 if (item.id === 'reels') DisplayIcon = <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/><line x1="16" x2="22" y1="5" y2="11"/><path d="M21 6h-6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h6"/></svg>;
                                 else if (item.id === 'tagged') DisplayIcon = <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
                                 else DisplayIcon = item.icon;

                                 return (
                                    <button 
                                        key={item.id} 
                                        onClick={() => setContentTab(item.id as any)} 
                                        className={`flex-1 flex justify-center items-center transition-all border-b-2 h-full ${contentTab === item.id ? 'text-white border-white' : 'text-gray-500 border-transparent hover:text-gray-300'}`}
                                    >
                                        {DisplayIcon}
                                    </button>
                                );
                            })}
                        </div>
                        {renderContentGrid()}
                    </div>
                );

            case 'tracker':
                 if (!isCurrentUser) return null;
                 const realAge = calculateAge(userProfileData.dob);
                 const stepProgress = Math.min((stepStats.steps / 10000) * 100, 100);

                 return (
                    <div className="p-4 space-y-6 pb-32 animate-fadeIn">
                        
                        {/* 1. BIOMETRIC ID CARD (Full Detail) */}
                        <section className="bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-3xl p-5 border border-white/10 shadow-2xl relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-40 h-40 bg-blue-500/5 rounded-full blur-3xl pointer-events-none"></div>
                            
                            <div className="flex justify-between items-center mb-6 relative z-10 border-b border-white/5 pb-4">
                                <div>
                                    <h2 className="text-lg font-black text-white italic tracking-wider flex items-center gap-2">
                                        <span className="text-2xl">🪪</span> BIO<span className="text-blue-500">METRIC_ID</span>
                                    </h2>
                                    <p className="text-[9px] text-gray-500 font-mono uppercase tracking-widest mt-1">Subject: {profile.username}</p>
                                </div>
                                <button onClick={() => openModal(ModalType.DataEntry)} className="text-[10px] font-bold bg-blue-900/20 text-blue-400 border border-blue-500/30 px-4 py-2 rounded-lg hover:bg-blue-900/40 transition-all flex items-center gap-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
                                    EDIT
                                </button>
                            </div>
                            
                            {/* Detailed Grid */}
                            <div className="grid grid-cols-2 gap-2.5 relative z-10">
                                <InfoTile label="Physical" value={`${userProfileData.height}cm / ${userProfileData.weight}kg`} icon="📏" />
                                <InfoTile label="Age / Gender" value={`${realAge} / ${userProfileData.gender ? (userProfileData.gender.charAt(0).toUpperCase() + userProfileData.gender.slice(1)) : '-'}`} icon={getGenderIcon(userProfileData.gender)} subValue={`DOB: ${userProfileData.dob || 'Not Set'}`} />
                                
                                <InfoTile label="Somatotype" value={userProfileData.somatotype ? (userProfileData.somatotype.charAt(0).toUpperCase() + userProfileData.somatotype.slice(1)) : 'N/A'} icon="🧬" color="text-blue-300" subValue="Genetic Body Type" />
                                <InfoTile label="Fat Distribution" value={userProfileData.fatDistribution ? (userProfileData.fatDistribution.charAt(0).toUpperCase() + userProfileData.fatDistribution.slice(1)) : 'N/A'} icon="🧊" color="text-blue-300" subValue="Storage Pattern" />
                                
                                <InfoTile label="Activity Level" value={getActivityLabel(userProfileData.activity)} icon="⚡" color="text-yellow-400" subValue={`Multiplier: x${userProfileData.activity}`} />
                                <InfoTile label="Goal" value={userProfileData.fitnessGoal?.replace('_', ' ').toUpperCase() || 'MAINTENANCE'} icon="🎯" color="text-green-400" subValue={`Target: ${userProfileData.targetWeight} kg`} />
                            </div>
                        </section>

                        {/* 2. AI METABOLIC ENGINE */}
                        <section className="bg-[#080808] p-1 rounded-3xl border border-green-900/30 shadow-lg relative overflow-hidden">
                            <div className="bg-gradient-to-b from-green-900/10 to-transparent p-5 rounded-3xl">
                                <div className="flex justify-between items-start mb-5 relative z-10">
                                    <div>
                                        <h2 className="text-lg font-black text-white flex items-center gap-2 tracking-tight">
                                            <span className="text-2xl">🔋</span> METABOLIC <span className="text-green-500">ENGINE</span>
                                        </h2>
                                        <p className="text-[10px] text-gray-500 mt-1 font-mono">AI-POWERED CALCULATION</p>
                                    </div>
                                    {/* Auto-Sync Indicator instead of Recalculate Button */}
                                    <div className="flex items-center gap-2 bg-green-900/20 px-3 py-1.5 rounded-lg border border-green-500/20">
                                        <div className="relative w-2 h-2">
                                            <div className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-75"></div>
                                            <div className="relative w-2 h-2 bg-green-500 rounded-full"></div>
                                        </div>
                                        <span className="text-[9px] font-bold text-green-400 uppercase tracking-wider">Auto-Sync Active</span>
                                    </div>
                                </div>

                                {userProfileData.aiDietPlan ? (
                                    <div className="space-y-6 relative z-10 animate-fadeIn">
                                        {/* Main Target Circle */}
                                        <div className="flex items-center justify-center py-2">
                                            <div className="relative w-40 h-40 flex items-center justify-center">
                                                <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                                                    <circle cx="50" cy="50" r="45" fill="none" stroke="#1a1a1a" strokeWidth="8" />
                                                    <circle cx="50" cy="50" r="45" fill="none" stroke="#10B981" strokeWidth="8" strokeDasharray="283" strokeDashoffset="70" strokeLinecap="round" className="drop-shadow-[0_0_10px_#10B981]" />
                                                </svg>
                                                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                                                    <span className="text-xs text-gray-400 font-bold uppercase">Target</span>
                                                    <span className="text-3xl font-black text-white tracking-tighter">{userProfileData.aiDietPlan.targetCalories}</span>
                                                    <span className="text-xs text-green-500 font-bold">KCAL / DAY</span>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Stats Grid */}
                                        <div className="grid grid-cols-3 gap-2">
                                            <div className="bg-black/40 p-2 rounded-xl border border-white/5 text-center">
                                                <p className="text-[9px] text-gray-500 uppercase font-bold">BMR (Rest)</p>
                                                <p className="text-sm font-bold text-white">{userProfileData.aiDietPlan.bmr.toFixed(0)}</p>
                                            </div>
                                            <div className="bg-black/40 p-2 rounded-xl border border-white/5 text-center">
                                                <p className="text-[9px] text-gray-500 uppercase font-bold">Active Burn</p>
                                                <p className="text-sm font-bold text-orange-400">+{userProfileData.aiDietPlan.sportsBurn.toFixed(0)}</p>
                                            </div>
                                            <div className="bg-black/40 p-2 rounded-xl border border-white/5 text-center">
                                                <p className="text-[9px] text-gray-500 uppercase font-bold">TDEE (Total)</p>
                                                <p className="text-sm font-bold text-blue-400">{userProfileData.aiDietPlan.tdee.toFixed(0)}</p>
                                            </div>
                                        </div>

                                        {/* Macro Distribution */}
                                        <div className="bg-[#151515] p-4 rounded-2xl border border-white/5 space-y-4">
                                            <NutrientProgress label="Protein (Repair)" value={userProfileData.aiDietPlan.macros.protein} goal={nutritionGoals.pro} unit="g" color="bg-blue-500" />
                                            <NutrientProgress label="Carbs (Energy)" value={userProfileData.aiDietPlan.macros.carbs} goal={nutritionGoals.carb} unit="g" color="bg-orange-500" />
                                            <NutrientProgress label="Fats (Hormonal)" value={userProfileData.aiDietPlan.macros.fat} goal={nutritionGoals.fat} unit="g" color="bg-yellow-500" />
                                        </div>
                                        
                                        {/* AI Advice Quote */}
                                        <div className="flex gap-3 bg-green-900/10 border border-green-500/20 p-3 rounded-xl items-start">
                                            <span className="text-2xl">🤖</span>
                                            <div>
                                                <p className="text-[10px] font-bold text-green-500 uppercase mb-1">AI Coach Insight</p>
                                                <p className="text-xs text-green-100 italic leading-relaxed">"{userProfileData.aiDietPlan.advice}"</p>
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="text-center py-10 bg-black/20 rounded-2xl border border-white/5 border-dashed">
                                        <span className="text-4xl block mb-3 opacity-50">🧠</span>
                                        <p className="text-sm text-gray-400 mb-3 font-medium">Initializing Neural Core...</p>
                                        <p className="text-xs text-gray-600 max-w-xs mx-auto">Please complete your bio-data entry to activate the engine.</p>
                                    </div>
                                )}
                            </div>
                        </section>

                        {/* 3. ACTIVE SPORTS LEDGER */}
                        <section className="bg-[#1E1E1E] p-5 rounded-3xl border border-gray-800 shadow-lg">
                            <div className="flex justify-between items-center mb-4">
                                <h2 className="text-lg font-black text-white flex items-center gap-2 italic">
                                    <span className="text-2xl">🏅</span> ACTIVE <span className="text-orange-500">BURN</span>
                                </h2>
                                <button onClick={() => openModal(ModalType.DataEntry)} className="text-gray-400 hover:text-white"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14"/></svg></button>
                            </div>
                            
                            {userProfileData.activeSports && userProfileData.activeSports.length > 0 ? (
                                <div className="space-y-2">
                                    {userProfileData.activeSports.map((sport, idx) => {
                                        const burnData = userProfileData.aiDietPlan?.sportsBreakdown?.find(s => s.name === sport.name);
                                        const hourlyBurn = burnData ? burnData.hourlyBurn : 0;
                                        
                                        return (
                                            <div key={idx} className="flex items-center justify-between bg-black/30 p-3 rounded-xl border border-white/5 hover:border-orange-500/30 transition-colors">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500/20 to-red-500/20 flex items-center justify-center text-orange-400 text-sm font-bold border border-orange-500/20">
                                                        {sport.name.substring(0,2).toUpperCase()}
                                                    </div>
                                                    <div>
                                                        <p className="font-bold text-white text-sm">{sport.name}</p>
                                                        <p className="text-[10px] text-gray-500 mt-0.5">{sport.hoursPerWeek}h/week</p>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    {hourlyBurn > 0 ? (
                                                        <>
                                                            <p className="font-black text-orange-400 text-sm">~{hourlyBurn.toFixed(0)}</p>
                                                            <p className="text-[9px] text-gray-500 uppercase font-bold">kcal / hour</p>
                                                        </>
                                                    ) : (
                                                        <p className="text-[10px] text-gray-500">Calculating...</p>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            ) : (
                                <div className="text-center py-6 text-gray-500 bg-black/20 rounded-xl">
                                    <p className="text-xs">No sports added yet.</p>
                                </div>
                            )}
                        </section>

                        {/* 4. DAILY ACTIVITY & WATER */}
                        <div className="grid grid-cols-1 gap-4">
                            {/* Activity Circle */}
                            <div className="bg-[#1E1E1E] p-5 rounded-3xl border border-gray-800 shadow-lg flex items-center gap-6 relative overflow-hidden">
                                <div className="relative w-28 h-28 flex-shrink-0">
                                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                                        <path className="text-gray-800" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" />
                                        <path className="text-green-500 transition-all duration-1000 ease-out drop-shadow-[0_0_5px_#10B981]" strokeDasharray={`${stepProgress}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                                    </svg>
                                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">STEPS</span>
                                        {/* FIX: Display exact steps without 'k' format for low numbers */}
                                        <span className="text-xl font-black text-white">{stepStats.steps.toLocaleString()}</span>
                                    </div>
                                </div>
                                <div className="flex-1 space-y-4 z-10">
                                    <div>
                                        <div className="flex justify-between text-xs mb-1"><span className="text-gray-400 font-bold uppercase">Distance</span><span className="text-white font-bold font-mono">{stepStats.distance.toFixed(2)} km</span></div>
                                        <div className="w-full bg-gray-800 h-1.5 rounded-full"><div className="bg-blue-500 h-1.5 rounded-full shadow-[0_0_5px_#3B82F6]" style={{width: '45%'}}></div></div>
                                    </div>
                                    <div>
                                        <div className="flex justify-between text-xs mb-1"><span className="text-gray-400 font-bold uppercase">Active Cal</span><span className="text-orange-400 font-bold font-mono">{stepStats.calories.toFixed(0)} kcal</span></div>
                                        <div className="w-full bg-gray-800 h-1.5 rounded-full"><div className="bg-orange-500 h-1.5 rounded-full shadow-[0_0_5px_#F59E0B]" style={{width: '60%'}}></div></div>
                                    </div>
                                    <button onClick={onToggleStepCounter} className={`w-full py-2 rounded-lg font-bold text-[10px] uppercase transition-all ${isStepCounterActive ? 'bg-red-500/10 text-red-500 border border-red-500/30 hover:bg-red-500/20' : 'bg-green-500/10 text-green-500 border border-green-500/30 hover:bg-green-500/20'}`}>
                                        {isStepCounterActive ? '🛑 Stop Tracking' : (stepCounterPermissionState === 'denied' ? '⚠️ Permission Denied' : stepCounterPermissionState === 'prompt' ? '▶️ Enable Sensors' : '▶️ Start Tracking')}
                                    </button>
                                </div>
                            </div>

                            {/* Water Tracker */}
                            <div className="bg-[#1E1E1E] p-5 rounded-3xl border border-blue-500/20 shadow-lg relative overflow-hidden">
                                <div className="absolute right-0 bottom-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl"></div>
                                <div className="flex justify-between items-center mb-4 relative z-10">
                                    <h3 className="text-sm font-bold text-blue-400 flex items-center gap-2 uppercase tracking-wider">
                                        <span>💧</span> Hydration
                                    </h3>
                                    <span className="text-xl font-black text-white">{waterCount} <span className="text-xs font-normal text-gray-500">/ 10</span></span>
                                </div>
                                <div className="flex gap-1 h-12 mb-4 relative z-10">
                                    {[...Array(10)].map((_, i) => (
                                        <div key={i} className={`flex-1 rounded-md transition-all duration-300 ${i < waterCount ? 'bg-gradient-to-t from-blue-600 to-blue-400 shadow-[0_0_10px_#3b82f6]' : 'bg-gray-800/50'}`}></div>
                                    ))}
                                </div>
                                <div className="flex gap-3 relative z-10">
                                    <button onClick={() => setWaterCount(Math.max(0, waterCount - 1))} className="w-12 h-10 bg-gray-800 hover:bg-gray-700 text-white rounded-xl font-bold text-lg transition-colors">-</button>
                                    <button onClick={() => setWaterCount(Math.min(10, waterCount + 1))} className="flex-1 bg-blue-600 hover:bg-blue-500 text-white h-10 rounded-xl text-xs font-bold shadow-lg shadow-blue-900/20 uppercase tracking-wide transition-all transform active:scale-95">Add Glass (+250ml)</button>
                                </div>
                            </div>
                        </div>
                    </div>
                 );

            case 'history':
                if (!isCurrentUser) return null;
                return (
                    <div className="p-4 space-y-6 animate-fadeIn">
                        <section className="bg-[#1E1E1E] p-4 rounded-xl border border-white/5">
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-sm font-bold text-white uppercase tracking-widest">Analysis</h3>
                                <div className="flex bg-black/30 rounded-lg p-1">
                                    {['steps', 'calories'].map(m => (
                                        <button key={m} onClick={() => setChartMetric(m as any)} className={`px-3 py-1 text-[10px] font-bold rounded-md transition-colors ${chartMetric === m ? 'bg-gray-700 text-white' : 'text-gray-500'}`}>{m}</button>
                                    ))}
                                </div>
                            </div>
                            <div className="h-48 w-full">
                                {activityHistory.length > 0 ? (
                                    <canvas ref={activityChartRef}></canvas>
                                ) : (
                                    <div className="h-full flex items-center justify-center text-xs text-gray-500">No data to visualize</div>
                                )}
                            </div>
                            <button 
                                onClick={handleGenerateWeeklySummary} 
                                disabled={isWeeklySummaryLoading}
                                className="w-full mt-4 py-3 bg-purple-900/20 text-purple-400 border border-purple-500/30 rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-purple-900/30 transition-colors"
                            >
                                {isWeeklySummaryLoading ? 'Thinking...' : '✨ Generate AI Insight'}
                            </button>
                            {weeklySummary && (
                                <div className="mt-3 p-3 bg-black/40 rounded-lg text-xs text-gray-300 leading-relaxed border-l-2 border-purple-500 animate-fadeIn">
                                    {weeklySummary}
                                </div>
                            )}
                        </section>

                        <div className="space-y-3">
                            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest ml-1">Recent Logs</h3>
                            {activityHistory.slice(0, 5).map((record, index) => (
                                <ActivityCard key={index} record={record} t={t} />
                            ))}
                        </div>
                    </div>
                );

            case 'quests':
                if (!isCurrentUser) return null;

                const categories: BadgeCategory[] = ['Milestones', 'Consistency', 'Social', 'Content', 'PRO', 'Economy'];
                
                const filteredBadges = badgeData.filter(b => b.category === activeQuestCategory);

                return (
                    <div className="p-4 pb-32 space-y-6 animate-fadeIn">
                        
                        {/* 1. Quest Dashboard Header */}
                        <div className="bg-gradient-to-br from-[#121212] to-[#000000] p-6 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden group">
                            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-overlay"></div>
                            <div className="absolute -top-20 -right-20 w-60 h-60 bg-emerald-500/10 rounded-full blur-[80px] group-hover:bg-emerald-500/20 transition-colors duration-1000"></div>
                            
                            <div className="relative z-10 flex flex-col gap-1">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h2 className="text-3xl font-black text-white italic tracking-tighter flex items-center gap-2">
                                            QUEST <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-blue-500">HUB</span>
                                        </h2>
                                        <p className="text-[10px] text-gray-400 mt-1 font-medium tracking-wide">COMPLETE TASKS. EARN NFTS. LEVEL UP.</p>
                                    </div>
                                    <div className="text-right bg-white/5 px-3 py-2 rounded-xl border border-white/5 backdrop-blur-sm">
                                        <p className="text-[9px] font-bold text-gray-500 uppercase tracking-wider">Total Value</p>
                                        <p className="text-xl font-black text-emerald-400 drop-shadow-sm">{fitTokenBalance.toLocaleString()} $FIT</p>
                                    </div>
                                </div>
                                
                                <div className="mt-6">
                                    <div className="flex justify-between text-[10px] font-bold text-gray-500 mb-1 uppercase tracking-wider">
                                        <span>Total Completion</span>
                                        <span>{earnedBadgeIds.size} / {badgeData.length}</span>
                                    </div>
                                    <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden border border-white/5">
                                        <div 
                                            className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-blue-500 shadow-[0_0_15px_#10b981]" 
                                            style={{ width: `${(earnedBadgeIds.size / badgeData.length) * 100}%` }}
                                        ></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* 2. Category Tabs (Scrollable) */}
                        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide snap-x">
                            {categories.map((cat) => (
                                <button 
                                    key={cat}
                                    onClick={() => setActiveQuestCategory(cat)}
                                    className={`snap-start flex-shrink-0 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all border ${activeQuestCategory === cat ? 'bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.3)]' : 'bg-[#121212] text-gray-500 border-white/10 hover:border-white/30 hover:text-gray-300'}`}
                                >
                                    {CategoryIconMap[cat]} {cat}
                                </button>
                            ))}
                        </div>

                        {/* 3. Dynamic Quest List */}
                        <div className="space-y-3">
                            {filteredBadges.map((badge) => {
                                const isEarned = earnedBadgeIds.has(badge.id);
                                const progress = getBadgeProgress(badge);
                                let percent = 0;
                                if (progress && progress.goal > 0) {
                                    percent = Math.min((progress.current / progress.goal) * 100, 100);
                                }
                                
                                // Enhanced Card Styling
                                const borderColor = isEarned ? RarityColorMap[badge.rarity] : 'border-white/10';
                                const glow = isEarned && badge.rarity === 'Legendary' ? 'shadow-[0_0_20px_rgba(245,158,11,0.3)]' : '';
                                
                                const action = getQuestAction(badge.condition.type);

                                return (
                                    <div key={badge.id} className={`relative overflow-hidden bg-[#18181b] border-2 ${borderColor} ${glow} rounded-2xl p-4 transition-all hover:bg-[#1f1f22] group`}>
                                        {/* Background Pattern for Earned */}
                                        {isEarned && <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-transparent pointer-events-none"></div>}
                                        
                                        <div className="flex items-start gap-4 relative z-10">
                                            {/* Icon */}
                                            <div className={`w-14 h-14 rounded-xl flex-shrink-0 flex items-center justify-center text-3xl shadow-inner border border-white/5 ${isEarned ? 'bg-gradient-to-br from-gray-800 to-black' : 'bg-black/40 grayscale opacity-50'}`}>
                                                {isEarned ? badge.icon : '🔒'}
                                            </div>

                                            {/* Content */}
                                            <div className="flex-1 min-w-0">
                                                <div className="flex justify-between items-start">
                                                    <h4 className={`font-bold text-sm truncate ${isEarned ? RarityTextMap[badge.rarity] : 'text-gray-400'}`}>{badge.title}</h4>
                                                    <span className={`text-[10px] font-black px-2 py-0.5 rounded border mb-2 ${isEarned ? 'bg-green-900/20 border-green-500/30 text-green-400' : 'bg-gray-800 border-gray-700 text-gray-500'}`}>
                                                        {isEarned ? 'OWNED' : `+${badge.floorPrice} $FIT`}
                                                    </span>
                                                </div>
                                                <p className="text-[11px] text-gray-500 leading-tight mt-1 line-clamp-2 font-medium">{badge.description}</p>
                                                
                                                {/* Progress Section */}
                                                <div className="mt-3">
                                                    <div className="flex justify-between text-[9px] font-mono text-gray-400 mb-1 uppercase font-bold">
                                                        <span>{isEarned ? 'Completed' : 'Progress'}</span>
                                                        <span>{progress ? `${progress.current} / ${progress.goal}` : '0 / 1'}</span>
                                                    </div>
                                                    <div className="h-2 bg-black rounded-full overflow-hidden border border-white/10 relative">
                                                        <div 
                                                            className={`h-full rounded-full transition-all duration-1000 relative ${isEarned ? 'bg-gradient-to-r from-green-500 to-emerald-400' : 'bg-blue-600'}`} 
                                                            style={{ width: `${percent}%` }}
                                                        >
                                                            {/* Animated Striped Pattern for unearned progress */}
                                                            {!isEarned && <div className="absolute inset-0 w-full h-full bg-[linear-gradient(45deg,rgba(255,255,255,.15)_25%,transparent_25%,transparent_50%,rgba(255,255,255,.15)_50%,rgba(255,255,255,.15)_75%,transparent_75%,transparent)] bg-[length:1rem_1rem] animate-[progress-stripes_1s_linear_infinite]"></div>}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Action Button (Only if not earned) */}
                                        {!isEarned && (
                                            <div className="mt-4 flex justify-end border-t border-white/5 pt-3">
                                                <button 
                                                    onClick={action.action}
                                                    className="text-[10px] font-bold bg-white/10 hover:bg-emerald-600 hover:text-white text-gray-300 px-4 py-2 rounded-lg border border-white/10 transition-all hover:scale-105 hover:border-emerald-500 flex items-center gap-2 shadow-lg"
                                                >
                                                    <span>{action.label}</span>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                            
                            {filteredBadges.length === 0 && (
                                <div className="text-center py-12 text-gray-600 text-sm">
                                    No quests available in this category yet.
                                </div>
                            )}
                        </div>
                    </div>
                );

            case 'badges':
                if (!isCurrentUser) return null;
                return (
                    <div className="p-4 animate-fadeIn min-h-screen pb-32">
                        <div className="grid grid-cols-3 gap-4">
                            {badgeData.map(badge => {
                                const isEarned = earnedBadgeIds.has(badge.id);
                                const progress = getBadgeProgress(badge);
                                let percent = 0;
                                if (progress && progress.goal > 0) {
                                    percent = Math.min((progress.current / progress.goal) * 100, 100);
                                }

                                const rarityGlow = isEarned 
                                    ? (badge.rarity === 'Legendary' ? 'shadow-[0_0_15px_rgba(245,158,11,0.5)] border-yellow-500' 
                                        : badge.rarity === 'Epic' ? 'shadow-[0_0_15px_rgba(139,92,246,0.5)] border-purple-500' 
                                        : 'border-white/10')
                                    : 'border-white/5';

                                return (
                                    <div 
                                        key={badge.id} 
                                        onClick={() => setViewingBadge(badge)}
                                        className={`relative group rounded-2xl p-3 flex flex-col items-center text-center transition-all duration-300 cursor-pointer border ${rarityGlow} ${isEarned ? 'bg-[#1E1E1E] hover:scale-105' : 'bg-[#121212] opacity-70 hover:opacity-100'}`}
                                    >
                                        {/* Icon */}
                                        <div className={`relative w-16 h-16 mb-3 rounded-full flex items-center justify-center border-2 ${isEarned ? RarityColorMap[badge.rarity] : 'border-gray-800 grayscale'}`}>
                                            <img src={badge.imageUrl} alt={badge.title} className="w-full h-full rounded-full object-cover" />
                                            {isEarned && <div className="absolute -bottom-1 -right-1 bg-green-500 text-black text-[8px] font-bold px-1.5 py-0.5 rounded-full shadow-lg">✓</div>}
                                            {!isEarned && <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full"><span className="text-2xl">🔒</span></div>}
                                        </div>
                                        
                                        {/* Info */}
                                        <span className={`text-[10px] font-bold line-clamp-1 ${isEarned ? 'text-white' : 'text-gray-500'}`}>{badge.title}</span>
                                        
                                        {/* Mini Progress Bar for Locked Items */}
                                        {!isEarned && (
                                            <div className="w-full h-1 bg-gray-800 rounded-full mt-2 overflow-hidden">
                                                <div className="h-full bg-blue-500/50" style={{ width: `${percent}%` }}></div>
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>

                        {/* BADGE DETAIL MODAL OVERLAY */}
                        {viewingBadge && (
                            <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm animate-fadeIn" onClick={() => setViewingBadge(null)}>
                                <div className="bg-[#151515] w-full max-w-sm rounded-3xl border border-white/10 p-6 shadow-2xl relative overflow-hidden" onClick={e => e.stopPropagation()}>
                                    
                                    {/* Background Glow */}
                                    <div className={`absolute top-0 left-0 w-full h-32 bg-gradient-to-b opacity-20 pointer-events-none ${viewingBadge.rarity === 'Legendary' ? 'from-yellow-500' : viewingBadge.rarity === 'Epic' ? 'from-purple-500' : 'from-blue-500'} to-transparent`}></div>

                                    {/* Close Button */}
                                    <button onClick={() => setViewingBadge(null)} className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                                    </button>

                                    {/* Content */}
                                    <div className="flex flex-col items-center text-center relative z-10">
                                        <div className={`w-28 h-28 rounded-full border-4 shadow-[0_0_30px_rgba(0,0,0,0.5)] mb-4 flex items-center justify-center bg-black ${earnedBadgeIds.has(viewingBadge.id) ? RarityColorMap[viewingBadge.rarity] : 'border-gray-700 grayscale'}`}>
                                            <img src={viewingBadge.imageUrl} alt={viewingBadge.title} className="w-full h-full rounded-full object-cover" />
                                        </div>

                                        <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border mb-2 ${RarityTextMap[viewingBadge.rarity]} ${RarityColorMap[viewingBadge.rarity]} bg-black/50`}>
                                            {viewingBadge.rarity} NFT
                                        </span>

                                        <h3 className="text-2xl font-black text-white mb-2">{viewingBadge.title}</h3>
                                        <p className="text-sm text-gray-400 leading-relaxed mb-6">{viewingBadge.description}</p>

                                        {/* Progress Section */}
                                        <div className="w-full bg-gray-800/50 rounded-xl p-4 border border-white/5 mb-4">
                                            {(() => {
                                                const progress = getBadgeProgress(viewingBadge);
                                                if (!progress) return null;
                                                const percent = Math.min((progress.current / progress.goal) * 100, 100);
                                                const isCompleted = percent >= 100;

                                                return (
                                                    <div>
                                                        <div className="flex justify-between items-end mb-2">
                                                            <span className="text-xs font-bold text-gray-400 uppercase">Progress</span>
                                                            <span className={`text-sm font-mono font-bold ${isCompleted ? 'text-green-400' : 'text-white'}`}>
                                                                {progress.current.toLocaleString()} <span className="text-gray-500">/ {progress.goal.toLocaleString()}</span>
                                                            </span>
                                                        </div>
                                                        <div className="w-full h-3 bg-black rounded-full overflow-hidden border border-white/10">
                                                            <div 
                                                                className={`h-full rounded-full transition-all duration-1000 ease-out relative ${isCompleted ? 'bg-green-500 shadow-[0_0_10px_#10b981]' : 'bg-blue-500'}`} 
                                                                style={{ width: `${percent}%` }}
                                                            >
                                                                {/* Shimmer effect for progress bar */}
                                                                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer" style={{backgroundSize: '200% 100%'}}></div>
                                                            </div>
                                                        </div>
                                                        {isCompleted ? (
                                                            <p className="text-xs text-green-400 mt-2 font-bold flex items-center justify-center gap-1"><span className="text-lg">🎉</span> Mission Accomplished!</p>
                                                        ) : (
                                                            <p className="text-xs text-gray-500 mt-2">Keep going to unlock this badge!</p>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>

                                        <div className="flex items-center justify-center gap-2 text-xs font-mono text-gray-500">
                                            <span>Market Value:</span>
                                            <span className="text-yellow-500 font-bold">{viewingBadge.floorPrice} $FIT</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                );

            case 'wallet':
                if (!isCurrentUser) return null;
                return <WalletPage openModal={openModal} coins={coins} nfts={nfts} />;
                
            default:
                return null;
        }
    };

    return (
        <div className="relative w-full h-full pb-20">
             {isModal && (
                <div className="absolute top-4 left-4 z-50">
                    <button onClick={closeModal} className="p-2 rounded-full bg-black/50 backdrop-blur-md text-white hover:bg-white/20">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m15 18-6-6 6-6"/></svg>
                    </button>
                </div>
            )}
            {/* Profile Header */}
            <div className="relative h-48 bg-gradient-to-b from-gray-800/80 to-transparent">
                <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
            </div>
            
            <div className="px-4 relative -mt-16 mb-4 flex flex-col items-center">
                <div className="relative group cursor-pointer" onClick={() => isCurrentUser && openModal(ModalType.EditProfile)}>
                    <div className="w-28 h-28 rounded-full p-1 bg-gradient-to-tr from-green-400 to-blue-500 shadow-2xl">
                        <img className="w-full h-full rounded-full object-cover border-4 border-[#121212]" src={profile.avatarImage} alt={profile.username} />
                    </div>
                    {isCurrentUser && <div className="absolute bottom-1 right-1 bg-gray-800 p-1.5 rounded-full border border-white/20 text-white shadow-md"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg></div>}
                </div>

                <h1 className="text-2xl font-black text-white mt-3 flex items-center gap-2">
                    {profile.username}
                    {profile.cvsScore > 9 && <span className="text-blue-400" title="Verified Athlete"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg></span>}
                </h1>
                <p className="text-sm text-gray-400 mt-1 max-w-xs text-center leading-relaxed">{profile.bio || "FitSocial Athlete"}</p>

                <div className="flex items-center gap-6 mt-4 text-sm">
                    <div className="text-center cursor-pointer hover:opacity-80" onClick={() => isCurrentUser ? setActiveTab('content') : null}><span className="block font-bold text-white text-lg">{posts.filter(p => p.author === profile.username).length}</span><span className="text-gray-500 text-xs">{t('profile.posts')}</span></div>
                    <div className="text-center cursor-pointer hover:opacity-80" onClick={() => openModal(ModalType.FollowList, { type: 'followers', profile })}><span className="block font-bold text-white text-lg">{profile.followers}</span><span className="text-gray-500 text-xs">{t('profile.followers')}</span></div>
                    <div className="text-center cursor-pointer hover:opacity-80" onClick={() => openModal(ModalType.FollowList, { type: 'following', profile })}><span className="block font-bold text-white text-lg">{followingCount}</span><span className="text-gray-500 text-xs">{t('profile.following')}</span></div>
                    <div className="text-center"><span className="block font-bold text-green-400 text-lg">{profile.cvsScore}</span><span className="text-gray-500 text-xs">{t('profile.cvsScore')}</span></div>
                </div>

                <div className="flex gap-3 mt-6 w-full max-w-sm">
                    {isCurrentUser ? (
                        <>
                            <button onClick={() => openModal(ModalType.EditProfile)} className="flex-1 bg-gray-800 text-white font-bold py-2.5 rounded-xl hover:bg-gray-700 transition-all border border-gray-700">{t('profile.editProfile')}</button>
                            <button onClick={() => openModal(ModalType.Settings)} className="w-12 flex items-center justify-center bg-gray-800 text-white rounded-xl hover:bg-gray-700 border border-gray-700"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
                        </>
                    ) : (
                        <>
                            <button onClick={() => handleToggleFollow(profile.username)} className={`flex-1 font-bold py-3 rounded-xl transition-all ${isFollowing ? 'bg-gray-700 text-white' : 'bg-green-500 text-black'}`}>
                                {isFollowing ? 'Following' : 'Follow'}
                            </button>
                            {isFollowing ? (
                                <button onClick={() => showNotification(`Opening chat with ${profile.username}...`,'success')} className="flex-1 bg-gray-800 text-white font-bold py-3 rounded-xl border border-gray-700">Message</button>
                            ) : (
                                <button onClick={() => showNotification(`Message request sent to ${profile.username}!`,'success')} className="flex-1 bg-gray-800 text-white font-bold py-3 rounded-xl border border-gray-700">Send Request</button>
                            )}
                            <button onClick={() => handleBlockUser(profile.username)} className={`w-14 text-center font-bold py-3 rounded-xl transition-all ${isBlocked ? 'bg-red-800 text-white' : 'bg-gray-800 text-gray-400'}`}>
                                {isBlocked ? 'Unblock' : 'Block'}
                            </button>
                        </>
                    )}
                </div>
            </div>

            {/* Bottom Tab Bar */}
            {isCurrentUser && (
                <div className="sticky top-0 z-10 bg-[#0A0A0A]/90 backdrop-blur-xl border-t border-b border-white/5 shadow-md">
                    <div className="flex justify-around items-center h-12 max-w-lg mx-auto">
                        {(['content', 'tracker', 'quests', 'badges', 'wallet', 'history'] as ProfileTab[]).map(tab => (
                            <button key={tab} onClick={() => setActiveTab(tab)} className={`flex-1 h-full text-xs font-bold uppercase tracking-wider transition-all border-b-2 ${activeTab === tab ? 'text-white border-white' : 'text-gray-500 border-transparent'}`}>
                                {t(`profile.tabs.${tab}`)}
                            </button>
                        ))}
                    </div>
                </div>
            )}
            
            {/* Tab Content */}
            <div className="w-full">
                {renderTabContent()}
            </div>
        </div>
    );
};