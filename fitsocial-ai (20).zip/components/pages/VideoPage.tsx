
import React, { useState, useEffect, useRef } from 'react';
import { ModalType, Reel, UserProfile } from '../../types';
import { findUser } from '../../data/users';
import { useTranslation } from '../../hooks/i18n';
import CommentsOverlay from '../ui/CommentsOverlay';

interface ReelItemProps {
    reel: Reel;
    language: string;
    openModal: (modal: ModalType, data?: any) => void;
    currentUser: UserProfile;
    handleToggleFollow: (username: string) => void;
    handleLikeReel: (reelId: number) => void;
    viewUserProfile: (user: UserProfile) => void;
    users: UserProfile[];
    onPostDownloaded: (author: string, mediaUrl: string) => void;
    isActive: boolean; // Controls playback
}

const ReelItem: React.FC<ReelItemProps> = ({ reel, language, openModal, currentUser, handleToggleFollow, handleLikeReel, viewUserProfile, users, onPostDownloaded, isActive }) => {
    const { t } = useTranslation();
    const [isMuted, setIsMuted] = useState(true);
    const [showHeartAnimation, setShowHeartAnimation] = useState(false);
    const [showVolumeIcon, setShowVolumeIcon] = useState(false);
    const [isPaused, setIsPaused] = useState(false);
    const [showComments, setShowComments] = useState(false);
    
    // Scrubber State
    const [progress, setProgress] = useState(0);
    const [isSeeking, setIsSeeking] = useState(false);
    
    const videoRef = useRef<HTMLVideoElement>(null);
    const clickTimeoutRef = useRef<any>(null);
    const volumeIconTimer = useRef<number | null>(null);
    const longPressTimer = useRef<any>(null);
    const isLongPressingRef = useRef(false);
    
    // Fix for Ghost Clicks: Track last touch time to ignore subsequent mouse events
    const lastTouchTimeRef = useRef(0);
    
    // Smart Playback Logic
    useEffect(() => {
        if (videoRef.current) {
            if (isActive && !isPaused && !isSeeking) {
                const playPromise = videoRef.current.play();
                if (playPromise !== undefined) {
                    playPromise.catch(error => {
                        // Auto-play prevented
                    });
                }
            } else {
                videoRef.current.pause();
                if (!isActive) {
                    videoRef.current.currentTime = 0;
                }
            }
        }
    }, [isActive, isPaused, isSeeking]);

    // Time Update for Progress Bar
    useEffect(() => {
        const video = videoRef.current;
        if (!video) return;

        const handleTimeUpdate = () => {
            if (!isSeeking && video.duration > 0) {
                setProgress((video.currentTime / video.duration) * 100);
            }
        };

        video.addEventListener('timeupdate', handleTimeUpdate);
        return () => video.removeEventListener('timeupdate', handleTimeUpdate);
    }, [isSeeking]);

    // Sync Mute State
    useEffect(() => {
        if (videoRef.current) {
            videoRef.current.muted = isMuted;
        }
    }, [isMuted]);
    
    // --- HANDLERS ---

    // 1. Seek Logic (Scrubber)
    const handleSeekStart = (e: React.TouchEvent | React.MouseEvent) => {
        e.stopPropagation();
        setIsSeeking(true);
        if (videoRef.current) videoRef.current.pause();
    };

    const handleSeekMove = (e: React.TouchEvent | React.MouseEvent) => {
        e.stopPropagation();
        if (!isSeeking || !videoRef.current) return;
        
        const bar = e.currentTarget as HTMLElement;
        const rect = bar.getBoundingClientRect();
        let clientX;
        
        if ('touches' in e) {
            clientX = e.touches[0].clientX;
        } else {
            clientX = (e as React.MouseEvent).clientX;
        }

        // Calculate new time
        const percentage = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
        setProgress(percentage * 100);
        videoRef.current.currentTime = percentage * videoRef.current.duration;
    };

    const handleSeekEnd = (e: React.TouchEvent | React.MouseEvent) => {
        e.stopPropagation();
        setIsSeeking(false);
        if (videoRef.current && isActive) videoRef.current.play();
    };

    // 2. Press & Hold Logic (Pause) + Tap Logic (Mute/Like)
    
    const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
        // Common logic for both mouse and touch down
        isLongPressingRef.current = false;
        longPressTimer.current = setTimeout(() => {
            isLongPressingRef.current = true;
            setIsPaused(true); // Pause video visually
        }, 200); // 200ms threshold for "Hold"
    };

    const handlePointerUp = (e: React.MouseEvent | React.TouchEvent) => {
        // Common logic for both mouse and touch up
        clearTimeout(longPressTimer.current);

        if (isLongPressingRef.current) {
            // Was holding, now releasing
            setIsPaused(false); // Resume video
            isLongPressingRef.current = false;
            // Return early so we DON'T trigger tap logic
            return; 
        }
        
        // If not long press, it's a tap. Handle Tap Logic:
        handleTapInteraction(e);
    };

    // Separate event listeners to handle ghost clicks
    const handleTouchStart = (e: React.TouchEvent) => {
        lastTouchTimeRef.current = Date.now();
        handlePointerDown(e);
    };

    const handleMouseDown = (e: React.MouseEvent) => {
        // If a touch event happened recently (<800ms), ignore this mouse event
        if (Date.now() - lastTouchTimeRef.current < 800) return;
        handlePointerDown(e);
    };

    const handleTouchEnd = (e: React.TouchEvent) => {
        lastTouchTimeRef.current = Date.now();
        handlePointerUp(e);
    };

    const handleMouseUp = (e: React.MouseEvent) => {
        // If a touch event happened recently (<800ms), ignore this mouse event
        if (Date.now() - lastTouchTimeRef.current < 800) return;
        handlePointerUp(e);
    };


    const handleTapInteraction = (e: React.MouseEvent | React.TouchEvent) => {
        if (clickTimeoutRef.current) {
            // DOUBLE TAP DETECTED -> LIKE
            clearTimeout(clickTimeoutRef.current);
            clickTimeoutRef.current = null;
            
            if (!reel.isLiked) {
                handleLikeReel(reel.id);
            }
            setShowHeartAnimation(true);
            setTimeout(() => setShowHeartAnimation(false), 800);
        } else {
            // FIRST TAP DETECTED -> Wait for potential second
            clickTimeoutRef.current = setTimeout(() => {
                clickTimeoutRef.current = null;
                
                // SINGLE TAP ACTION -> TOGGLE MUTE
                setIsMuted(prev => !prev);
                setShowVolumeIcon(true);
                if (volumeIconTimer.current) clearTimeout(volumeIconTimer.current);
                volumeIconTimer.current = window.setTimeout(() => setShowVolumeIcon(false), 1000);
            }, 250); // 250ms wait time for double tap
        }
    };
    
    const toggleLike = (e: React.MouseEvent) => {
        e.stopPropagation();
        handleLikeReel(reel.id);
        if (!reel.isLiked) {
            setShowHeartAnimation(true);
            setTimeout(() => setShowHeartAnimation(false), 800);
        }
    };

    const handleCommentClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setShowComments(true);
    };

    const handleVideoVolumeClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsMuted(prev => !prev);
    };

    // Dummy function to handle adding comment
    const handleAddComment = (text: string) => {
        console.log("Adding comment:", text);
    };

    const author = findUser(reel.user, users);

    return (
        <section 
            className="h-full w-full snap-start relative bg-transparent overflow-hidden select-none touch-pan-y"
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
        >
            <video
                ref={videoRef}
                className="absolute top-0 left-0 w-full h-full object-cover"
                src={reel.videoSrc}
                loop 
                playsInline
            />
            
            {/* Heart Animation */}
            {showHeartAnimation && (
                <div className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none">
                    <svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 24 24" fill="#ef4444" stroke="none" className="animate-like drop-shadow-2xl"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                </div>
            )}

            {/* Pause Indicator */}
            {isPaused && (
                <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none bg-black/20 backdrop-blur-[1px]">
                    <div className="bg-black/40 p-4 rounded-full animate-scaleIn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="white"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>
                    </div>
                </div>
            )}
            
             {/* Volume Icon Overlay */}
             {showVolumeIcon && (
                <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none animate-fadeIn">
                    <div className="bg-black/50 p-4 rounded-full backdrop-blur-sm border border-white/10">
                         {isMuted ? <svg width="32" height="32" viewBox="0 0 24 24" fill="white"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg> 
                         : <svg width="32" height="32" viewBox="0 0 24 24" fill="white"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>}
                    </div>
                </div>
            )}

            {/* Bottom Overlay Gradient */}
            <div className="absolute inset-0 flex flex-col justify-end pointer-events-none">
                <div className="w-full h-1/2 bg-gradient-to-t from-black/90 via-black/40 to-transparent"></div>
            </div>

            {/* Controls Overlay */}
            <div className="absolute bottom-0 left-0 w-full px-4 pb-safe z-20 pointer-events-none">
                
                <div className="flex justify-between items-end pointer-events-auto mb-4">
                    {/* Left Side: User Info & Caption */}
                    <div className="flex-1 text-white space-y-3 pb-2 pr-12">
                         <div className="flex items-center gap-3 cursor-pointer">
                            <div onClick={() => viewUserProfile(author!)} className="relative">
                                <img src={author?.avatarImage} alt={reel.user} className="w-10 h-10 rounded-full border border-white/50 shadow-md"/>
                                {/* Follow Plus Button */}
                                {!currentUser.following.includes(reel.user) && reel.user !== currentUser.username && (
                                    <div className="absolute -bottom-1 -right-1 bg-emerald-500 rounded-full w-4 h-4 flex items-center justify-center border border-black" onClick={(e) => {e.stopPropagation(); handleToggleFollow(reel.user);}}>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="4"><path d="M12 5v14M5 12h14"/></svg>
                                    </div>
                                )}
                            </div>
                            <div className="flex flex-col">
                                <div className="flex items-center flex-wrap gap-1">
                                    <span onClick={() => viewUserProfile(author!)} className="font-bold text-sm shadow-black drop-shadow-md hover:underline">{reel.user}</span>
                                    {reel.taggedUsers && reel.taggedUsers.length > 0 && (
                                        <>
                                            <span className="text-xs font-normal opacity-80">with</span>
                                            {reel.taggedUsers.map(username => (
                                                <span 
                                                    key={username}
                                                    className="font-bold text-sm hover:underline cursor-pointer"
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        const u = findUser(username, users);
                                                        if (u) viewUserProfile(u);
                                                    }}
                                                >
                                                    @{username}
                                                </span>
                                            ))}
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                        
                        <div className="space-y-1">
                            <p className="text-sm text-slate-100 drop-shadow-md font-light leading-snug line-clamp-2">
                                {reel.caption}
                            </p>
                            <div className="flex items-center gap-2 text-xs text-slate-300 mt-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="animate-spin-slow"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
                                <span className="truncate max-w-[150px]">Original Audio • {reel.user}</span>
                            </div>
                        </div>
                    </div>
                    
                    {/* Right Side: Action Buttons */}
                    <div className="flex flex-col items-center space-y-5 pb-2">
                         {/* Explicit Mute Button for accessibility */}
                         <button onClick={handleVideoVolumeClick} className="flex flex-col items-center gap-1 group">
                            {isMuted ? 
                                <svg width="28" height="28" viewBox="0 0 24 24" fill="white" stroke="none" className="drop-shadow-lg"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg> 
                                : 
                                <svg width="28" height="28" viewBox="0 0 24 24" fill="white" stroke="none" className="drop-shadow-lg"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
                            }
                         </button>

                        <button onClick={toggleLike} className="flex flex-col items-center gap-1 group">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill={reel.isLiked ? "#ef4444" : "white"} stroke={reel.isLiked ? "#ef4444" : "none"} className={`drop-shadow-lg transition-transform duration-200 ${reel.isLiked ? 'scale-110' : 'group-hover:scale-110'}`}><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                            <span className="text-xs font-medium text-white shadow-black drop-shadow-md">{reel.likes}</span>
                        </button>
                        <button onClick={handleCommentClick} className="flex flex-col items-center gap-1 group">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="white" stroke="none" className="drop-shadow-lg group-hover:scale-110 transition-transform"><path d="M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18zM18 14H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>
                            <span className="text-xs font-medium text-white shadow-black drop-shadow-md">{reel.comments.length}</span>
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); openModal(ModalType.SharePost, { mediaUrl: reel.videoSrc, author: reel.user }); }} className="flex flex-col items-center gap-1 group">
                             <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-lg group-hover:scale-110 transition-transform"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                             <span className="text-xs font-medium text-white shadow-black drop-shadow-md">Share</span>
                        </button>
                    </div>
                </div>

                {/* Interactive Thin Scrubber */}
                <div 
                    className="absolute bottom-0 left-0 right-0 h-3 z-50 cursor-pointer flex items-end pointer-events-auto group"
                    onMouseDown={handleSeekStart}
                    onMouseMove={handleSeekMove}
                    onMouseUp={handleSeekEnd}
                    onMouseLeave={handleSeekEnd}
                    onTouchStart={handleSeekStart}
                    onTouchMove={handleSeekMove}
                    onTouchEnd={handleSeekEnd}
                >
                    <div className="w-full h-[1.5px] bg-white/20 relative group-hover:h-[4px] transition-all duration-200">
                        <div 
                            className="h-full bg-white relative transition-all duration-75 linear"
                            style={{ width: `${progress}%` }}
                        >
                            {/* Scrubber Knob (Only visible when interacting) */}
                            {isSeeking && (
                                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-lg scale-100 transition-transform"></div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* Comments Overlay */}
            <CommentsOverlay 
                isOpen={showComments}
                onClose={() => setShowComments(false)}
                comments={reel.comments}
                currentUser={currentUser}
                users={users}
                onAddComment={handleAddComment}
                openModal={openModal}
            />
        </section>
    );
};

export default ReelItem;
