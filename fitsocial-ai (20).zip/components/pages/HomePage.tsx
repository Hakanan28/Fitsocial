
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { ModalType, UserProfile, Post, Story, NotificationType, Group } from '../../types';
import { translateText } from '../../services/geminiService';
import { getRecommendations, RecommendationItem } from '../../services/recommendationService';
import { findUser } from '../../data/users';
import { initialGroupData } from '../../data/groups';
import { useTranslation } from '../../hooks/i18n';
import SuggestionCarousel from '../ui/SuggestionCarousel';

interface PostCardProps {
    post: Post;
    language: string;
    currentUser: UserProfile;
    handleToggleFollow: (username: string) => void;
    handleLikePost: (postId: number) => void;
    viewUserProfile: (user: UserProfile) => void;
    showNotification: (message: string, type?: 'success' | 'error') => void;
    openModal: (modal: ModalType, data?: any) => void;
    users: UserProfile[];
    onPostDownloaded: (author: string, mediaUrl: string) => void;
    onNavigateToReel: (reelId: number) => void;
}

const Scrubber: React.FC<{ videoRef: React.RefObject<HTMLVideoElement> }> = ({ videoRef }) => {
    const [progress, setProgress] = useState(0);
    const [isSeeking, setIsSeeking] = useState(false);

    useEffect(() => {
        const video = videoRef.current;
        if (!video) return;

        const handleTimeUpdate = () => {
            if (!isSeeking && video.duration > 0) {
                setProgress((video.currentTime / video.duration) * 100);
            }
        };

        video.addEventListener('timeupdate', handleTimeUpdate);
        return () => video.removeEventListener('timeupdate', handleTimeUpdate);
    }, [videoRef, isSeeking]);

    const handleSeek = (e: React.MouseEvent | React.TouchEvent) => {
        e.stopPropagation();
        if (!videoRef.current) return;
        
        const bar = e.currentTarget as HTMLElement;
        const rect = bar.getBoundingClientRect();
        let clientX;
        
        if ('touches' in e) {
            clientX = e.touches[0].clientX;
        } else {
            clientX = (e as React.MouseEvent).clientX;
        }

        const percentage = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
        setProgress(percentage * 100);
        videoRef.current.currentTime = percentage * videoRef.current.duration;
    };

    return (
        <div 
            className="absolute bottom-0 left-0 right-0 h-3 z-40 cursor-pointer flex items-end group"
            onMouseDown={(e) => { setIsSeeking(true); handleSeek(e); }}
            onMouseMove={(e) => isSeeking && handleSeek(e)}
            onMouseUp={() => setIsSeeking(false)}
            onMouseLeave={() => setIsSeeking(false)}
            onTouchStart={(e) => { setIsSeeking(true); handleSeek(e); }}
            onTouchMove={(e) => isSeeking && handleSeek(e)}
            onTouchEnd={() => setIsSeeking(false)}
            onClick={(e) => e.stopPropagation()}
        >
            <div className="w-full h-[2px] bg-white/20 relative group-hover:h-[4px] transition-all duration-200">
                <div 
                    className="h-full bg-white relative"
                    style={{ width: `${progress}%` }}
                >
                </div>
            </div>
        </div>
    );
}


const PostCard: React.FC<PostCardProps> = ({ post, language, currentUser, handleToggleFollow, handleLikePost, viewUserProfile, showNotification, openModal, users, onPostDownloaded, onNavigateToReel }) => {
    const { id, author, avatarText, mediaUrl, mediaType, caption, filter, location, taggedUsers, likes, comments, isLiked, allowDownload, type, powDetails, imageTags } = post;
    const { t } = useTranslation();

    const [isTranslated, setIsTranslated] = useState(false);
    const [translatedCaption, setTranslatedCaption] = useState('');
    const [isTranslating, setIsTranslating] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isMuted, setIsMuted] = useState(true);
    const [showHeartAnimation, setShowHeartAnimation] = useState(false);
    
    const videoRef = useRef<HTMLVideoElement>(null);
    
    // New state for Tag visibility
    const [showTags, setShowTags] = useState(false);
    
    const clickTimeoutRef = useRef<any>(null);
    
    const supportedLanguages: { [key: string]: string } = {
        en: 'English', es: 'Spanish', tr: 'Turkish', de: 'German', fr: 'French',
    };

    // Explicitly handle video mute state changes
    useEffect(() => {
        if (videoRef.current) {
            videoRef.current.muted = isMuted;
        }
    }, [isMuted]);

    const handleTranslate = async () => {
        if (isTranslated) {
            setIsTranslated(false);
            return;
        }
        if (translatedCaption) {
            setIsTranslated(true);
            return;
        }
        setIsTranslating(true);
        try {
            const targetLanguageName = supportedLanguages[language] || 'English';
            const translation = await translateText(caption, targetLanguageName);
            setTranslatedCaption(translation);
            setIsTranslated(true);
        } catch (error) {
            console.error("Translation failed:", error);
            setTranslatedCaption("Translation failed.");
        } finally {
            setIsTranslating(false);
        }
    };

    const handleViewProfile = (e: React.MouseEvent) => {
        e.stopPropagation();
        const user = findUser(author, users);
        if (user) viewUserProfile(user);
    };
    
    const handleTagClick = (e: React.MouseEvent, username: string) => {
        e.stopPropagation(); // Prevent post opening
        e.preventDefault();
        // Strip @ if present
        const cleanUsername = username.replace('@', '');
        const user = findUser(cleanUsername, users);
        if (user) {
            viewUserProfile(user);
        } else {
            showNotification("User not found", "error");
        }
    };

    const handleLike = (e: React.MouseEvent) => {
        e.stopPropagation();
        handleLikePost(id);
    };
    
    const handleMediaClick = (e: React.MouseEvent) => {
        // If we clicked on a tag bubble inside, don't trigger media click
        e.stopPropagation();
        
        if (clickTimeoutRef.current) {
            // Double click detected
            clearTimeout(clickTimeoutRef.current);
            clickTimeoutRef.current = null;
            
            if (!isLiked) {
                handleLikePost(id);
            }
            setShowHeartAnimation(true);
            setTimeout(() => setShowHeartAnimation(false), 800);
        } else {
            // Potential single click
            clickTimeoutRef.current = setTimeout(() => {
                clickTimeoutRef.current = null;
                
                if (type === 'reel') {
                    onNavigateToReel(id);
                    return;
                }

                if(type === 'proofOfWorkout'){
                     openModal(ModalType.ProofOfWorkoutDetail, { ...post, id: id.toString() });
                } else {
                     openModal(ModalType.PostDetail, post);
                }
            }, 250);
        }
    };
    
    const isFollowing = currentUser.following.includes(author);
    const isOwnPost = currentUser.username === author;

    const handleVideoVolumeClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsMuted(prev => !prev);
    };
    
    // Helper to render caption with clickable tags
    const renderCaption = (text: string) => {
        const parts = text.split(/(@\w+)/g);
        return (
            <>
                {parts.map((part, i) => {
                    if (part.startsWith('@')) {
                        return (
                            <span 
                                key={i} 
                                onClick={(e) => handleTagClick(e, part)} 
                                className="text-blue-400 font-semibold cursor-pointer hover:underline ml-1"
                            >
                                {part}
                            </span>
                        );
                    }
                    return part;
                })}
            </>
        );
    };

    // Render special Proof of Workout Card
    if (type === 'proofOfWorkout' && powDetails) {
        return (
            <article className="bg-[#18181b] rounded-2xl overflow-hidden mb-8 border border-white/10 relative group shadow-xl w-full">
                {/* Header */}
                <div className="flex items-center px-4 py-3 justify-between bg-[#18181b] border-b border-white/5">
                    <div onClick={(e) => {e.stopPropagation(); handleViewProfile(e)}} className="flex items-center cursor-pointer gap-2 pointer-events-auto">
                        <div className="relative p-[1.5px] bg-gradient-to-tr from-emerald-500 to-green-300 rounded-full">
                            <img className="w-9 h-9 rounded-full object-cover border border-black" src={`https://placehold.co/100x100/FBC02D/white?text=${avatarText}`} alt={`${author}`} />
                        </div>
                        <div className="flex flex-col">
                            <span className="font-bold text-white text-sm">{author}</span>
                            <span className="text-[10px] text-emerald-400 font-bold tracking-wide uppercase">Verified Workout</span>
                        </div>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); setIsMenuOpen(!isMenuOpen); }} className="text-gray-400 p-2 hover:text-white rounded-full transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
                    </button>
                </div>

                {/* Content */}
                <div onClick={handleMediaClick} className="aspect-[4/5] bg-gray-900 relative flex items-center justify-center cursor-pointer overflow-hidden">
                     {mediaType === 'video' ? (
                         <video src={mediaUrl} muted className="absolute inset-0 w-full h-full object-cover blur-xl opacity-40 scale-110" />
                     ) : (
                         <img src={mediaUrl} className="absolute inset-0 w-full h-full object-cover blur-xl opacity-40 scale-110" alt="" />
                     )}

                    {mediaType === 'video' ? (
                        <>
                            <video 
                                ref={videoRef}
                                src={mediaUrl} 
                                muted={isMuted} 
                                loop 
                                autoPlay 
                                playsInline 
                                className={`relative z-10 w-full h-full object-contain ${filter || ''}`} 
                            />
                            <Scrubber videoRef={videoRef} />
                        </>
                    ) : (
                        <img className={`relative z-10 w-full h-full object-contain ${filter || ''}`} src={mediaUrl} alt="Workout" />
                    )}
                    
                    {mediaType === 'video' && (
                        <button onClick={handleVideoVolumeClick} className="absolute top-3 right-3 bg-black/60 p-2 rounded-full text-white hover:bg-black/80 transition-colors z-30 pointer-events-auto">
                            {isMuted ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="23" x2="17" y1="9" y2="15"/><line x1="17" x2="23" y1="9" y2="15"/></svg> : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>}
                        </button>
                    )}

                    <div className="absolute bottom-4 left-4 flex flex-wrap gap-2 z-20 pointer-events-none">
                        <div className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 flex items-center gap-2 shadow-lg">
                            <span className="text-[10px] text-gray-300 font-bold uppercase tracking-wider">TIME</span>
                            <span className="text-white text-xs font-bold">{powDetails.duration.hours}h {powDetails.duration.minutes}m</span>
                        </div>
                        <div className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 flex items-center gap-2 shadow-lg">
                            <span className="text-[10px] text-gray-300 font-bold uppercase tracking-wider">EFFORT</span>
                            <span className="text-emerald-400 text-xs font-bold">{powDetails.effort}/5</span>
                        </div>
                    </div>
                     
                      {showHeartAnimation && (
                        <div className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none">
                            <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="#ef4444" stroke="none" className="animate-like drop-shadow-2xl opacity-90"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                        </div>
                    )}
                </div>

                {/* Action Bar */}
                <div className="px-4 py-3 bg-[#18181b] border-t border-white/5">
                    <div className="flex items-center gap-5 mb-2.5">
                         <button onClick={handleLike} className="hover:scale-110 transition-transform active:scale-95">
                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill={isLiked ? "#ef4444" : "none"} stroke={isLiked ? "#ef4444" : "white"} strokeWidth="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); openModal(ModalType.Comments, { id, author, type: 'pow' }); }} className="hover:scale-110 transition-transform active:scale-95">
                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="hover:text-gray-300"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                        </button>
                        <button onClick={() => openModal(ModalType.SharePost, { mediaUrl, author })} className="hover:scale-110 transition-transform active:scale-95">
                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                        </button>
                    </div>
                    
                    <div className="text-sm font-bold text-white mb-1.5">{likes.toLocaleString()} likes</div>
                    
                    <div className="text-sm text-gray-300 leading-relaxed mb-1">
                        <span className="font-bold mr-1.5 text-white cursor-pointer" onClick={handleViewProfile}>{author}</span>
                        <span className="text-emerald-400 font-bold mr-1">[{powDetails.activity}]</span>
                        {renderCaption(caption)}
                    </div>
                    
                    {comments.length > 0 && (
                         <button onClick={(e) => { e.stopPropagation(); openModal(ModalType.Comments, { id, author, type: 'pow' }); }} className="text-xs text-gray-500 font-medium mt-1 hover:text-gray-300">
                            View all {comments.length} comments
                        </button>
                    )}
                </div>
            </article>
        );
    }

    // Standard Post & Reel Post
    return (
    <article className="bg-[#18181b] rounded-2xl overflow-hidden mb-8 border border-white/10 shadow-xl w-full">
        {/* Header */}
        <div className="flex items-center px-4 py-3 justify-between">
            <div onClick={handleViewProfile} className="flex items-center cursor-pointer gap-3">
                 <div className="relative p-[2px] bg-gradient-to-tr from-yellow-500 to-red-500 rounded-full">
                    <img className="w-9 h-9 rounded-full object-cover border border-black" src={`https://placehold.co/100x100/FBC02D/white?text=${avatarText}`} alt={`${author}`} />
                </div>
                <div className="flex flex-col justify-center">
                    <span className="font-bold text-white text-sm leading-none">{author}</span>
                    {location && <p className="text-[10px] text-gray-400 mt-0.5">{location}</p>}
                </div>
            </div>
            <div className="flex items-center gap-3">
                {!isOwnPost && (
                    <button onClick={() => handleToggleFollow(author)} className={`text-[10px] font-bold px-4 py-1.5 rounded-full transition-all border ${isFollowing ? 'border-white/20 text-white' : 'bg-emerald-500 border-transparent text-black hover:bg-emerald-400'}`}>
                        {isFollowing ? 'Following' : 'Follow'}
                    </button>
                )}
                 <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-400 p-2 hover:text-white rounded-full transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
                </button>
            </div>
        </div>

        {/* Media Content */}
        <div
            onClick={handleMediaClick}
            className="aspect-[4/5] bg-gray-900 relative flex items-center justify-center group overflow-hidden cursor-pointer border-t border-b border-white/5"
        >
            {mediaType === 'video' ? (
                 <video src={mediaUrl} muted className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-30 scale-110" />
            ) : (
                 <img src={mediaUrl} className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-30 scale-110" alt="" />
            )}

            {mediaType === 'video' ? (
                <>
                    <video 
                        ref={videoRef}
                        src={mediaUrl} 
                        muted={isMuted} 
                        loop 
                        autoPlay 
                        playsInline 
                        className={`relative z-10 w-full h-full object-contain ${filter || ''}`} 
                    />
                    <Scrubber videoRef={videoRef} />
                    <button onClick={handleVideoVolumeClick} className="absolute bottom-4 right-4 bg-black/60 p-2 rounded-full text-white hover:bg-black/80 transition-colors z-20">
                        {isMuted ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="23" x2="17" y1="9" y2="15"/><line x1="17" x2="23" y1="9" y2="15"/></svg> : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>}
                    </button>
                </>
            ) : (
                <img className={`relative z-10 w-full h-full object-contain ${filter || ''}`} src={mediaUrl} alt="Post Content" />
            )}
            
             {/* Tag Button & Overlays */}
             {(imageTags || (taggedUsers && taggedUsers.length > 0)) && (
                <>
                    <button 
                        className={`absolute bottom-3 left-3 z-30 bg-black/60 hover:bg-black/80 p-1.5 rounded-full text-white backdrop-blur-md border border-white/10 transition-all ${showTags ? 'bg-white text-black hover:bg-gray-200' : ''}`}
                        onClick={(e) => { e.stopPropagation(); setShowTags(!showTags); }}
                        aria-label="Show tags"
                    >
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </button>

                    {showTags && (
                        <div className="absolute inset-0 z-20 pointer-events-none">
                             {/* Prefer coordinate based tags if available */}
                             {imageTags && imageTags.length > 0 ? (
                                 imageTags.map((tag, idx) => (
                                     <div 
                                        key={idx}
                                        className="absolute bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-lg flex items-center gap-2 cursor-pointer border border-white/20 animate-scaleIn pointer-events-auto hover:scale-105 transition-transform shadow-lg transform -translate-x-1/2 -translate-y-1/2"
                                        style={{ left: `${tag.x}%`, top: `${tag.y}%` }}
                                        onClick={(e) => handleTagClick(e, tag.username)}
                                     >
                                        <span className="text-xs font-bold text-white">{tag.username}</span>
                                        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-black/80 rotate-45 border-r border-b border-white/20"></div>
                                     </div>
                                 ))
                             ) : (
                                 /* Fallback for legacy tags (list style) */
                                 taggedUsers?.map((username, idx) => {
                                    const taggedUser = findUser(username, users);
                                    const topPos = 50 + (idx - (taggedUsers.length - 1) / 2) * 15; 
                                    
                                    return (
                                         <div 
                                            key={username}
                                            className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-lg flex items-center gap-2 cursor-pointer border border-white/20 animate-fadeIn pointer-events-auto hover:scale-105 transition-transform shadow-lg"
                                            style={{ top: `${topPos}%` }}
                                            onClick={(e) => handleTagClick(e, username)}
                                         >
                                            {taggedUser && (
                                                <div className="relative w-6 h-6">
                                                    <img src={taggedUser.avatarImage} className="w-full h-full rounded-full object-cover border border-white/50" alt={username} />
                                                </div>
                                            )}
                                            <span className="text-xs font-bold text-white">{username}</span>
                                            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-black/80 rotate-45 border-r border-b border-white/20"></div>
                                         </div>
                                    )
                                 })
                             )}
                        </div>
                    )}
                </>
            )}

            {type === 'reel' && (
                <div className="absolute top-3 right-3 z-20 bg-black/60 p-1.5 rounded-full text-white animate-pulse">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.2 6 3 11l-.9-2.4c-.3-1.1.4-2.2 1.5-2.5l13-3.2c-1.1-.3-2.2.4-2.5 1.5L20.2 6Z"/><path d="m7 11 13 4.8.9 2.4c.3 1.1-.4 2.2-1.5 2.5l-13 3.2c-1.1.3-2.2-.4-2.5-1.5L3 11Z"/></svg>
                </div>
            )}
            
            {showHeartAnimation && (
                <div className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none">
                    <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="#ef4444" stroke="none" className="animate-like drop-shadow-2xl opacity-90"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                </div>
            )}
        </div>
        
        {/* Action Bar */}
        <div className="px-4 py-3">
            <div className="flex items-center gap-5 mb-3">
                <button onClick={handleLike} className="hover:scale-110 transition-transform active:scale-95">
                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill={isLiked ? "#ef4444" : "none"} stroke={isLiked ? "#ef4444" : "white"} strokeWidth="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                </button>
                <button onClick={() => openModal(ModalType.Comments, { id, author, type: type === 'reel' ? 'reel' : 'post' })} className="hover:scale-110 transition-transform active:scale-95">
                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                </button>
                <button onClick={() => openModal(ModalType.SharePost, { mediaUrl, author })} className="hover:scale-110 transition-transform active:scale-95">
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                </button>
            </div>
            
            <div className="text-sm font-bold text-white mb-1.5">{likes.toLocaleString()} likes</div>
            
            <div className="text-sm text-gray-300 leading-relaxed">
                <span className="font-bold mr-2 text-white cursor-pointer" onClick={handleViewProfile}>{author}</span>
                {isTranslated ? renderCaption(translatedCaption) : renderCaption(caption)}
            </div>
             {caption && (
                <button onClick={handleTranslate} disabled={isTranslating} className="text-[10px] text-gray-500 uppercase font-bold mt-2 hover:text-gray-300 tracking-wide">
                    {isTranslating ? 'Translating...' : isTranslated ? 'See Original' : 'Translate'}
                </button>
            )}
            
            {comments.length > 0 && (
                 <button onClick={() => openModal(ModalType.Comments, { id, author, type: type === 'reel' ? 'reel' : 'post' })} className="text-xs text-gray-500 mt-2 font-medium hover:text-gray-300">
                    View all {comments.length} comments
                </button>
            )}
        </div>
    </article>
    );
};

// ... HomePage Component ...
interface HomePageProps {
    posts: Post[];
    stories: Record<string, Story[]>;
    openModal: (modal: ModalType, data?: any) => void;
    language: string;
    currentUser: UserProfile;
    handleToggleFollow: (username: string) => void;
    handleLikePost: (postId: number) => void;
    viewUserProfile: (user: UserProfile) => void;
    showNotification: (message: string, type?: 'success' | 'error') => void;
    users: UserProfile[];
    onPostDownloaded: (author: string, mediaUrl: string) => void;
    onNavigateToReel: (reelId: number) => void;
}

const HomePage: React.FC<HomePageProps> = ({ posts, stories, openModal, language, currentUser, handleToggleFollow, handleLikePost, viewUserProfile, showNotification, users, onPostDownloaded, onNavigateToReel }) => {
    const [activeTab, setActiveTab] = useState<'forYou' | 'following'>('forYou');
    const { t } = useTranslation();
    
    // Recommendations state
    const [recommendations, setRecommendations] = useState<RecommendationItem[]>([]);
    const [showSuggestions, setShowSuggestions] = useState(true);

    // Generate recommendations on mount
    useEffect(() => {
        // In a real app, this would be an API call
        const recs = getRecommendations(currentUser, users, initialGroupData);
        setRecommendations(recs);
    }, [currentUser, users]);

    const followingPosts = posts.filter(post => currentUser.following.includes(post.author));

    // Prepare story data - Ensuring reactivity
    const myStory = stories[currentUser.username];
    const hasMyStory = myStory && myStory.length > 0;

    const otherStories = Object.keys(stories)
        .filter(username => username !== currentUser.username)
        .map(username => ({
            username,
            stories: stories[username],
            user: users.find(u => u.username === username)
        }))
        .filter(item => item.user && item.stories && item.stories.length > 0);
    
    return (
        <div id="page-home" className="space-y-0 pb-24 w-full">
            
            {/* 1. Stories Section (At the very top) */}
            <div className="relative pt-4 pb-4 overflow-hidden bg-gradient-to-b from-gray-900 via-[#101012] to-[#020617] border-b border-white/5">
                 {/* Background Glow Effect for Stories */}
                 <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-emerald-900/5 via-transparent to-blue-900/5 pointer-events-none"></div>
                 
                 <section className="relative z-10 flex space-x-4 overflow-x-auto px-4 scrollbar-hide items-center">
                    {/* Your Story Button */}
                    <div className="flex-shrink-0 flex flex-col items-center gap-1.5 cursor-pointer group" onClick={() => hasMyStory ? openModal(ModalType.StoryViewer, { stories: myStory, startIndex: 0 }) : openModal(ModalType.CreatePost)}>
                        <div className="relative">
                             <div className={`w-[74px] h-[74px] rounded-full p-[2px] ${hasMyStory ? 'bg-gradient-to-tr from-emerald-500 to-teal-400' : 'border-2 border-dashed border-gray-600 group-hover:border-gray-400'} transition-all`}>
                                <img className="w-full h-full rounded-full object-cover border-2 border-black" src={currentUser.avatarImage} alt="Your Story" />
                            </div>
                            {!hasMyStory && (
                                <div className="absolute bottom-0 right-0 w-6 h-6 bg-emerald-600 rounded-full border-2 border-black flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
                                    <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3"><path d="M12 5v14M5 12h14"/></svg>
                                </div>
                            )}
                        </div>
                        <span className="text-[11px] font-medium text-gray-400 group-hover:text-white transition-colors truncate w-16 text-center">{t('home.yourStory')}</span>
                    </div>

                    {/* Friends' Stories */}
                    {otherStories.map(({ username, stories, user }) => (
                        <div key={username} className="flex-shrink-0 flex flex-col items-center gap-1.5 cursor-pointer group" onClick={() => openModal(ModalType.StoryViewer, { stories: stories, startIndex: 0 })}>
                             <div className="w-[74px] h-[74px] rounded-full p-[2px] bg-gradient-to-tr from-emerald-500 to-blue-500 group-hover:scale-105 transition-transform shadow-[0_0_15px_rgba(16,185,129,0.15)]">
                                <img className="w-full h-full rounded-full object-cover border-2 border-black" src={user?.avatarImage} alt={username} />
                            </div>
                            <span className="text-[11px] font-medium text-gray-300 truncate w-16 text-center">{username}</span>
                        </div>
                    ))}
                 </section>
            </div>

            {/* 2. Feed Toggle Tabs (Sticky below stories) */}
            <div className="sticky top-0 z-30 w-full bg-[#0a0a0a]/90 backdrop-blur-xl border-b border-white/5 shadow-2xl transition-all duration-300">
                <div className="flex items-center justify-center py-4">
                    <div className="flex items-center bg-[#18181b] p-1.5 rounded-full border border-white/10 relative w-64 shadow-inner">
                         <button 
                            onClick={() => setActiveTab('forYou')} 
                            className={`flex-1 py-2.5 rounded-full text-sm font-bold transition-all duration-300 flex items-center justify-center relative z-10 ${
                                activeTab === 'forYou' 
                                    ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-black shadow-[0_0_15px_rgba(52,211,153,0.4)]' 
                                    : 'text-gray-400 hover:text-white'
                            }`}
                        >
                            {t('home.forYou')}
                        </button>
                        
                        <button 
                            onClick={() => setActiveTab('following')} 
                             className={`flex-1 py-2.5 rounded-full text-sm font-bold transition-all duration-300 flex items-center justify-center relative z-10 ${
                                activeTab === 'following' 
                                    ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-black shadow-[0_0_15px_rgba(52,211,153,0.4)]' 
                                    : 'text-gray-400 hover:text-white'
                            }`}
                        >
                            {t('common.following')}
                        </button>
                    </div>
                </div>
            </div>
            
            {/* 3. Feed Content */}
            <div className="space-y-6 px-0 md:px-4 w-full mt-4">
                {activeTab === 'forYou' ? (
                    posts.length > 0 ? posts.map((post, index) => (
                        <React.Fragment key={post.id}>
                            <PostCard post={post} openModal={openModal} language={language} currentUser={currentUser} handleToggleFollow={handleToggleFollow} handleLikePost={handleLikePost} viewUserProfile={viewUserProfile} showNotification={showNotification} users={users} onPostDownloaded={onPostDownloaded} onNavigateToReel={onNavigateToReel} />
                            
                            {/* Inject Suggestions after the 3rd post */}
                            {index === 2 && showSuggestions && recommendations.length > 0 && (
                                <SuggestionCarousel 
                                    suggestions={recommendations} 
                                    onFollow={handleToggleFollow} 
                                    onJoinGroup={(g) => openModal(ModalType.GroupJoin, g)}
                                    onClose={() => setShowSuggestions(false)}
                                    viewProfile={viewUserProfile}
                                />
                            )}
                        </React.Fragment>
                    )) : <div className="text-center py-24 text-slate-600 font-light">{t('home.emptyForYou.title')}</div>
                ) : (
                     followingPosts.length > 0 ? followingPosts.map(post => (
                        <PostCard key={post.id} post={post} openModal={openModal} language={language} currentUser={currentUser} handleToggleFollow={handleToggleFollow} handleLikePost={handleLikePost} viewUserProfile={viewUserProfile} showNotification={showNotification} users={users} onPostDownloaded={onPostDownloaded} onNavigateToReel={onNavigateToReel} />
                    )) : <div className="text-center py-24 text-slate-600 font-light">{t('home.emptyFeed.title')}</div>
                )}
            </div>
        </div>
    );
};

export default HomePage;
