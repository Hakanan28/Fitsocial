
import React, { useState, useMemo } from 'react';
import { ModalType, Coin, NFT } from '../../types';
import { useTranslation } from '../../hooks/i18n';

interface WalletPageProps {
    openModal: (modal: ModalType, data?: any) => void;
    coins: Coin[];
    nfts: NFT[];
}

type WalletTab = 'tokens' | 'nfts' | 'transactions';

const WalletPage: React.FC<WalletPageProps> = ({ openModal, coins, nfts }) => {
    const { t } = useTranslation();
    const [activeTab, setActiveTab] = useState<WalletTab>('tokens');
    
    const totalPortfolioValue = coins.reduce((acc, coin) => acc + coin.balance * coin.price, 0);
    
    // Collect all transactions from all coins and sort by date
    const allTransactions = useMemo(() => {
        const txs = coins.flatMap(coin => coin.transactions.map(tx => ({...tx, symbol: coin.symbol, logo: coin.logoUrl})));
        return txs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [coins]);

    const renderTokens = () => (
        <div className="space-y-3">
            {coins.map(coin => {
                const value = coin.balance * coin.price;
                return (
                    <div key={coin.id} onClick={() => openModal(ModalType.CoinDetails, coin)} className="flex items-center p-4 bg-[#1E1E1E] rounded-2xl border border-white/5 cursor-pointer hover:border-green-500/30 transition-all group">
                        <div className="relative">
                            <img src={coin.logoUrl} alt={coin.name} className="w-12 h-12 rounded-full bg-white/5 p-1" />
                            <div className="absolute -bottom-1 -right-1 bg-[#1E1E1E] rounded-full p-0.5">
                                <div className={`w-3 h-3 rounded-full ${coin.priceChange24h >= 0 ? 'bg-green-500' : 'bg-red-500'}`}></div>
                            </div>
                        </div>
                        <div className="ml-4 flex-1">
                            <div className="flex justify-between items-center">
                                <h3 className="font-bold text-white text-base">{coin.symbol}</h3>
                                <span className="font-bold text-white">${value.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                            </div>
                            <div className="flex justify-between items-center mt-1">
                                <span className="text-xs text-gray-400 font-mono">{coin.balance.toFixed(4)}</span>
                                <span className={`text-xs font-medium ${coin.priceChange24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                    {coin.priceChange24h >= 0 ? '+' : ''}{coin.priceChange24h.toFixed(2)}%
                                </span>
                            </div>
                        </div>
                    </div>
                );
            })}
            <button onClick={() => openModal(ModalType.AddToken)} className="w-full mt-4 py-3 rounded-xl border border-dashed border-gray-600 text-gray-400 hover:text-green-400 hover:border-green-500 transition-all flex items-center justify-center gap-2 text-sm font-bold">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><line x1="12" x2="12" y1="5" y2="19"/><line x1="5" x2="19" y1="12" y2="12"/></svg>
                {t('modals.wallet_add_token.title')}
            </button>
        </div>
    );

    const renderNFTs = () => (
        <div className="grid grid-cols-2 gap-3">
            {nfts.map(nft => (
                <div key={nft.id} onClick={() => openModal(ModalType.NftDetails, nft)} className="bg-[#1E1E1E] rounded-xl overflow-hidden border border-white/5 group cursor-pointer hover:border-purple-500/50 transition-all">
                    <div className="aspect-square overflow-hidden">
                        <img src={nft.imageUrl} alt={nft.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"/>
                    </div>
                    <div className="p-3">
                        <p className="text-[10px] text-purple-400 uppercase font-bold tracking-wider mb-1 truncate">{nft.collection}</p>
                        <h4 className="font-bold text-white text-xs truncate">{nft.name}</h4>
                    </div>
                </div>
            ))}
             {nfts.length === 0 && (
                <div className="col-span-2 text-center py-12 bg-[#1E1E1E] rounded-xl border border-dashed border-gray-700">
                    <span className="text-4xl block mb-2 opacity-50">🖼️</span>
                    <p className="text-gray-500 text-sm">Your gallery is empty.</p>
                </div>
            )}
        </div>
    );

    const renderTransactions = () => (
        <div className="space-y-3">
            {allTransactions.map(tx => (
                <div key={tx.id} className="flex items-center justify-between p-3 bg-[#1E1E1E] rounded-xl border border-white/5">
                    <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${tx.type === 'received' ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'}`}>
                            {tx.type === 'received' ? (
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14"/><path d="m19 12-7 7-7-7"/></svg>
                            ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></svg>
                            )}
                        </div>
                        <div>
                            <p className="text-sm font-bold text-white capitalize">{tx.type}</p>
                            <p className="text-[10px] text-gray-500">{tx.date}</p>
                        </div>
                    </div>
                    <div className="text-right">
                        <p className={`text-sm font-bold ${tx.type === 'received' ? 'text-green-400' : 'text-white'}`}>
                            {tx.type === 'received' ? '+' : '-'}{tx.amount.toFixed(4)} {tx.symbol}
                        </p>
                        <p className="text-[10px] text-gray-500 font-mono truncate w-24 ml-auto">{tx.address}</p>
                    </div>
                </div>
            ))}
            {allTransactions.length === 0 && (
                <p className="text-center text-gray-500 py-8">No recent transactions.</p>
            )}
        </div>
    );

    return (
        <div className="p-4 space-y-6 min-h-screen pb-20">
            {/* Portfolio Header */}
            <section className="p-6 bg-[#1E1E1E] rounded-2xl border border-white/5 shadow-lg text-center">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Total Balance</p>
                <h1 className="text-3xl font-black text-white tracking-tight mb-6">
                    ${totalPortfolioValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </h1>
                
                <div className="flex gap-3">
                    <button onClick={() => openModal(ModalType.SendCoin)} className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-xl font-bold text-sm shadow-lg transition-all flex items-center justify-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg>
                        Send
                    </button>
                    <button onClick={() => openModal(ModalType.ReceiveCoin)} className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-xl font-bold text-sm border border-white/10 transition-all flex items-center justify-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="7" y1="7" x2="17" y2="17"/><polyline points="17 7 17 17 7 17"/></svg>
                        Receive
                    </button>
                </div>
            </section>

            {/* Tabs & Content */}
            <div>
                <div className="flex p-1 bg-[#121212] rounded-xl border border-white/5 mb-4">
                    <button className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${activeTab === 'tokens' ? 'bg-gray-800 text-white shadow' : 'text-gray-500 hover:text-gray-300'}`} onClick={() => setActiveTab('tokens')}>Tokens</button>
                    <button className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${activeTab === 'nfts' ? 'bg-gray-800 text-white shadow' : 'text-gray-500 hover:text-gray-300'}`} onClick={() => setActiveTab('nfts')}>Collectibles</button>
                    <button className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${activeTab === 'transactions' ? 'bg-gray-800 text-white shadow' : 'text-gray-500 hover:text-gray-300'}`} onClick={() => setActiveTab('transactions')}>History</button>
                </div>
                
                <div className="animate-fadeIn min-h-[300px]">
                    {activeTab === 'tokens' && renderTokens()}
                    {activeTab === 'nfts' && renderNFTs()}
                    {activeTab === 'transactions' && renderTransactions()}
                </div>
            </div>
        </div>
    );
};

export default WalletPage;
