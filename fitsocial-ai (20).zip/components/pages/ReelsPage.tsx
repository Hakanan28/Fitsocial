import React, { useMemo, useEffect, useRef, useState } from 'react';
import { ModalType, Reel, UserProfile } from '../../types';
import ReelItem from './VideoPage';
import { useTranslation } from '../../hooks/i18n';
import { getReelsFeed } from '../../services/feedService';

interface ReelsPageProps {
    language: string;
    openModal: (modal: ModalType, data?: any) => void;
    reels: Reel[];
    initialReelId?: number;
    customFeed?: Reel[] | null; // Allow passing a specific feed (e.g., from Explore)
    currentUser: UserProfile;
    handleToggleFollow: (username: string) => void;
    handleLikeReel: (reelId: number) => void;
    viewUserProfile: (user: UserProfile) => void;
    users: UserProfile[];
    onPostDownloaded: (author: string, mediaUrl: string) => void;
}

const ReelsPage: React.FC<ReelsPageProps> = ({ language, openModal, reels, initialReelId, customFeed, currentUser, handleToggleFollow, handleLikeReel, viewUserProfile, users, onPostDownloaded }) => {
    const { t } = useTranslation();
    const reelsContainerRef = useRef<HTMLDivElement>(null);
    const [activeReelId, setActiveReelId] = useState<number | null>(initialReelId || null);

    const sortedReels = useMemo(() => {
        if (customFeed && customFeed.length > 0) {
            return customFeed;
        }
        return getReelsFeed(currentUser, reels, users);
    }, [currentUser, reels, users, customFeed]);

    useEffect(() => {
        if (!activeReelId && sortedReels.length > 0) {
            setActiveReelId(sortedReels[0].id);
        }
    }, [sortedReels, activeReelId]);

    useEffect(() => {
        if (initialReelId) {
            // Short delay to allow rendering before scrolling
            const timer = setTimeout(() => {
                const element = document.getElementById(`reel-${initialReelId}`);
                if (element) {
                    element.scrollIntoView({ behavior: 'auto' });
                }
            }, 100);
            return () => clearTimeout(timer);
        }
    }, [initialReelId]);

    useEffect(() => {
        const observerOptions = {
            root: reelsContainerRef.current,
            threshold: 0.6,
        };

        const handleIntersection = (entries: IntersectionObserverEntry[]) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const reelId = Number(entry.target.getAttribute('data-reel-id'));
                    if (!isNaN(reelId)) {
                        setActiveReelId(reelId);
                    }
                }
            });
        };

        const observer = new IntersectionObserver(handleIntersection, observerOptions);

        const container = reelsContainerRef.current;
        if (container) {
            const reelElements = container.querySelectorAll('.reel-section');
            reelElements.forEach(el => observer.observe(el));
        }

        return () => {
            observer.disconnect();
        };
    }, [sortedReels]);

    return (
        <div className="absolute inset-0 w-full h-full bg-black z-0">
            <div 
                ref={reelsContainerRef} 
                id="reels-container" 
                className="w-full h-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide pb-[70px]"
                style={{ scrollBehavior: 'smooth' }}
            >
                {sortedReels.map(reel => (
                     <section 
                        key={reel.id} 
                        id={`reel-${reel.id}`} 
                        data-reel-id={reel.id}
                        className="w-full h-full snap-start relative bg-transparent flex items-center justify-center overflow-hidden reel-section"
                    >
                        <ReelItem 
                            reel={reel} 
                            language={language} 
                            openModal={openModal}
                            currentUser={currentUser}
                            handleToggleFollow={handleToggleFollow}
                            handleLikeReel={handleLikeReel}
                            viewUserProfile={viewUserProfile}
                            users={users}
                            onPostDownloaded={onPostDownloaded}
                            isActive={activeReelId === reel.id}
                        />
                    </section>
                ))}
            </div>

             {/* Create Reel Action Button - Bottom Left */}
             <div className="fixed bottom-24 left-4 z-50 pointer-events-none">
                <div className="pointer-events-auto">
                    <button
                        // FIX: Changed ModalType.CreateReel to ModalType.CreatePost
                        onClick={() => openModal(ModalType.CreatePost, { contentType: 'reel' })}
                        className="group flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 border border-white/20 shadow-[0_0_20px_rgba(236,72,153,0.4)] transition-all duration-300 hover:scale-110 active:scale-95"
                        aria-label="Create Reel"
                    >
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="group-hover:rotate-90 transition-transform duration-500"><path d="M12 5v14M5 12h14"/></svg>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ReelsPage;
