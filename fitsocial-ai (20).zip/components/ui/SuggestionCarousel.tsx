
import React from 'react';
import { UserProfile, Group } from '../../types';
import { RecommendationItem } from '../../services/recommendationService';

interface SuggestionCarouselProps {
    suggestions: RecommendationItem[];
    onFollow: (username: string) => void;
    onJoinGroup: (group: Group) => void;
    onClose: () => void;
    viewProfile: (user: UserProfile) => void;
}

const SuggestionCarousel: React.FC<SuggestionCarouselProps> = ({ suggestions, onFollow, onJoinGroup, onClose, viewProfile }) => {
    if (suggestions.length === 0) return null;

    return (
        <div className="py-4 mb-6 border-y border-white/5 bg-[#13151a] relative animate-fadeIn">
            <div className="px-4 flex justify-between items-center mb-3">
                <h3 className="text-sm font-bold text-white">Suggested for You</h3>
                <button onClick={onClose} className="text-gray-500 hover:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </button>
            </div>

            <div className="flex overflow-x-auto gap-3 px-4 pb-2 scrollbar-hide snap-x snap-mandatory">
                {suggestions.map((item, index) => (
                    <div key={`${item.type}-${index}`} className="snap-center flex-shrink-0 w-36 bg-[#1E1E1E] border border-white/10 rounded-xl p-3 flex flex-col items-center text-center relative group hover:border-white/20 transition-colors">
                        
                        {/* Close Single Item (Optional, simplified for now) */}
                        
                        {item.type === 'user' ? (
                            <>
                                <div onClick={() => viewProfile(item.data as UserProfile)} className="relative cursor-pointer mb-2">
                                    <img 
                                        src={(item.data as UserProfile).avatarImage} 
                                        alt={(item.data as UserProfile).username} 
                                        className="w-16 h-16 rounded-full object-cover border-2 border-gray-800" 
                                    />
                                    {(item.data as UserProfile).isVerified && (
                                        <div className="absolute bottom-0 right-0 bg-blue-500 rounded-full p-0.5 border-2 border-[#1E1E1E]">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="white" stroke="none"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                        </div>
                                    )}
                                </div>
                                <h4 onClick={() => viewProfile(item.data as UserProfile)} className="text-sm font-bold text-white truncate w-full cursor-pointer hover:underline">{(item.data as UserProfile).username}</h4>
                                <p className="text-[10px] text-gray-400 truncate w-full mb-3 h-4">{item.reason}</p>
                                <button 
                                    onClick={() => onFollow((item.data as UserProfile).username)}
                                    className="w-full py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg transition-colors"
                                >
                                    Follow
                                </button>
                            </>
                        ) : (
                            <>
                                <div className="relative mb-2 w-16 h-16">
                                    <img 
                                        src={(item.data as Group).coverImage} 
                                        alt={(item.data as Group).name} 
                                        className="w-full h-full rounded-xl object-cover border border-white/10" 
                                    />
                                     <div className="absolute -bottom-1 -right-1 bg-yellow-600 rounded-md p-0.5 border-2 border-[#1E1E1E]">
                                        <span className="text-[8px] font-bold text-white px-1">GRP</span>
                                    </div>
                                </div>
                                <h4 className="text-sm font-bold text-white truncate w-full">{(item.data as Group).name}</h4>
                                <p className="text-[10px] text-gray-400 truncate w-full mb-3 h-4">{item.reason}</p>
                                <button 
                                    onClick={() => onJoinGroup(item.data as Group)}
                                    className="w-full py-1.5 bg-gray-700 hover:bg-gray-600 text-white text-xs font-bold rounded-lg transition-colors border border-white/10"
                                >
                                    Join
                                </button>
                            </>
                        )}
                    </div>
                ))}
                {/* Spacer for end of scroll */}
                <div className="w-2 flex-shrink-0"></div>
            </div>
        </div>
    );
};

export default SuggestionCarousel;
