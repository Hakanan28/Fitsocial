import React, { useState } from 'react';

interface EmojiPickerProps {
    onSelect: (emoji: string) => void;
}

const EMOJI_CATEGORIES = {
    'Smileys & People': ['😀', '😂', '😍', '🤔', '😎', '😭', '😡', '👍', '👎', '👋', '🙏', '👀', '🧑‍💻', '👩‍🔬', '👨‍🚀'],
    'Fitness & Health': ['💪', '🏋️‍♀️', '🤸‍♂️', '🏃‍♀️', '🧘‍♂️', '🚴‍♀️', '🥊', '🥋', '👟', '🏆', '🥇', '🥈', '🥉', '💧', '🍎', '🥦', '❤️‍🩹', '🩺'],
    'Cyber & Sci-Fi': ['🤖', '👾', '👽', '🛸', '🚀', '🛰️', '⚡️', '💥', '☄️', '🌌', '🌃', '💻', '🧪', '🧬', '🔮', '💎'],
    'Animals & Nature': ['🐶', '🐱', '🦁', '🐯', '🦄', '🦅', '🦋', '🍀', '🌸', '🌲', '☀️', '🌙', '🌊', '🔥', '🌍'],
    'Food & Drink': ['🍕', '🍔', '🍣', '🌮', '🍜', '🍩', '☕️', '🍺', '🍉', '🍓', '🥑', '🥕', '🥩', '🍳', '🥖'],
    'Objects': ['📱', '⌚️', '💡', '💰', '🔑', '⚔️', '🛡️', '⚙️', '📈', '📊', '📌', '💊', '🎁', '🎉', '🎵'],
};

const EmojiPicker: React.FC<EmojiPickerProps> = ({ onSelect }) => {
    const [activeCategory, setActiveCategory] = useState<string>('Smileys & People');

    return (
        <div className="bg-[#20232b] h-64 w-full rounded-t-2xl border-t border-white/10 flex flex-col shadow-lg">
            <div className="flex-shrink-0 border-b border-white/10">
                <div className="flex space-x-4 overflow-x-auto px-2 pt-2 scrollbar-hide">
                    {Object.keys(EMOJI_CATEGORIES).map(category => (
                        <button 
                            key={category} 
                            onClick={() => setActiveCategory(category)}
                            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition-colors whitespace-nowrap ${activeCategory === category ? 'bg-[#373d48] text-white' : 'text-gray-400 hover:text-white'}`}
                        >
                            {category}
                        </button>
                    ))}
                </div>
            </div>
            <div className="flex-1 p-3 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600">
                <div className="grid grid-cols-8 gap-2">
                    {EMOJI_CATEGORIES[activeCategory as keyof typeof EMOJI_CATEGORIES].map(emoji => (
                        <button 
                            key={emoji} 
                            onClick={() => onSelect(emoji)}
                            className="text-2xl rounded-lg hover:bg-white/10 aspect-square flex items-center justify-center transition-colors active:scale-90"
                        >
                            {emoji}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default EmojiPicker;