import { Chat } from '@google/genai';

export enum Page {
    Home = 'home',
    Explore = 'explore',
    Reels = 'reels',
    Exercise = 'exercise',
    Profile = 'profile',
}

export enum ModalType {
    AiCoach = 'ai-coach',
    Notifications = 'notifications',
    Settings = 'settings',
    DmList = 'dm-list',
    DmChat = 'dm-chat',
    CreatePost = 'create-post',
    ReelEditor = 'reel-editor', 
    StoryEditor = 'story-editor', 
    VideoEditor = 'video-editor', 
    ImageEditor = 'image-editor', 
    PostImageEditor = 'post-image-editor',
    VideoGeneration = 'video-generation',
    ImageGeneration = 'image-generation',
    ContentAnalysis = 'content-analysis',
    ImageEditing = 'image-editing',
    PremiumPitch = 'premium-pitch',
    TextToSpeech = 'text-to-speech',
    SpeechToText = 'speech-to-text',
    ProgramDetails = 'program-details',
    RoutineDetails = 'routine-details',
    ChallengeDetails = 'challenge-details',
    GroupDetails = 'group-details',
    CoachDetails = 'coach-details',
    StoryViewer = 'story-viewer',
    AuthFlow = 'auth-flow',
    DataEntry = 'data-entry',
    AddMeal = 'add-meal',
    CreateRoutine = 'create-routine',
    ReactionTest = 'reaction-test',
    AdaptiveWorkout = 'adaptive-workout',
    WorkoutMode = 'workout-mode',
    RunningMode = 'running-mode',
    HolographicForm = 'holographic-form',
    NeuralLink = 'neural-link',
    QuantumHrv = 'quantum-hrv',
    BodyMap = 'body-map',
    CryptoRewards = 'crypto-rewards',
    StakeChallenge = 'stake-challenge',
    MetaGym = 'meta-gym',
    AiWorkoutGenerator = 'ai-workout-generator',
    WorkoutPlan = 'workout-plan',
    WorkoutVideoGeneration = 'workout-video-generation',
    PostAnalysis = 'post-analysis',
    AiReelGenerator = 'ai-reel-generator',
    SharePost = 'share-post',
    Comments = 'comments',
    CoinDetails = 'coin-details',
    NftDetails = 'nft-details',
    SendCoin = 'send-coin',
    ReceiveCoin = 'receive-coin',
    AddToken = 'add-token',
    ExerciseList = 'exercise-list',
    ExerciseDetail = 'exercise-detail',
    EditProfile = 'edit-profile',
    CreateHighlight = 'create-highlight',
    FollowList = 'follow-list',
    CreateChallenge = 'create-challenge',
    ProofOfWorkout = 'proof-of-workout',
    ProofOfWorkoutDetail = 'proof-of-workout-detail',
    ThemeCustomization = 'theme-customization',
    PostDetail = 'post-detail',
    ReelPlayer = 'reel-player',
    AiRecipe = 'ai-recipe',
    DailyNutritionDetail = 'daily-nutrition-detail',
    CreateGroup = 'create-group',
    GroupChat = 'group-chat', 
    GroupJoin = 'group-join',
    Profile = 'profile',
    GroupProfile = 'group-profile',
    CreateListing = 'create-listing',
    ProductDetail = 'product-detail'
}

export interface CallLog {
    id: string;
    type: 'voice' | 'video';
    direction: 'incoming' | 'outgoing' | 'missed';
    participants: (UserProfile | Group)[]; 
    timestamp: number;
    duration?: number; 
}

export interface Challenge {
    id: string;
    title: string;
    description: string;
    goal: string;
    duration: number;
    creator: UserProfile;
    participants: UserProfile[];
    prizePool: number;
    isAiChallenge?: boolean;
}

export interface CustomTheme {
    type: 'color' | 'pattern' | 'image';
    value: string;
    textColor: 'light' | 'dark';
    backgroundColor?: string;
    backgroundSize?: string;
    backgroundBlendMode?: string;
}

export interface Exercise {
    id: string;
    name: string;
    muscleGroup: string;
    equipment: string;
    thumbnailUrl: string;
    primaryMuscles: string[];
    secondaryMuscles: string[];
    location: 'home' | 'gym' | 'both';
}

export interface RoutineExercise {
    exercise: Exercise;
    sets: string;
    reps: string;
}

export interface WorkoutRoutine {
    id: string;
    user: UserProfile;
    routineName: string;
    description?: string;
    exercises: RoutineExercise[];
    savesCount: number;
    difficulty?: 'Beginner' | 'Intermediate' | 'Advanced';
    tags?: string[];
    likes: number;
    comments: Comment[];
    isLiked?: boolean;
    duration?: number;
    rating?: number;
    ratingsCount?: number;
    allowDownload?: boolean;
}

export interface ChatMessage {
    id: string;
    sender: 'user' | 'ai';
    text: string;
    sources?: { uri: string; title: string }[];
    audioUrl?: string;
    isLoading?: boolean;
    suggestions?: string[];
}

export interface ChatSession {
    id: string;
    title: string;
    messages: ChatMessage[];
    chatInstance: Chat | null;
}

export interface ChallengeExercise {
    exercise: Exercise;
    sets: string;
    reps: string;
    notes?: string;
    completed?: boolean;
}

// Deprecated DmMessage in favor of unified GroupMessage
export interface DmMessage {
    id: number;
    sender: 'user' | 'other';
    type: 'text' | 'challenge' | 'post_share' | 'nft_share'; // Added nft_share
    text?: string;
    challengeDetails?: {
        amount: number;
        duration: number;
        exercises: ChallengeExercise[];
        status: 'pending' | 'accepted' | 'declined' | 'completed';
    };
    sharedPost?: Post | Reel;
    sharedNft?: NFT; // Added sharedNft
    translated?: string;
    isTranslating?: boolean;
}

export interface Transaction {
    id: string;
    type: 'sent' | 'received';
    amount: number;
    date: string;
    address: string;
}

export interface Coin {
    id: string;
    name: string;
    symbol: string;
    logoUrl: string;
    balance: number;
    price: number;
    priceChange24h: number;
    sparkline: number[];
    transactions: Transaction[];
}

export interface Review {
    id: string;
    user: string; // username
    rating: number; // 1-5
    comment: string;
    timestamp: number;
    avatarImage?: string; // Optional for display
}

export interface ItemDesign {
    background?: string;
    themeColor?: string;
    fontStyle?: string;
}

export interface CustomLayoutElement {
    id: string;
    type: 'image-slot' | 'buy-button' | 'title' | 'price' | 'description' | 'specs';
    x: number; // Percentage 0-100
    y: number; // Percentage 0-100
    w: number; // Percentage 0-100
    h: number; // Percentage 0-100
    shape?: 'rect' | 'circle' | 'star' | 'rounded'; // New shape property
    style?: any;
}

export interface CustomLayout {
    elements: CustomLayoutElement[];
    background?: string;
}

export interface NFT {
    id: string;
    name: string;
    collection: string;
    imageUrl: string;
    owner: {
        username: string;
        avatar: string;
    };
    price: number;
    currency: string;
    bestOffer: number;
    description: string;
    reservePrice?: number;
    auctionEndsIn?: string;
    bids: {
        user: {
            username: string;
            avatar: string;
        };
        amount: number;
        currency: string;
    }[];
    priceHistory: { time: string; value: number }[];
    reviews?: Review[];
    customDesign?: ItemDesign;
    customLayout?: CustomLayout;
}


export interface GearItem {
    id: string;
    title: string;
    price: number;
    currency: string;
    image: string;
    category: 'Supplement' | 'Equipment' | 'Clothing' | 'Tech' | 'Accessories';
    condition: 'New' | 'Used' | 'Used - Like New' | 'Used - Good' | 'Used - Fair';
    seller: UserProfile;
    description: string;
    specs?: { id: string; key: string; value: string }[];
    logistics?: {
        weight: string;
        dimensions: string;
        carrier: string;
        deliveryTime: string;
    };
    reviews?: Review[];
    customDesign?: ItemDesign;
    customLayout?: CustomLayout;
}

export type BadgeCategory = 'Consistency' | 'Milestones' | 'Social' | 'Content' | 'PRO' | 'Economy';
export type BadgeRarity = 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary';

export interface BadgeNFT {
    id: string;
    title: string;
    description: string;
    imageUrl: string;
    rarity: BadgeRarity;
    category: BadgeCategory;
    floorPrice: number;
    icon?: string;
    condition: {
        type: string;
        value: number;
    };
}

export interface Comment {
    id: number;
    user: string;
    text: string;
}

export interface ImageTag {
    username: string;
    x: number; 
    y: number; 
}

export interface PostLocation {
    name: string;
    address?: string;
    latitude?: number;
    longitude?: number;
}

export interface Post {
    id: number;
    author: string;
    avatarText: string;
    mediaUrl: string;
    mediaType: 'image' | 'video';
    caption: string;
    likes: number;
    comments: Comment[];
    savesCount: number;
    shareCount: number;
    filter?: string;
    location?: string; 
    locationDetails?: PostLocation; 
    taggedUsers?: string[]; 
    imageTags?: ImageTag[]; 
    isLiked?: boolean;
    allowDownload?: boolean;
    type?: 'regular' | 'proofOfWorkout' | 'reel'; 
    powDetails?: {
        activity: string;
        duration: { hours: number; minutes: number };
        effort: number;
        sets?: string;
        reps?: string;
    };
}

export interface UserPost {
    id: number;
    img: string;
    caption: string;
}

export interface Story {
    user: string;
    mediaUrl: string;
    mediaType: 'image' | 'video';
    avatarImage?: string;
    isMuted?: boolean;
    filter?: string;
    music?: {
        name: string;
        src: string;
    };
    textOverlays?: {
        id: number;
        text: string;
        color: string;
        position: { x: number; y: number };
    }[];
}

export interface StoryHighlight {
    id: string;
    title: string;
    coverImage: string;
    stories: Story[];
}

export interface UserProfile {
    username: string;
    name?: string;
    surname?: string;
    email: string;
    phone?: string;
    password?: string;
    avatarText: string;
    avatarColor: string;
    avatarImage?: string;
    posts: UserPost[];
    followers: number;
    following: string[];
    cvsScore: number;
    bio?: string;
    highlights?: StoryHighlight[];
    isVerified?: boolean; 
    somatotype: 'ectomorph' | 'mesomorph' | 'endomorph';
    isOnline?: boolean;
    lastSeen?: number; 
    presenceHidden?: boolean;
    blockedUsers?: string[]; 
    creationTimestamp?: number; 
}

export interface DetailedUserProfileData {
    height: number;
    weight: number;
    targetWeight: number;
    age: number;
    activity: number;
    gender: 'male' | 'female';
    somatotype: 'ectomorph' | 'mesomorph' | 'endomorph';
    fatDistribution: 'apple' | 'pear';
    dob: string;
    fitnessGoal: 'weight_loss' | 'muscle_gain' | 'athletic' | 'maintenance';
    activeSports: UserSport[];
    gymExercises?: string;
    aiDietPlan?: AiDietPlan;
}

export type ProfileTab = 'content' | 'tracker' | 'quests' | 'badges' | 'wallet' | 'history';
export type ExploreTab = 'discoverMore' | 'challenges' | 'leaderboard' | 'marketplace' | 'groups' | 'signal' | 'aiKitchen';

export interface ActivityRecord {
    date: string;
    steps: number;
    distance: number;
    calories: number;
    water: number;
    sleep: number;
}

export interface Reel {
    id: number;
    user: string;
    caption: string;
    subtitle: string;
    videoSrc: string;
    videoType?: string;
    likes: number;
    comments: Comment[];
    isMuted?: boolean;
    effect?: string;
    taggedUsers?: string[];
    shareCount: number;
    savesCount: number;
    watchTimePercentage: number;
    timestamp: number;
    category: 'Cardio' | 'Strength' | 'Yoga' | 'General';
    isLiked?: boolean;
    allowDownload?: boolean;
}

export interface ProofOfWorkoutPost {
    id: string;
    user: UserProfile;
    mediaUrl: string;
    mediaType: 'image' | 'video';
    activity: string;
    notes?: string;
    effort: number;
    duration: {
        hours: number;
        minutes: number;
    };
    sets?: string;
    reps?: string;
    isVerified: boolean;
    likes: number;
    comments: Comment[];
    isLiked?: boolean;
    allowDownload?: boolean;
    location?: string; 
}

export enum NotificationType {
    Like = 'like',
    Comment = 'comment',
    Follow = 'follow',
    Share = 'share',
    Download = 'download',
    Security = 'security',
    Mention = 'mention'
}

export interface Notification {
    id: string;
    type: NotificationType;
    actor: UserProfile;
    recipientUsername: string;
    contentPreview?: string;
    message: string;
    timestamp: number;
    isRead: boolean;
    relatedContentId?: string | number;
}

export interface AdaptiveWorkoutPlan {
    workoutTitle: string;
    aiRationale: string;
    warmup: { name: string; duration: string; }[];
    exercises: { name: string; sets: string; reps: string; rest: string; }[];
    cooldown: { name: string; duration: string; }[];
}

export interface UserSport {
    id: string;
    name: string;
    hoursPerWeek: number;
    intensity?: 'Low' | 'Moderate' | 'High';
}

export interface SportBreakdown {
    name: string;
    calories: number; 
    hourlyBurn: number;
}

export interface AiDietPlan {
    bmr: number;
    baseBurn: number; 
    sportsBurn: number; 
    workoutBurnPerSession: number; 
    tdee: number; 
    targetCalories: number;
    calorieStrategy: string; 
    calorieAdjustment: number; 
    macros: {
        protein: number;
        carbs: number;
        fat: number;
    };
    sportsBreakdown: SportBreakdown[]; 
    advice: string;
}

export interface AiRecipeResponse {
    planName: string;
    aiAnalysis: string;
    meals: {
        type: string;
        name: string;
        ingredients: string[];
        instructions: string[];
        macros: {
            calories: number;
            protein: number;
            carbs: number;
            fat: number;
            fiber?: number;
            sugar?: number;
            sodium?: number;
            potassium?: number;
            saturatedFat?: number;
            vitamins: string;
        };
        missingIngredients?: string[];
    }[];
}

export interface FoodLogEntry {
    id: string;
    name: string;
    mealType: string; 
    calories: number;
    macros?: {
        pro: number;
        carb: number;
        fat: number;
    };
    date: string;
    timestamp: number;
}

// --- ADVANCED GROUP & CHAT TYPES ---

export interface GroupTheme {
    id: string;
    name: string;
    gradient: string; 
    primaryColor: string; 
    accentColor: string; 
    isAnimated?: boolean; 
}

export interface GroupGoal {
    title: string;
    target: number;
    current: number;
    unit: string;
}

export interface GroupRequirements {
    isStaked?: boolean;
    stakeAmount?: number;
    nftRequired?: boolean;
}

export interface SocialLinks {
    discord?: string;
    instagram?: string;
    website?: string;
}

export interface GroupMessage {
    id: string;
    sender: UserProfile;
    text?: string;
    type: 'text' | 'image' | 'video' | 'action_gym' | 'action_panic' | 'image_single' | 'stake_challenge' | 'post_share' | 'nft_share'; 
    timestamp: number;
    mediaUrl?: string; 
    stakeDetails?: {
        amount: number;
        task: string;
        durationHours: number;
        status: 'pending' | 'accepted' | 'completed' | 'expired';
        challengerId: string;
        accepterId?: string; // User who accepted
        poolTotal: number; // 2x amount
    };
    sharedPost?: Post | Reel;
    sharedNft?: NFT;
}


export interface GroupRequest {
    user: UserProfile;
    answer: string;
    timestamp: number;
}

export interface Group {
    id: string;
    name: string;
    description: string;
    motto: string;
    coverImage?: string;
    tags?: string[];
    admin: UserProfile;
    members: UserProfile[];
    memberCount: number;
    theme: GroupTheme;
    goal?: GroupGoal;
    requirements?: GroupRequirements;
    socialLinks?: SocialLinks;
    entryQuestion: string;
    pendingRequests: GroupRequest[];
    messages: GroupMessage[];
    isPrivate: boolean;
    location?: string;
    pinnedMessageId?: string;
}
